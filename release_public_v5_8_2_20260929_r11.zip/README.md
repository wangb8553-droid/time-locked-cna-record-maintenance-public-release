# Time-locked CNA record-maintenance benchmark (release 5.8.2)

This release accompanies an empirical software-engineering study of **syntactic CNA affected-field record maintenance**. It does not predict exploitation, security risk, semantic affected-version expansion, patch priority, or analyst workload savings. This curated package is prepared for journal review and public archival; no public repository DOI has yet been assigned.

## What is in this release

- Project-authored analysis and audit scripts, tests, and the frozen V5.8.1 protocol.
- Aggregate cohort/model/holdout/replay summaries and the manuscript's table source data.
- Figure files (PDF, SVG, PNG) and the cleaned aggregate source data behind them.
- A source-provenance record with upstream commit identifiers and reconstruction notes.

## What is deliberately not included

No upstream CVE or CISA KEV Git repository, original record text, row-level labels, complete per-record trajectories, row-level predictions, case keys, model weights, private review material, account data, or credentials are included. The published aggregate tables do not allow record-level prediction recovery. Re-running the full analysis requires obtaining the upstream public datasets directly and rebuilding the inputs using the recorded revisions and protocol.

## Reproduce selected aggregate figures

Use Python 3.11 with the versions in `requirements-figure.lock` and run:

```powershell
python src_public/plot_public_fig2_r01.py --source-data source_data/figure_2_primary_models_source_data.csv --output-dir outputs/figure2_rebuilt
```

The script refuses to run if the constant-score baselines are not the analytic expected recalls (5%, 10%, and 20%) under random tie-breaking. It generates Figure 2 in SVG, PDF, TIFF and PNG and writes a small QA manifest. Figure S1 can be rebuilt from the public aggregate replay summary without access to record-level trajectories:

```powershell
python src_v5/plot_v5_1_full_window_schematic.py --audit-summary source_data/replay_audit_summary.json --output-dir outputs/figure_s1_rebuilt --run-id figure_s1_release_20260929_r11
```

Figures 1-6 and S2-S3 are supplied with their cleaned aggregate source tables; their source run identifiers are recorded in the release manifests.

## Primary endpoint and interpretation

The primary event is a new normalized CNA affected-field signature within the 90-day observation window after a 24-hour information-time boundary. It is a record-structure event, not proof that the real affected population changed. The fixed 2025 test cohort contains 26,103 records and 2,428 such events. The primary metric is R@10%; PR-AUC is used for the frozen fusion hypothesis. Entity-transfer and grouped-uncertainty results materially limit generalization.

## Data and code rights

The MIT License applies only to project-authored software, tests and documentation. Aggregate result tables and figure data are public for access and inspection, but no separate open-data license is granted in this package. Third-party rights and source attribution remain governed by their respective terms. The upstream CVE and CISA KEV records are not redistributed. The included tests are a hermetic synthetic-fixture subset, not the full private-data integration suite.

See `RIGHTS_AND_ATTRIBUTION.md`, `docs/`, and `source_data/README.md` before reuse. The package is a local candidate until repository publication is confirmed. No DOI is asserted; it must be added only after Zenodo registers a published record.
