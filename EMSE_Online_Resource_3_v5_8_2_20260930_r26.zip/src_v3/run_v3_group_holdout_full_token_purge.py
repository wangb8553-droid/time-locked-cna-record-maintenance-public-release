"""Strict all-token purge sensitivity using frozen outcome-blind group selections."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from run_v3_group_holdout_outcomeblind import GROUP_FIELDS, group_values, write_json
from run_v3_models import bootstrap, dict_matrix, fit_probability, metrics, require_manifest, sha256
from v3_input_reference import validate_reference


OUTCOME = "affected_field_structural_addition"


def purge_train_by_all_test_tokens(train: list[dict], heldout_test: list[dict], group: str) -> tuple[list[dict], set[str]]:
    """Purge training rows that carry any token present in held-out test rows."""
    heldout_tokens = {token for row in heldout_test for token in group_values(row, group)}
    retained = [row for row in train if not (group_values(row, group) & heldout_tokens)]
    return retained, heldout_tokens


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--v3-input-reference", type=Path, required=True)
    parser.add_argument("--v3-labels", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--selection-manifest", type=Path, required=True)
    parser.add_argument("--group", choices=tuple(GROUP_FIELDS), required=True)
    parser.add_argument("--bootstrap-replicates", type=int, default=2000)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output_dir.exists() or args.bootstrap_replicates != 2000:
        raise RuntimeError("invalid_full_token_purge_request_preserve_existing_run")

    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    if protocol.get("protocol_id") != "group_holdout_full_token_purge_v3_primary_20260930":
        raise RuntimeError("strict_purge_protocol_id_invalid")
    expected_selection_hash = protocol["selection_manifests"][args.group]["sha256"]
    selection_hash = sha256(args.selection_manifest)
    if selection_hash != expected_selection_hash:
        raise RuntimeError("frozen_outcome_blind_selection_hash_mismatch")
    selection = json.loads(args.selection_manifest.read_text(encoding="utf-8"))
    if selection.get("group") != args.group or selection.get("selection_is_post_hoc") is not True:
        raise RuntimeError("selection_manifest_group_or_status_invalid")

    reference = validate_reference(args.v3_input_reference, args.v3_labels)
    manifest = require_manifest(args.model_rows, args.model_manifest, args.v3_input_reference)
    if manifest.get("row_count") != 76790:
        raise RuntimeError("unexpected_model_row_count")
    rows = [json.loads(line) for line in args.model_rows.read_text(encoding="utf-8").splitlines() if line.strip()]
    train = [row for row in rows if row["t_obs"][:10] <= "2024-06-30"]
    test = [row for row in rows if "2025-01-01" <= row["t_obs"][:10] <= "2025-09-30"]
    selected_tokens = {entry["token"] for entry in selection["selected_groups"]}
    if not selected_tokens:
        raise RuntimeError("frozen_selection_has_no_tokens")
    heldout_test = [row for row in test if group_values(row, args.group) & selected_tokens]
    selected_purged_train = [row for row in train if not (group_values(row, args.group) & selected_tokens)]
    retained_train, all_heldout_tokens = purge_train_by_all_test_tokens(train, heldout_test, args.group)
    remaining_overlap = sorted(
        {token for row in retained_train for token in group_values(row, args.group)} & all_heldout_tokens
    )
    if remaining_overlap:
        raise RuntimeError("all_token_overlap_remains_after_strict_purge")

    args.output_dir.mkdir(parents=True)
    selection_payload = {
        "run_id": args.run_id,
        "status": "strict_training_purge_frozen_before_outcome_metrics",
        "group": args.group,
        "source_selection_run_id": selection["run_id"],
        "source_selection_manifest_sha256": selection_hash,
        "fixed_selected_tokens": selection["selected_groups"],
        "all_group_tokens_in_heldout_test": sorted(all_heldout_tokens),
        "strict_rule": "purge every training record carrying any token in all_group_tokens_in_heldout_test",
        "split_counts_without_outcome_access": {
            "original_train": len(train),
            "selected_token_purged_train": len(selected_purged_train),
            "strict_retained_train": len(retained_train),
            "heldout_test": len(heldout_test),
            "additional_rows_purged_for_all_token_disjointness": len(selected_purged_train) - len(retained_train),
        },
        "remaining_all_token_overlap": remaining_overlap,
        "hashes": {
            "protocol_sha256": sha256(args.protocol),
            "strict_script_sha256": sha256(Path(__file__)),
            "initial_selection_script_sha256": selection["hashes"]["script_sha256"],
            "model_rows_sha256": sha256(args.model_rows),
            "model_manifest_sha256": sha256(args.model_manifest),
            "input_reference_sha256": sha256(args.v3_input_reference),
            "v3_labels_sha256": sha256(args.v3_labels),
        },
    }
    selection_path = args.output_dir / "strict_purge_manifest.json"
    write_json(selection_path, selection_payload)
    strict_manifest_hash = sha256(selection_path)

    # Outcome labels are first accessed after the strict purge manifest is written.
    label_name = "outcome_" + OUTCOME
    for row in (*retained_train, *heldout_test):
        if label_name not in row:
            raise RuntimeError("primary_outcome_missing_after_strict_purge")
        row["label"] = int(row[label_name])
    y_train = np.asarray([row["label"] for row in retained_train], dtype=int)
    y_test = np.asarray([row["label"] for row in heldout_test], dtype=int)
    if len(set(y_train.tolist())) != 2 or len(set(y_test.tolist())) != 2:
        raise RuntimeError("strict_purge_split_lacks_both_classes_preserve_selection")

    x_train, x_test = dict_matrix(retained_train, heldout_test, "full")
    scores = fit_probability(x_train, y_train, x_test)
    ids = np.asarray([row["cve_id"] for row in heldout_test])
    point_metrics = metrics(y_test, scores, ids)
    intervals = bootstrap(y_test, scores, ids, args.bootstrap_replicates, 20261001)
    n_test = len(y_test)
    positives = int(y_test.sum())
    capacity_10 = int(np.ceil(n_test * 0.10))
    prevalence = positives / n_test

    pred_path = args.output_dir / "heldout_predictions_private.jsonl"
    pred_path.write_text(
        "".join(
            json.dumps({"cve_id": row["cve_id"], "t_obs": row["t_obs"], "label": int(y_test[i]), "score": float(scores[i])}, ensure_ascii=False) + "\n"
            for i, row in enumerate(heldout_test)
        ),
        encoding="utf-8",
    )
    report = {
        "run_id": args.run_id,
        "status": "completed",
        "interpretation": "post hoc strict all-token-disjointness sensitivity using fixed outcome-blind selected groups; not preregistered or a population-level unseen-entity estimate",
        "group": args.group,
        "outcome": OUTCOME,
        "model": "structured_cna",
        "model_specification": "DictVectorizer sparse structured features + LogisticRegression(C=1.0, max_iter=500, class_weight=balanced, solver=liblinear, random_state=20260906)",
        "split_counts": {
            "original_train": len(train),
            "selected_token_purged_train": len(selected_purged_train),
            "strict_retained_train": len(retained_train),
            "strict_train_positive": int(y_train.sum()),
            "heldout_test": n_test,
            "heldout_test_positive": positives,
            "test_prevalence": prevalence,
            "additional_rows_purged_for_all_token_disjointness": len(selected_purged_train) - len(retained_train),
        },
        "all_token_disjointness": {
            "heldout_test_group_token_count": len(all_heldout_tokens),
            "train_test_overlap_count_after_purge": len(remaining_overlap),
            "train_test_overlap_after_purge": remaining_overlap,
        },
        "within_set_baselines": {
            "constant_score_pr_auc_equals_prevalence": prevalence,
            "r10_capacity": capacity_10,
            "expected_random_r10": capacity_10 / n_test,
        },
        "test_metrics": point_metrics,
        "row_stratified_bootstrap_95": intervals,
        "bootstrap_interpretation": "conditional on fixed heldout rows; not uncertainty over unseen groups",
        "strict_purge_manifest_sha256": strict_manifest_hash,
        "prediction_artifact": {"path": pred_path.name, "classification": "private_local_only; not for redistribution", "sha256": sha256(pred_path)},
        "hashes": selection_payload["hashes"],
        "python": sys.version,
        "platform": platform.platform(),
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(args.output_dir / "group_holdout_report.json", report)
    print(json.dumps({"run_id": args.run_id, "group": args.group, "heldout_n": n_test, "positives": positives, "pr_auc": point_metrics["pr_auc"], "r10": point_metrics["recall_at_10_pct"], "strict_train_n": len(retained_train), "all_token_overlap": len(remaining_overlap)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
