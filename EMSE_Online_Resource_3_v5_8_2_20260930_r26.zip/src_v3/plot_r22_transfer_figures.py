"""Create updated, audit-bound EMSE transfer figures from aggregate reports.

The script never reads row-level predictions or group-token identifiers. It
exports editable vector figures, 600-dpi TIFFs, manuscript-sized PNGs, clean
aggregate source tables, and an input/output hash manifest.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D


BLUE = "#145DA0"
TEAL = "#3D8E9B"
PURPLE = "#8E5A8C"
GRAY = "#777777"
LIGHT = "#D1D1D1"

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans", "Liberation Sans"],
    "font.size": 7,
    "axes.labelsize": 7,
    "xtick.labelsize": 6.5,
    "ytick.labelsize": 6.5,
    "axes.linewidth": 0.75,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "legend.frameon": False,
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
})


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def save_all(fig, stem: Path) -> list[Path]:
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight",
                pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    outputs = [stem.with_suffix(suffix) for suffix in (".svg", ".pdf", ".tiff", ".png")]
    plt.close(fig)
    return outputs


def add_panel(ax, label: str) -> None:
    ax.text(-0.15, 1.04, label, transform=ax.transAxes, fontweight="bold",
            fontsize=8, ha="left", va="bottom")


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError("empty_source_data")
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        fieldnames = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def figure4(delta: dict, month: dict, cna: dict, stem: Path) -> tuple[list[Path], list[dict]]:
    models = ["structured_cna", "fused_tfidf_structured", "tfidf_word_character"]
    labels = ["Structured CNA", "Fusion", "TF-IDF text"]
    colors = [BLUE, PURPLE, TEAL]
    fig, axes = plt.subplots(1, 2, figsize=(6.85, 2.15),
                             gridspec_kw={"width_ratios": [1.0, 1.3]},
                             layout="constrained")

    ax = axes[0]
    rows = []
    y = np.arange(len(models))[::-1]
    for yi, model, label, color in zip(y, models, labels, colors):
        item = delta["models"][model]
        value = item["point_pr_auc_difference_full_minus_ablated"]
        ci = item["paired_bootstrap_95"]
        ax.errorbar(value, yi,
                    xerr=[[value - ci["lower_95"]], [ci["upper_95"] - value]],
                    fmt="o", color=color, capsize=2, lw=1.0, ms=4)
        rows.append({"panel": "a", "model": model, "label": label,
                     "estimate": value, "ci_lower": ci["lower_95"],
                     "ci_upper": ci["upper_95"],
                     "interpretation": "paired full-minus-identity-ablated PR-AUC"})
    ax.axvline(0, color=GRAY, lw=0.8, ls="--")
    ax.set_yticks(y, labels)
    ax.set_xlabel("Full minus ablated PR-AUC")
    ax.set_xlim(-0.008, 0.21)
    add_panel(ax, "a")

    ax = axes[1]
    primary = read_json(Path(delta["_primary_report_path"])) if delta.get("_primary_report_path") else None
    if primary is None:
        raise ValueError("primary_report_missing_for_figure4")
    point = primary["test_models"]["structured_cna"]["metrics"]["pr_auc"]
    intervals = [
        ("Fixed-row bootstrap", primary["test_models"]["structured_cna"]["bootstrap_95"]["pr_auc"], None),
        (f"Month clusters (k={month['cluster_count']})", month["models"]["structured_cna"]["bootstrap_95"]["pr_auc"], month["cluster_count"]),
        (f"CNA clusters (k={cna['cluster_count']})", cna["models"]["structured_cna"]["bootstrap_95"]["pr_auc"], cna["cluster_count"]),
    ]
    yy = np.arange(len(intervals))[::-1]
    for yi, (label, interval, count) in zip(yy, intervals):
        low, high = interval["lower_95"], interval["upper_95"]
        ax.plot([low, high], [yi, yi], color=BLUE, lw=1.4)
        ax.plot(point, yi, "o", color=BLUE, ms=4)
        rows.append({"panel": "b", "model": "structured_cna", "label": label,
                     "estimate": point, "ci_lower": low, "ci_upper": high,
                     "cluster_count": count,
                     "interpretation": "sensitivity interval; not an external-generalization interval"})
    ax.set_yticks(yy, [x[0] for x in intervals])
    ax.set_xlabel("Structured-CNA PR-AUC (95% interval)")
    ax.set_xlim(0, 0.9)
    add_panel(ax, "b")
    return save_all(fig, stem), rows


def figure5(primary: dict, holdouts: list[dict], stem: Path) -> tuple[list[Path], list[dict]]:
    colors = {"structured_cna": BLUE, "tfidf_word_character": TEAL,
              "fused_tfidf_structured": PURPLE}
    model_labels = {"structured_cna": "Structured CNA",
                    "tfidf_word_character": "TF-IDF text",
                    "fused_tfidf_structured": "Fusion"}
    group_order = ["vendor", "product", "cna"]
    group_labels = {"vendor": "Vendor", "product": "Product", "cna": "CNA"}
    report_by_group = {item["group"]: item for item in holdouts}
    if set(report_by_group) != set(group_order):
        raise ValueError("holdout_group_set_invalid")

    fig = plt.figure(figsize=(6.85, 3.55), layout="constrained")
    grid = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.2], hspace=0.28, wspace=0.22)
    axes = (fig.add_subplot(grid[0, :]), fig.add_subplot(grid[1, 0]),
            fig.add_subplot(grid[1, 1]))
    source_rows: list[dict] = []

    ax = axes[0]
    period_keys = ["train_through_2023_test_2024", "train_through_2024_test_2025"]
    period_labels = ["Train ≤2023\nTest 2024", "Train ≤2024\nTest 2025"]
    for model, color in colors.items():
        estimates, lows, highs = [], [], []
        for key in period_keys:
            item = primary["rolling_origin_models"][key][model]
            estimates.append(item["metrics"]["pr_auc"])
            lows.append(item["bootstrap_95"]["pr_auc"]["lower_95"])
            highs.append(item["bootstrap_95"]["pr_auc"]["upper_95"])
            source_rows.append({"panel": "a", "analysis": key, "model": model,
                                "estimate": estimates[-1], "ci_lower": lows[-1],
                                "ci_upper": highs[-1], "test_prevalence": "",
                                "random_r10_expectation": "",
                                "record_count": "", "positive_count": ""})
        ax.errorbar([0, 1], estimates,
                    yerr=[np.array(estimates) - np.array(lows),
                          np.array(highs) - np.array(estimates)],
                    marker="o", lw=1.15, ms=3.5, capsize=2,
                    color=color, label=model_labels[model])
    ax.set_xticks([0, 1], period_labels)
    ax.set_xlim(-0.08, 1.08)
    ax.set_ylabel("PR-AUC")
    ax.set_ylim(0, 0.85)
    ax.legend(fontsize=5.5, loc="upper left")
    add_panel(ax, "a")

    y = np.arange(len(group_order))[::-1]
    ax = axes[1]
    for yi, group in zip(y, group_order):
        report = report_by_group[group]
        met = report["test_metrics"]
        ci = report["row_stratified_bootstrap_95"]["pr_auc"]
        baseline = report["within_set_baselines"]["constant_score_pr_auc_equals_prevalence"]
        ax.errorbar(met["pr_auc"], yi,
                    xerr=[[met["pr_auc"] - ci["lower_95"]],
                          [ci["upper_95"] - met["pr_auc"]]],
                    fmt="o", color=BLUE, capsize=2, ms=4, lw=1.0)
        ax.plot(baseline, yi, marker="D", ms=3.5, color=GRAY)
        n = report["split_counts"]["heldout_test"]
        pos = report["split_counts"]["heldout_test_positive"]
        prev = report["within_set_baselines"]["constant_score_pr_auc_equals_prevalence"]
        source_rows.append({"panel": "b", "analysis": f"{group}_strict_all_token_purge",
                            "model": "structured_cna", "estimate": met["pr_auc"],
                            "ci_lower": ci["lower_95"], "ci_upper": ci["upper_95"],
                            "test_prevalence": prev, "random_r10_expectation": "",
                            "record_count": n, "positive_count": pos,
                            "additional_train_rows_purged": report["split_counts"].get("additional_rows_purged_for_all_token_disjointness", 0)})
    ax.set_yticks(y, [group_labels[g] for g in group_order])
    ax.set_xlabel("PR-AUC")
    ax.set_xlim(0, 0.75)
    ax.legend(
        handles=[
            Line2D([0], [0], marker="o", color="none", markerfacecolor=BLUE,
                   markeredgecolor=BLUE, markersize=4, label="Model"),
            Line2D([0], [0], marker="D", color="none", markerfacecolor=GRAY,
                   markeredgecolor=GRAY, markersize=3.5, label="Prevalence"),
        ],
        loc="lower center", bbox_to_anchor=(0.5, 1.01), ncol=2,
        fontsize=5.5, handletextpad=0.35, columnspacing=0.8, frameon=False,
    )
    add_panel(ax, "b")

    ax = axes[2]
    for yi, group in zip(y, group_order):
        report = report_by_group[group]
        met = report["test_metrics"]
        ci = report["row_stratified_bootstrap_95"]["recall_at_10_pct"]
        baseline = report["within_set_baselines"]["expected_random_r10"]
        ax.errorbar(met["recall_at_10_pct"], yi,
                    xerr=[[met["recall_at_10_pct"] - ci["lower_95"]],
                          [ci["upper_95"] - met["recall_at_10_pct"]]],
                    fmt="o", color=BLUE, capsize=2, ms=4, lw=1.0)
        ax.plot(baseline, yi, marker="D", ms=3.5, color=GRAY)
        source_rows.append({"panel": "c", "analysis": f"{group}_strict_all_token_purge",
                            "model": "structured_cna", "estimate": met["recall_at_10_pct"],
                            "ci_lower": ci["lower_95"], "ci_upper": ci["upper_95"],
                            "test_prevalence": report["within_set_baselines"]["constant_score_pr_auc_equals_prevalence"],
                            "random_r10_expectation": baseline,
                            "record_count": report["split_counts"]["heldout_test"],
                            "positive_count": report["split_counts"]["heldout_test_positive"],
                            "additional_train_rows_purged": report["split_counts"].get("additional_rows_purged_for_all_token_disjointness", 0)})
    ax.set_yticks(y, [group_labels[g] for g in group_order])
    ax.set_xlabel("Recall at 10%")
    ax.set_xlim(0, 0.78)
    ax.legend(
        handles=[
            Line2D([0], [0], marker="o", color="none", markerfacecolor=BLUE,
                   markeredgecolor=BLUE, markersize=4, label="Model"),
            Line2D([0], [0], marker="D", color="none", markerfacecolor=GRAY,
                   markeredgecolor=GRAY, markersize=3.5, label="Random expectation"),
        ],
        loc="lower center", bbox_to_anchor=(0.5, 1.01), ncol=2,
        fontsize=5.5, handletextpad=0.35, columnspacing=0.8, frameon=False,
    )
    add_panel(ax, "c")

    return save_all(fig, stem), source_rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary-report", type=Path, required=True)
    parser.add_argument("--profile-delta", type=Path, required=True)
    parser.add_argument("--cluster-month", type=Path, required=True)
    parser.add_argument("--cluster-cna", type=Path, required=True)
    parser.add_argument("--holdout-report", type=Path, nargs=3, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise SystemExit(f"output_dir_exists: {args.output_dir}")
    inputs = [args.primary_report, args.profile_delta, args.cluster_month,
              args.cluster_cna, *args.holdout_report]
    missing = [str(path) for path in inputs if not path.is_file()]
    if missing:
        raise SystemExit("missing_input: " + ", ".join(missing))
    args.output_dir.mkdir(parents=True)

    primary = read_json(args.primary_report)
    delta = read_json(args.profile_delta)
    month = read_json(args.cluster_month)
    cna = read_json(args.cluster_cna)
    holds = [read_json(path) for path in args.holdout_report]
    if any(x.get("status") != "completed" for x in holds):
        raise SystemExit("holdout_run_not_completed")
    if any(x.get("all_token_disjointness", {}).get("train_test_overlap_count_after_purge") != 0 for x in holds):
        raise SystemExit("strict_all_token_purge_audit_failed")

    # Pass the exact frozen primary report to Figure 4 without duplicating its values.
    delta["_primary_report_path"] = str(args.primary_report)
    outputs: list[Path] = []
    fig4, fig4_rows = figure4(delta, month, cna, args.output_dir / "Fig4_identity_uncertainty")
    fig5, fig5_rows = figure5(primary, holds, args.output_dir / "Fig5_transfer_and_drift")
    outputs.extend(fig4)
    outputs.extend(fig5)
    write_csv(args.output_dir / "figure4_source_data.csv", fig4_rows)
    write_csv(args.output_dir / "figure5_source_data.csv", fig5_rows)

    manifest = {
        "run_id": args.run_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "backend": "Python / matplotlib",
        "python": sys.version,
        "platform": platform.platform(),
        "matplotlib": matplotlib.__version__,
        "inputs": {str(p): {"sha256": sha256(p), "bytes": p.stat().st_size} for p in inputs},
        "outputs": {p.name: {"sha256": sha256(p), "bytes": p.stat().st_size} for p in outputs},
        "figure_contract": {
            "figure4": "Identity-feature dependence and the difference between fixed-row and clustered uncertainty.",
            "figure5": "Performance varies by time window and group; group-specific baselines are displayed and no arbitrary unseen-group claim is made.",
            "intervals": "2,000-replicate row-stratified bootstrap intervals conditional on fixed rows; cluster intervals are sensitivity analyses.",
            "group_selection": "Post hoc outcome-blind top-20 high-support groups; full-token training purge; not retrospective preregistration or a population sample.",
        },
        "qa": {
            "all_holdout_runs_completed": True,
            "all_group_token_overlap_after_strict_purge": 0,
            "prediction_records_embedded_or_exported": False,
            "group_token_identifiers_embedded_or_exported": False,
        },
    }
    manifest_path = args.output_dir / "figure_revision_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": args.run_id, "figure4": len(fig4), "figure5": len(fig5),
                      "manifest": str(manifest_path)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
