"""Post hoc, outcome-blind group-holdout sensitivity for the V3 primary outcome.

Group selection uses only test-cohort group-token support. Outcome fields are
not read until after selection_manifest.json has been written.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from run_v3_models import bootstrap, dict_matrix, fit_probability, metrics, require_manifest, sha256
from v3_input_reference import validate_reference


GROUP_FIELDS = {"vendor": "vendors", "product": "products", "cna": "cna_group"}
OUTCOME = "affected_field_structural_addition"


def group_values(row: dict, group: str) -> set[str]:
    raw = str(row[GROUP_FIELDS[group]])
    return {item for item in raw.split("|") if item and item != "__missing__"}


def select_groups_without_outcomes(test_rows: list[dict], group: str, count: int, min_support: int) -> list[dict]:
    """Select groups using only support, with deterministic lexical tie-breaking."""
    support = Counter(token for row in test_rows for token in group_values(row, group))
    eligible = [(token, n) for token, n in support.items() if n >= min_support]
    eligible.sort(key=lambda item: (-item[1], item[0]))
    return [{"token": token, "test_support": n} for token, n in eligible[:count]]


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--v3-input-reference", type=Path, required=True)
    parser.add_argument("--v3-labels", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--group", choices=tuple(GROUP_FIELDS), required=True)
    parser.add_argument("--group-count", type=int, default=20)
    parser.add_argument("--min-support", type=int, default=10)
    parser.add_argument("--bootstrap-replicates", type=int, default=2000)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()

    if args.output_dir.exists():
        raise RuntimeError("output_dir_exists_preserve_existing_run")
    if args.group_count != 20 or args.min_support != 10 or args.bootstrap_replicates != 2000:
        raise RuntimeError("invalid_formal_outcome_blind_holdout_request")

    protocol = json.loads(args.protocol.read_text(encoding="utf-8")) if args.protocol.suffix == ".json" else {"text": args.protocol.read_text(encoding="utf-8")}
    protocol_bytes = args.protocol.read_bytes()
    script_path = Path(__file__)
    reference = validate_reference(args.v3_input_reference, args.v3_labels)
    manifest = require_manifest(args.model_rows, args.model_manifest, args.v3_input_reference)
    if manifest.get("row_count") != 76790:
        raise RuntimeError("unexpected_model_row_count")

    rows = [json.loads(line) for line in args.model_rows.read_text(encoding="utf-8").splitlines() if line.strip()]
    train = [row for row in rows if row["t_obs"][:10] <= "2024-06-30"]
    test = [row for row in rows if "2025-01-01" <= row["t_obs"][:10] <= "2025-09-30"]

    # This selection function deliberately has no outcome argument and never reads a label.
    selected_rows = select_groups_without_outcomes(test, args.group, args.group_count, args.min_support)
    if not selected_rows:
        raise RuntimeError("no_eligible_outcome_blind_groups")
    selected_tokens = {item["token"] for item in selected_rows}
    heldout_test = [row for row in test if group_values(row, args.group) & selected_tokens]
    retained_train = [row for row in train if not (group_values(row, args.group) & selected_tokens)]
    selected_token_overlap = sorted(
        {token for row in retained_train for token in group_values(row, args.group)} & selected_tokens
    )
    all_test_tokens = {token for row in heldout_test for token in group_values(row, args.group)}
    all_train_tokens = {token for row in retained_train for token in group_values(row, args.group)}
    any_token_overlap = sorted(all_test_tokens & all_train_tokens)
    if selected_token_overlap:
        raise RuntimeError("selected_token_overlap_after_purge")

    args.output_dir.mkdir(parents=True)
    selection = {
        "run_id": args.run_id,
        "status": "selection_frozen_before_outcome_metrics",
        "selection_rule": "test-cohort support >= min_support; sort by descending support then ascending token; first group_count; selection code does not access outcome fields",
        "selection_is_post_hoc": True,
        "retrospective_preregistration": False,
        "unlabeled_test_support_used": True,
        "group": args.group,
        "group_count_requested": args.group_count,
        "min_support": args.min_support,
        "selected_groups": selected_rows,
        "split_dates": {"train_through": "2024-06-30", "test_start": "2025-01-01", "test_end": "2025-09-30"},
        "split_counts_without_outcome_access": {"all_rows": len(rows), "train": len(train), "test": len(test), "purged_train": len(retained_train), "heldout_test": len(heldout_test)},
        "selected_token_overlap_with_retained_train": selected_token_overlap,
        "all_token_overlap_with_retained_train": any_token_overlap,
        "hashes": {
            "protocol_sha256": hashlib.sha256(protocol_bytes).hexdigest(),
            "script_sha256": sha256(script_path),
            "model_rows_sha256": sha256(args.model_rows),
            "model_manifest_sha256": sha256(args.model_manifest),
            "input_reference_sha256": sha256(args.v3_input_reference),
            "v3_labels_sha256": sha256(args.v3_labels),
        },
    }
    selection_path = args.output_dir / "selection_manifest.json"
    write_json(selection_path, selection)
    selection_hash = sha256(selection_path)

    # Outcomes are first read here, after selection_manifest.json is sealed on disk.
    label_name = "outcome_" + OUTCOME
    for row in (*retained_train, *heldout_test):
        if label_name not in row:
            raise RuntimeError("primary_outcome_missing_after_selection")
        row["label"] = int(row[label_name])
    y_train = np.asarray([row["label"] for row in retained_train], dtype=int)
    y_test = np.asarray([row["label"] for row in heldout_test], dtype=int)
    if len(set(y_train.tolist())) != 2:
        raise RuntimeError("retained_train_lacks_both_classes_preserve_selection")
    if len(set(y_test.tolist())) != 2:
        raise RuntimeError("heldout_test_lacks_both_classes_preserve_selection")

    x_train, x_test = dict_matrix(retained_train, heldout_test, "full")
    scores = fit_probability(x_train, y_train, x_test)
    ids = np.asarray([row["cve_id"] for row in heldout_test])
    point_metrics = metrics(y_test, scores, ids)
    intervals = bootstrap(y_test, scores, ids, args.bootstrap_replicates, 20260930)
    n_test = len(y_test)
    positives = int(y_test.sum())
    capacity_10 = int(np.ceil(n_test * 0.10))
    prevalence = positives / n_test
    exact_random_r10 = capacity_10 / n_test

    pred_path = args.output_dir / "heldout_predictions_private.jsonl"
    pred_path.write_text(
        "".join(
            json.dumps({"cve_id": row["cve_id"], "t_obs": row["t_obs"], "label": int(y_test[i]), "score": float(scores[i])}, ensure_ascii=False) + "\n"
            for i, row in enumerate(heldout_test)
        ),
        encoding="utf-8",
    )

    report = {
        "run_id": args.run_id,
        "status": "completed",
        "protocol_sha256": hashlib.sha256(protocol_bytes).hexdigest(),
        "selection_manifest_sha256": selection_hash,
        "selection_manifest": "selection_manifest.json",
        "interpretation": "post hoc outcome-blind high-support-group sensitivity; not preregistered and not a population-level unseen-entity estimate",
        "outcome": OUTCOME,
        "model": "structured_cna",
        "model_specification": "DictVectorizer sparse structured features + LogisticRegression(C=1.0, max_iter=500, class_weight=balanced, solver=liblinear, random_state=20260906)",
        "split_counts": {
            "original_train": len(train),
            "retained_train": len(retained_train),
            "retained_train_positive": int(y_train.sum()),
            "heldout_test": n_test,
            "heldout_test_positive": positives,
            "test_prevalence": prevalence,
        },
        "group_overlap": {
            "selected_token_overlap_count": len(selected_token_overlap),
            "all_group_token_overlap_count": len(any_token_overlap),
            "all_group_token_overlap": any_token_overlap,
            "interpretation": "zero selected-token overlap is guaranteed by the purge; residual all-token overlap is reported separately and prevents a blanket claim that every group token is disjoint",
        },
        "within_set_baselines": {
            "constant_score_pr_auc_equals_prevalence": prevalence,
            "r10_capacity": capacity_10,
            "expected_random_r10": exact_random_r10,
        },
        "test_metrics": point_metrics,
        "row_stratified_bootstrap_95": intervals,
        "bootstrap_interpretation": "conditional on fixed heldout rows; not uncertainty over unseen groups",
        "prediction_artifact": {"path": pred_path.name, "classification": "private_local_only; not for redistribution", "sha256": sha256(pred_path)},
        "hashes": selection["hashes"],
        "python": sys.version,
        "platform": platform.platform(),
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    write_json(args.output_dir / "group_holdout_report.json", report)
    print(json.dumps({"run_id": args.run_id, "group": args.group, "heldout_n": n_test, "positives": positives, "pr_auc": point_metrics["pr_auc"], "r10": point_metrics["recall_at_10_pct"], "all_token_overlap_count": len(any_token_overlap)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
