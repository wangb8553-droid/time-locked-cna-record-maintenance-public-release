# Rights and attribution

## Project-authored code and protocol documentation

The project-authored code in src_v3/, the protocol files in protocol/, and the accompanying documentation and dependency lock are licensed under the MIT License in LICENSE. The clean-room runbook and path-neutral adapters are also identified in reproduction/RIGHTS_AND_ATTRIBUTION.md and reproduction/LICENSE.

## Aggregate outputs and third-party material

The aggregate result tables, figure source data, and rendered figures are supplied for access and inspection. They are not licensed under MIT, and this resource grants no separate reuse license for those outputs. The upstream CVE List V5 and CISA KEV histories and original record text are not redistributed; their terms remain independent of the project license.
