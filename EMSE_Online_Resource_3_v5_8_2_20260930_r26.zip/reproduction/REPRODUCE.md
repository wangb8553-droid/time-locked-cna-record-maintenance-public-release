# Reproducing the benchmark and revision-specific analyses

This runbook supplies the command order and local adapters used for the author-side clean-room reconstruction. It starts from the public, commit-pinned CVE List V5 and CISA KEV histories, rebuilds all record-level intermediates locally, and checks the published aggregate results. It does not require redistribution of original records, per-record labels, predictions, trajectories, or selected entity names.

The reconstruction is computational reproduction by the authors, not an external institutional replication or semantic validation. It does not establish that a signature addition means that the real affected software population expanded.

## Required material and privacy boundary

Obtain Online Resource 2, version 5.8.2-r14, and Online Resource 3 from the submission package. Extract each into a new, empty directory. The r14 source tree supplies the frozen V3/V5 code, tests, and dependency locks. Online Resource 3 supplies the post hoc group-holdout scripts and the path-neutral helper adapters under reproduction/helpers.

Use Git, Python 3.11.9, and separate output directories for each run. The full source histories are intentionally not bundled. Fetch them from their official repositories and pin the commits below. Do not use shallow clones.

All files named model_rows.jsonl, labels_v5_full_window.json, selection_manifest.json, heldout_predictions_private.jsonl, test_predictions.jsonl, or trajectory_v5_replay_audit.json contain record-level identifiers or other private intermediates. Keep them in a local working directory. Share only the sanitized aggregate summaries and source tables already supplied with the submission package.

The group sensitivity is post hoc. It selects tokens using unlabeled support in the fixed 2025 cohort after earlier holdout results were visible. It is not a probability sample of future entities.

## 1. Create a clean workspace and fetch frozen sources

Set PROJECT to the extracted Online Resource 2 directory and SUPPLEMENT to the extracted Online Resource 3 directory. Set WORK to a new empty directory. The commands below use PowerShell:

    $WORK = 'C:\research\cna-reproduction'
    $PROJECT = 'C:\research\inputs\online-resource-2'
    $SUPPLEMENT = 'C:\research\inputs\online-resource-3'
    $DATA = Join-Path $WORK 'upstream'
    $RUNS = Join-Path $WORK 'runs'
    if (Test-Path -LiteralPath $WORK) { throw 'Choose a new empty WORK directory.' }
    New-Item -ItemType Directory -Path $WORK | Out-Null
    New-Item -ItemType Directory -Path $DATA | Out-Null
    New-Item -ItemType Directory -Path $RUNS | Out-Null
    git clone https://github.com/CVEProject/cvelistV5.git (Join-Path $DATA 'cvelistV5')
    git -C (Join-Path $DATA 'cvelistV5') checkout --detach 1642a6b9bb01c7f4eb11801ee45f5bc929c00c16
    git -C (Join-Path $DATA 'cvelistV5') fsck --connectivity-only
    git clone https://github.com/cisagov/kev-data.git (Join-Path $DATA 'kev-data')
    git -C (Join-Path $DATA 'kev-data') checkout --detach ac9d37166471fbed6a03dff6c84f05e9c6b1d2c2
    git -C (Join-Path $DATA 'kev-data') fsck --connectivity-only

The CVE List V5 checkout must resolve to 1642a6b9bb01c7f4eb11801ee45f5bc929c00c16. The KEV repository checkout used for the reconstruction must resolve to ac9d37166471fbed6a03dff6c84f05e9c6b1d2c2; the descriptive catalog snapshot is commit 7b6be08055a42cf238a080745a3a2ff9f7e43ac5, dated 2025-12-29.

## 2. Install the pinned environment

Create an isolated environment and install the locks supplied with Online Resource 2:

    py -3.11 -m venv (Join-Path $WORK '.venv')
    $PY = Join-Path $WORK '.venv\Scripts\python.exe'
    & $PY -m pip install --upgrade pip
    & $PY -m pip install -r (Join-Path $PROJECT 'requirements-model.lock')
    & $PY -m pip install -r (Join-Path $PROJECT 'requirements-figure.lock')

The clean-room test attempt using only the model lock lacked the separately pinned plotting dependency and was preserved as an engineering failure. The successful test run used an isolated environment with both locks installed. Do not treat the failed attempt as a scientific result.

## 3. Rebuild the cohort and frozen V3 labels

The full-cohort builder writes asof_full_records.jsonl, asof_full_manifest.json, and cohort_counts.json. The label builder then writes the 90-day V3 label file:

    $COHORT = Join-Path $RUNS '01_asof_cohort'
    $LABELS = Join-Path $RUNS '02_v3_labels\v3_labels.json'
    & $PY (Join-Path $PROJECT 'src_v3\build_full_cohort_batch.py') --repo (Join-Path $DATA 'cvelistV5') --output-dir $COHORT
    & $PY (Join-Path $PROJECT 'src_v3\build_v3_labels.py') --repo (Join-Path $DATA 'cvelistV5') --asof-jsonl (Join-Path $COHORT 'asof_full_records.jsonl') --output $LABELS --dataset-freeze-time 2025-12-31T23:59:59Z

Expected checks: 77,218 cohort rows; cohort SHA-256 5ee5f90da014da1a362dda62d304e82e7563aa46a21ca125baf4ca5b3615447f. The V3 label SHA-256 is 7c99c4f740deed8cb8eb4f6f7cdf90f20a29ecb6729655b4fe295f0064c5f893. V3 status counts are defer 70,309, excluded 38, review 6,481, and withdraw 390. These are reconstruction checks, not independent evidence that the construct has semantic meaning.

## 4. Run and audit the two V5 full-window replays

Run the commit-order replay and the independent snapshot-difference replay, then compare both with the frozen V3 labels:

    $V5A = Join-Path $RUNS '05_v5_a'
    $V5B = Join-Path $RUNS '05_v5_b\labels_v5_full_window.json'
    $V5AUDIT = Join-Path $RUNS '05_v5_audit'
    & $PY (Join-Path $PROJECT 'src_v5\replay_v5_commit_order.py') --repo (Join-Path $DATA 'cvelistV5') --asof (Join-Path $COHORT 'asof_full_records.jsonl') --output-dir $V5A --run-id cleanroom_v5_commit_order
    & $PY (Join-Path $PROJECT 'src_v5\replay_v5_snapshot_diff.py') --repo (Join-Path $DATA 'cvelistV5') --asof (Join-Path $COHORT 'asof_full_records.jsonl') --output $V5B --run-id cleanroom_v5_snapshot_diff
    & $PY (Join-Path $PROJECT 'src_v5\audit_v5_replays.py') --a (Join-Path $V5A 'labels_v5_full_window.json') --b $V5B --v3 $LABELS --output-dir $V5AUDIT --run-id cleanroom_v5_replay_audit

Expected checks: 77,218 records from each implementation; zero replay mismatches; seven V3/V5 label differences, all terminal withdrawal rows; 24 withdrawn records with at least one further event after withdrawal but before the fixed 90-day endpoint; zero changes to eligible model rows. The audit writes record-level files, which must remain local.

## 5. Rebuild model inputs and the primary chronological results

Bind a fresh input reference to the reconstructed cohort and labels, then materialize the model rows:

    $REF = Join-Path $RUNS '03_v3_input_reference.json'
    $ROWS = Join-Path $RUNS '04_model_input\model_rows.jsonl'
    $MODEL_MANIFEST = Join-Path $RUNS '04_model_input\model_manifest.json'
    & $PY (Join-Path $SUPPLEMENT 'reproduction\helpers\cleanroom_reference_builder.py') --repo (Join-Path $DATA 'cvelistV5') --asof (Join-Path $COHORT 'asof_full_records.jsonl') --asof-manifest (Join-Path $COHORT 'asof_full_manifest.json') --labels $LABELS --output $REF --run-id cleanroom_reference
    & $PY (Join-Path $PROJECT 'src_v3\prepare_v3_model_dataset.py') --repo (Join-Path $DATA 'cvelistV5') --asof-jsonl (Join-Path $COHORT 'asof_full_records.jsonl') --v3-labels $LABELS --v3-input-reference $REF --output $ROWS --manifest $MODEL_MANIFEST --run-id cleanroom_model_input

Expected checks: 76,790 model rows and model-input SHA-256 4906ba5314364248c8521bb38a16bbacdceac010de44fadb17037c147572f093.

Run the full structured-CNA and identity-ablated profiles. Each formal run uses 2,000 bootstrap replicates and writes row-level predictions to its output directory:

    & $PY (Join-Path $PROJECT 'src_v3\run_v3_models.py') --model-rows $ROWS --model-manifest $MODEL_MANIFEST --v3-input-reference $REF --v3-labels $LABELS --outcome affected_field_structural_addition --profile full --output-dir (Join-Path $RUNS '06_primary_models_full') --run-id cleanroom_primary_full --bootstrap-replicates 2000
    & $PY (Join-Path $PROJECT 'src_v3\run_v3_models.py') --model-rows $ROWS --model-manifest $MODEL_MANIFEST --v3-input-reference $REF --v3-labels $LABELS --outcome affected_field_structural_addition --profile identity_ablated --output-dir (Join-Path $RUNS '07_identity_ablated') --run-id cleanroom_identity_ablated --bootstrap-replicates 2000

Expected primary test support is 26,103 rows and 2,428 events. The structured-CNA model should reproduce PR-AUC 0.662 and R@10% 0.773. The frozen test-prediction SHA-256 is 914aee5a49dc5bad2f3577e4315ca82cab6bd83c92dda211bc5f6fbaaafd27be. The paired full-minus-ablated structured PR-AUC difference is 0.174 (95% interval 0.158–0.190).

## 6. Recompute metric, tie-aware, and dependence checks

Using the primary run's test_predictions.jsonl and chronological_report.json:

    $PRIMARY = Join-Path $RUNS '06_primary_models_full'
    & $PY (Join-Path $PROJECT 'src_v3\audit_v3_prediction_metrics.py') --predictions (Join-Path $PRIMARY 'test_predictions.jsonl') --report (Join-Path $PRIMARY 'chronological_report.json') --output (Join-Path $PRIMARY 'independent_metric_audit.json') --run-id cleanroom_metric_audit
    & $PY (Join-Path $PROJECT 'src_v5\audit_v5_tie_aware_baselines.py') --predictions (Join-Path $PRIMARY 'test_predictions.jsonl') --output (Join-Path $PRIMARY 'tie_aware_baseline.json') --run-id cleanroom_tie_aware
    & $PY (Join-Path $PROJECT 'src_v3\bootstrap_v3_cluster_sensitivity.py') --predictions (Join-Path $PRIMARY 'test_predictions.jsonl') --model-rows $ROWS --grouping month --replicates 2000 --output (Join-Path $RUNS '11_cluster_month.json') --run-id cleanroom_month_cluster
    & $PY (Join-Path $PROJECT 'src_v3\bootstrap_v3_cluster_sensitivity.py') --predictions (Join-Path $PRIMARY 'test_predictions.jsonl') --model-rows $ROWS --grouping cna_group --replicates 2000 --output (Join-Path $RUNS '11_cluster_cna.json') --run-id cleanroom_cna_cluster

Expected tie-aware R@10% for random selection is approximately 0.10003. The expected value is deterministic; a hypergeometric interval describes one random selection. The fixed-row PR-AUC interval is 0.641–0.683; the month-cluster interval is 0.558–0.734; the CNA-group interval is 0.073–0.812. These resampling units answer different questions and do not establish future-year or unseen-entity performance.

## 7. Re-run the post hoc, outcome-blind entity sensitivities

For each of vendor, product, and CNA, select up to 20 tokens with support of at least 10 in the fixed 2025 test cohort, without reading labels. Then bind the newly generated selection-manifest hashes into a local copy of the strict-purge protocol and run the all-token purge:

    $SELECTOR = Join-Path $SUPPLEMENT 'src_v3\run_v3_group_holdout_outcomeblind.py'
    $PURGER = Join-Path $SUPPLEMENT 'src_v3\run_v3_group_holdout_full_token_purge.py'
    $SELECTIONS = @{}
    foreach ($g in @('vendor','product','cna')) {
      $s = Join-Path $RUNS ('08_select_' + $g)
      & $PY $SELECTOR --model-rows $ROWS --model-manifest $MODEL_MANIFEST --v3-input-reference $REF --v3-labels $LABELS --protocol (Join-Path $SUPPLEMENT 'protocol\protocol_addendum_group_holdout_outcomeblind_20260930.md') --group $g --output-dir $s --run-id ('cleanroom_select_' + $g)
      $SELECTIONS[$g] = Join-Path $s 'selection_manifest.json'
    }
    $BOUND_PROTOCOL = Join-Path $RUNS '09_strict_purge_protocol.json'
    & $PY (Join-Path $SUPPLEMENT 'reproduction\helpers\cleanroom_purge_protocol_builder.py') --frozen-protocol (Join-Path $SUPPLEMENT 'protocol\protocol_addendum_group_holdout_full_token_purge_20260930.json') --vendor-selection $SELECTIONS.vendor --product-selection $SELECTIONS.product --cna-selection $SELECTIONS.cna --output $BOUND_PROTOCOL
    foreach ($g in @('vendor','product','cna')) {
      $s = Join-Path $RUNS ('08_select_' + $g)
      $o = Join-Path $RUNS ('10_group_' + $g + '_strict_purge')
      & $PY $PURGER --model-rows $ROWS --model-manifest $MODEL_MANIFEST --v3-input-reference $REF --v3-labels $LABELS --protocol $BOUND_PROTOCOL --selection-manifest (Join-Path $s 'selection_manifest.json') --group $g --bootstrap-replicates 2000 --output-dir $o --run-id ('cleanroom_strict_purge_' + $g)
    }

Expected remaining all-token train/test overlap is zero for all three groups. Expected held-out summaries are vendor n=9,352, 2,099 events, PR-AUC 0.580, R@10% 0.263; product n=3,861, 1,750 events, PR-AUC 0.561, R@10% 0.094; CNA n=20,701, 2,183 events, PR-AUC 0.557, R@10% 0.665. The product partition prevalence is 0.453 and random R@10% expectation is 0.1002. Do not publish selection manifests or held-out prediction files.

## 8. Rebuild descriptive checks, tables, and figures

Run the public KEV audit only after model predictions and thresholds are frozen, with the KEV repository and snapshot commit above. Run the V5 taxonomy transformation from the two full-window replay labels and the reconstructed cohort. These outputs are descriptive and do not alter the primary labels or model.

The path-neutral adapters under reproduction/helpers perform only schema conversion, aggregate-source-table construction, plotting, and final checks. They do not fit models or change metrics. Use:

- cleanroom_normalize_holdout_reports.py to copy aggregate PR-AUC estimates into the renderer's expected schema; it performs no metric recomputation.
- cleanroom_build_figure_source_data.py for the yearly cohort and primary-model source tables.
- cleanroom_plot_figure3_fixed_budget.py for the fixed-budget capture and omission figure.
- the released plot_r22_transfer_figures.py for identity, dependence, temporal, and holdout figures.
- cleanroom_plot_figure6.py for construct taxonomy and identity-ablation effects.
- cleanroom_final_audit.py after creating the run subdirectories named in the preceding steps.

All adapters expose their required arguments with --help. Use a new output directory for every invocation. The final author-side audit should report 16 of 16 checks passed, six manuscript figures, and no numerical differences in the independent metric audit. Re-render and inspect the final figures and manuscript before submission.

## 9. Test suites and interpretation

Two test counts are reported because they refer to different archived code versions and test frameworks. Online Resource 2 version 5.8.2-r14 records 18 pytest tests passed (14 warnings) in RELEASE_AUDIT.json. The clean-room run used the earlier version 5.8.2-r11 source suite and passed 16 unittest tests. These are distinct suite scopes, not contradictory counts; both test implementation behavior, not semantic label validity.

To repeat the r14 archived test suite from the extracted project directory:

    Set-Location $PROJECT
    & $PY -m pytest -q -p no:cacheprovider tests

No public repository, Zenodo deposit, identifier, or remote release is updated by following this runbook. Keep all regenerated record-level intermediates private.
