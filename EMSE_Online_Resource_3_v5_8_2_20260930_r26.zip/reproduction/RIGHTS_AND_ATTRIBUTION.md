# Rights and attribution for Online Resource 3 reproduction materials

The following project-authored files in this Online Resource 3 are licensed under the MIT License included in this directory:

- reproduction/REPRODUCE.md
- reproduction/helpers/*.py

This license does not cover the CVE List V5 or CISA KEV records, third-party text, upstream repositories, aggregate source tables, or figure outputs. Their rights and reuse conditions remain separate. No original record-level data or upstream Git history is redistributed here.
