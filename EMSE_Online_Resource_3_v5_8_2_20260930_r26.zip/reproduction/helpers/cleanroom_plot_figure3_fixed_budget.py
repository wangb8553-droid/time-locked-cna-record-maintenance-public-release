from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans", "Liberation Sans"],
    "font.size": 7,
    "axes.labelsize": 7,
    "axes.linewidth": 0.75,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "legend.frameon": False,
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
})


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--independent-audit", type=Path, required=True)
    p.add_argument("--tie-aware-baseline", type=Path, required=True)
    p.add_argument("--predictions", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    a = p.parse_args()
    a.output_dir.mkdir(parents=True, exist_ok=False)
    audit = json.loads(a.independent_audit.read_text(encoding="utf-8"))
    tie = json.loads(a.tie_aware_baseline.read_text(encoding="utf-8"))
    model = audit["recomputed"]["structured_cna"]["metrics"]
    n, positives = model["record_count"], model["positive_count"]
    rows = []
    budgets = (5, 10, 20)
    for pct in budgets:
        key = str(pct)
        cap = model[f"capacity_at_{key}_pct"]
        missed = model[f"false_deferral_at_{key}_pct"]
        rand = tie["baselines"]["prevalence"][key]
        rows.append({
            "budget_percent": pct,
            "selected_records": cap,
            "cohort_records": n,
            "events_total": positives,
            "structured_caught": positives - missed,
            "structured_missed": missed,
            "missed_over_all_events": missed / positives,
            "event_rate_among_deferred": model["risk_coverage"][budgets.index(pct)]["deferred_risk"],
            "random_expected_caught": rand["expected_caught"],
        })
    source = a.output_dir / "Fig3_fixed_budget_capture_source_data.csv"
    with source.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    fig, axes = plt.subplots(1, 2, figsize=(6.85, 2.2), layout="constrained")
    x = np.arange(len(budgets))
    ax = axes[0]
    width = 0.34
    caught = [r["structured_caught"] for r in rows]
    random = [r["random_expected_caught"] for r in rows]
    ax.bar(x - width / 2, caught, width, color="#145DA0", label="Structured CNA")
    ax.bar(x + width / 2, random, width, color="#B8B8B8", label="Random tie-aware expectation")
    ax.set_xticks(x, [f"{p}%" for p in budgets])
    ax.set_ylabel("Events captured")
    ax.legend(fontsize=6, loc="upper left")
    for i, row in enumerate(rows):
        ax.text(i - width / 2, row["structured_caught"] + 35, f"{row['structured_caught']:,}", ha="center", fontsize=6)
        ax.text(i + width / 2, row["random_expected_caught"] + 35, f"{row['random_expected_caught']:.0f}", ha="center", fontsize=6)
    ax.text(-0.15, 1.04, "a", transform=ax.transAxes, fontweight="bold", fontsize=8)

    ax = axes[1]
    miss_pct = [100 * r["missed_over_all_events"] for r in rows]
    deferred_rate = [100 * r["event_rate_among_deferred"] for r in rows]
    ax.plot(budgets, miss_pct, marker="o", color="#B64342", lw=1.4, label="Missed / all events")
    ax.plot(budgets, deferred_rate, marker="s", color="#3D8E9B", lw=1.4, label="Event rate among deferred")
    ax.set_xticks(budgets, [f"{p}%" for p in budgets])
    ax.set_xlabel("Review capacity")
    ax.set_ylabel("Percent")
    ax.legend(fontsize=6, loc="upper right")
    for xx, yy in zip(budgets, miss_pct):
        ax.annotate(f"{yy:.1f}%", (xx, yy), xytext=(0, 5), textcoords="offset points", ha="center", fontsize=6)
    for xx, yy in zip(budgets, deferred_rate):
        ax.annotate(f"{yy:.2f}%", (xx, yy), xytext=(0, 8), textcoords="offset points", ha="center", fontsize=6)
    ax.text(-0.15, 1.04, "b", transform=ax.transAxes, fontweight="bold", fontsize=8)

    stem = a.output_dir / "Fig3_fixed_budget_capture"
    outputs = []
    for suffix, kwargs in (("svg", {}), ("pdf", {}), ("tiff", {"dpi": 600, "pil_kwargs": {"compression": "tiff_lzw"}}), ("png", {"dpi": 300})):
        path = stem.with_suffix("." + suffix)
        fig.savefig(path, bbox_inches="tight", **kwargs)
        outputs.append(path)
    plt.close(fig)
    qa = {}
    for path in outputs:
        if path.suffix == ".svg":
            text_count = path.read_text(encoding="utf-8").count("<text")
            if text_count < 10:
                raise RuntimeError("noneditable_svg_text")
            qa[path.name] = {"editable_text_nodes": text_count}
        elif path.suffix == ".png":
            pixels = np.asarray(Image.open(path).convert("RGB"))
            nonwhite = float((pixels < 245).any(axis=2).mean())
            if min(pixels.shape[:2]) < 500 or nonwhite <= 0.01:
                raise RuntimeError("figure_png_visual_check_failed")
            qa[path.name] = {"shape": list(pixels.shape), "nonwhite_fraction": nonwhite}
        else:
            qa[path.name] = {"bytes": path.stat().st_size}
    manifest = {
        "run_id": a.output_dir.name,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "Manuscript Figure 3 fixed-budget capture and omission rebuilt from clean-room predictions and tie-aware analytic baseline.",
        "inputs": {path.name: {"sha256": sha(path), "bytes": path.stat().st_size} for path in (a.independent_audit, a.tie_aware_baseline, a.predictions)},
        "outputs": {path.name: {"sha256": sha(path), "bytes": path.stat().st_size} for path in [source, *outputs]},
        "qa": qa,
        "privacy_boundary": "The exported source table contains only aggregate counts and rates; row-level predictions remain local.",
    }
    (a.output_dir / "figure3_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": a.output_dir.name, "selected": [r["selected_records"] for r in rows], "captured": caught, "missed": [r["structured_missed"] for r in rows]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
