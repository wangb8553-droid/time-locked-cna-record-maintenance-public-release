"""Create a clean-room run binding for the frozen strict-purge rule."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--frozen-protocol", type=Path, required=True)
    parser.add_argument("--vendor-selection", type=Path, required=True)
    parser.add_argument("--product-selection", type=Path, required=True)
    parser.add_argument("--cna-selection", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"output_exists:{args.output}")

    base = json.loads(args.frozen_protocol.read_text(encoding="utf-8"))
    protocol = copy.deepcopy(base)
    expected_selection_rule = "test-cohort support >= min_support; sort by descending support then ascending token; first group_count; selection code does not access outcome fields"
    current = {
        "vendor": args.vendor_selection,
        "product": args.product_selection,
        "cna": args.cna_selection,
    }
    checks = {}
    for group, path in current.items():
        selection = json.loads(path.read_text(encoding="utf-8"))
        checks[group] = (
            selection.get("group") == group
            and selection.get("selection_is_post_hoc") is True
            and selection.get("selection_rule") == expected_selection_rule
            and selection.get("group_count_requested") == base.get("selection_rule_parameters", {}).get("group_count", 20)
            and selection.get("min_support") == base.get("selection_rule_parameters", {}).get("min_support", 10)
        )
        protocol["selection_manifests"][group] = {
            "run_id": selection["run_id"],
            "sha256": digest(path),
        }
    protocol["cleanroom_execution_note"] = {
        "source_frozen_protocol_sha256": digest(args.frozen_protocol),
        "selection_manifests_rederived_from_cleanroom_model_inputs": True,
        "selection_protocol_rules_unchanged": True,
        "selection_manifest_hashes_rebound_for_this_run": True,
        "selection_manifest_sha256": {group: digest(path) for group, path in current.items()},
        "note": "Original private selection manifests are not included in the public supplement; this run binds freshly regenerated, outcome-blind manifests to the same frozen selection rule before strict-purge model fits.",
    }
    protocol["cleanroom_execution_checks"] = checks
    if not all(checks.values()):
        raise SystemExit(f"selection_manifest_check_failed:{checks}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(protocol, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"checks": checks, "cleanroom_protocol_sha256": digest(args.output)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
