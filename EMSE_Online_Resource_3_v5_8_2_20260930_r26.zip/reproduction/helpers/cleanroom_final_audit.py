from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--run-id", required=True)
    a = p.parse_args()
    root = a.root
    runs = root / "runs"
    cohort = runs / "01_asof_cohort" / "asof_full_records.jsonl"
    labels = runs / "02_v3_labels" / "v3_labels.json"
    model_rows = runs / "04_model_input" / "model_rows.jsonl"
    primary = read(runs / "06_primary_models_full" / "chronological_report.json")
    metric_audit = read(runs / "06_primary_models_full" / "independent_metric_audit.json")
    tie = read(runs / "06_primary_models_full" / "tie_aware_baseline.json")
    identity = read(runs / "07_identity_ablated" / "chronological_report.json")
    delta = read(runs / "14_profile_delta" / "profile_delta.json")
    v5 = read(runs / "05_v5_audit" / "trajectory_v5_replay_audit.json")
    v5_decision = read(runs / "05_v5_decision" / "v5_decision.json")
    month = read(runs / "11_cluster_month.json")
    cna = read(runs / "11_cluster_cna.json")
    kev = read(runs / "12_kev_descriptive" / "kev_descriptive.json")
    taxonomy = read(runs / "13_taxonomy" / "taxonomy.json")
    taxonomy_audit = read(runs / "13_taxonomy" / "taxonomy_audit.json")
    tests = read(runs / "20_unit_tests_r02" / "test_audit.json")
    holds = {}
    for group in ("vendor", "product", "cna"):
        holds[group] = read(runs / f"10_group_{group}_strict_purge" / "group_holdout_report.json")
    figure12_manifest = read(runs / "16_figures_1_3_r02" / "figure_manifest.json")
    figure3_manifest = read(runs / "22_figure3_fixed_budget_r02" / "figure3_manifest.json")
    figure45_manifest = read(runs / "17_figures_4_5" / "figure_revision_manifest.json")
    figure6_manifest = read(runs / "18_figure6" / "figure6_manifest.json")
    figure12 = {key: value for key, value in figure12_manifest["outputs"].items() if key.startswith(("figure_1_", "figure_2_"))}
    figures = {"figures_1_2": figure12, "figure_3": figure3_manifest["outputs"],
               "figures_4_5": figure45_manifest["outputs"], "figure_6": figure6_manifest["outputs"]}
    checks = {
        "cohort_hash_matches_frozen": sha(cohort) == "5ee5f90da014da1a362dda62d304e82e7563aa46a21ca125baf4ca5b3615447f",
        "label_hash_matches_frozen": sha(labels) == "7c99c4f740deed8cb8eb4f6f7cdf90f20a29ecb6729655b4fe295f0064c5f893",
        "model_input_hash_matches_frozen": sha(model_rows) == "4906ba5314364248c8521bb38a16bbacdceac010de44fadb17037c147572f093",
        "v5_double_replay_passed": v5["passed"] and v5["replay_mismatch_count"] == 0,
        "v5_decision_rule_applied": v5_decision["decision"] == "retain_v3_model_results_with_v5_full_window_sensitivity",
        "primary_formal_2000_bootstrap": primary["formal"] and primary["bootstrap_replicates"] == 2000,
        "independent_metric_audit_passed": metric_audit["passed"],
        "tie_aware_baseline_passed": tie["passed"] and tie["expected_recall_is_deterministic"],
        "identity_ablation_formal_2000_bootstrap": identity["formal"] and identity["bootstrap_replicates"] == 2000,
        "profile_delta_matches_frozen_source": all(abs(delta["models"][m]["point_pr_auc_difference_full_minus_ablated"] - want) < 1e-12 for m, want in (("structured_cna", .1743767623430713), ("fused_tfidf_structured", .03300889330961765), ("tfidf_word_character", 0.0))),
        "cluster_bootstraps_passed": month["passed"] and cna["passed"] and month["bootstrap_replicates_requested"] == 2000 and cna["bootstrap_replicates_requested"] == 2000,
        "group_holdouts_passed_all_token_disjointness": all(h["status"] == "completed" and h["all_token_disjointness"]["train_test_overlap_count_after_purge"] == 0 for h in holds.values()),
        "kev_snapshot_descriptive_counts_match": [x["selected_kev_count"] for x in kev["capacities"]] == [6, 21, 54] and kev["capacities"][0]["cohort_kev_count"] == 115,
        "taxonomy_passed_and_counts_match": taxonomy_audit["passed"] and taxonomy["event_count"] == 10268 and taxonomy["counts"]["version_or_range_rewrite_semantic_comparability_not_assessed"] == 8452,
        "unit_suite_passed": tests["status"] == "passed" and tests["tests_run"] == 16,
        "manuscript_figures_1_to_6_rebuilt_and_visual_qa_recorded": len(figures["figures_1_2"]) == 8 and len(figures["figure_3"]) == 5 and len(figures["figures_4_5"]) == 8 and len(figures["figure_6"]) == 4,
    }
    payload = {
        "run_id": a.run_id,
        "scope": "author-side clean-room reproduction from fresh source checkout and isolated environments; not external institutional replication",
        "working_directory": ".",
        "source_commit_pins": {
            "cvelistV5_clone_head": "1642a6b9bb01c7f4eb11801ee45f5bc929c00c16",
            "cisa_kev_catalog_snapshot": kev["kev_snapshot"]["commit"],
        },
        "reconstructed_artifacts": {
            "cohort": {"rows": 77218, "sha256": sha(cohort)},
            "labels": {"sha256": sha(labels), "eligible_structural_events": 6378, "cvss_escalations": 149, "withdrawals": 390},
            "model_rows": {"rows": 76790, "sha256": sha(model_rows)},
            "primary_test_predictions": {"rows": primary["split_counts"]["test"], "positives": primary["split_counts"]["test_positive"], "sha256": primary["test_predictions_sha256"]},
            "v5_replay": {"records_per_implementation": v5["source_id_counts"], "mismatches": v5["replay_mismatch_count"], "v3_v5_differences": v5["v3_v5_difference_count"], "withdrawals_with_post_change": v5["withdrawals_with_post_change"]},
            "groups": {k: {"records": h["split_counts"]["heldout_test"], "positives": h["split_counts"]["heldout_test_positive"], "pr_auc": h["test_metrics"]["pr_auc"], "r10": h["test_metrics"]["recall_at_10_pct"], "remaining_token_overlap": h["all_token_disjointness"]["train_test_overlap_count_after_purge"]} for k, h in holds.items()},
            "taxonomy": taxonomy["counts"],
            "kev_selected_counts_at_5_10_20_percent": [x["selected_kev_count"] for x in kev["capacities"]],
            "tests": {"count": tests["tests_run"], "status": tests["status"]},
            "figures": {k: len(v) for k, v in figures.items()},
        },
        "checks": checks,
        "passed": all(checks.values()),
        "privacy_boundary": "Row-level records, labels, predictions, and selected-token manifests remain local and are not part of any public release.",
        "public_release_authorized": False,
    }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": payload["passed"], "checks_passed": sum(checks.values()), "checks_total": len(checks), "output_file": a.output.name}))
    return 0 if payload["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
