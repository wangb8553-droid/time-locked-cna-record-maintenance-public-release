from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans", "Liberation Sans"],
    "font.size": 7,
    "axes.labelsize": 7,
    "axes.linewidth": 0.75,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "legend.frameon": False,
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
})


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--taxonomy", type=Path, required=True)
    p.add_argument("--profile-delta", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    a = p.parse_args()
    a.output_dir.mkdir(parents=True, exist_ok=False)
    taxonomy = json.loads(a.taxonomy.read_text(encoding="utf-8"))
    delta = json.loads(a.profile_delta.read_text(encoding="utf-8"))
    fig, axes = plt.subplots(1, 2, figsize=(6.85, 2.15), layout="constrained",
                             gridspec_kw={"width_ratios": [1.1, 1.5]})
    ax = axes[0]
    labels = ["New vendor/product", "Version/range rewrite\n(comparability not assessed)", "Other JSON\nstructural change"]
    keys = ["new_vendor_or_product", "version_or_range_rewrite_semantic_comparability_not_assessed", "other_json_structural_change"]
    vals = [taxonomy["counts"][k] for k in keys]
    colors = ["#145DA0", "#777777", "#3D8E9B"]
    y = np.arange(len(vals))
    ax.barh(y, vals, color=colors, height=0.62)
    ax.set_yticks(y, labels, fontsize=6)
    ax.invert_yaxis()
    ax.set_xlabel("Observed structural events")
    for yi, v in zip(y, vals):
        ax.text(v + max(vals) * 0.018, yi, f"{v:,}", va="center", fontsize=6)
    ax.set_xlim(0, max(vals) * 1.22)
    ax.text(-0.15, 1.04, "a", transform=ax.transAxes, fontweight="bold", fontsize=8)

    ax = axes[1]
    models = ["structured_cna", "fused_tfidf_structured", "tfidf_word_character"]
    names = ["Structured CNA", "Fusion", "TF-IDF text"]
    colors = ["#145DA0", "#8E5A8C", "#3D8E9B"]
    vals = [delta["models"][m]["point_pr_auc_difference_full_minus_ablated"] for m in models]
    ci = [delta["models"][m]["paired_bootstrap_95"] for m in models]
    y = np.arange(len(vals))
    for yi, v, bounds, color in zip(y, vals, ci, colors):
        ax.errorbar(v, yi, xerr=[[v - bounds["lower_95"]], [bounds["upper_95"] - v]],
                    fmt="o", color=color, capsize=2, lw=1, ms=4)
    ax.axvline(0, color="#777777", lw=0.8, ls="--")
    ax.set_yticks(y, names, fontsize=6)
    ax.invert_yaxis()
    ax.set_xlabel("Full minus identity-ablated PR-AUC (95% paired CI)")
    ax.text(-0.12, 1.04, "b", transform=ax.transAxes, fontweight="bold", fontsize=8)

    stem = a.output_dir / "figure_6_construct_and_identity"
    outputs = []
    for suffix, kwargs in (("svg", {}), ("pdf", {}), ("tiff", {"dpi": 600, "pil_kwargs": {"compression": "tiff_lzw"}}), ("png", {"dpi": 300})):
        path = stem.with_suffix("." + suffix)
        fig.savefig(path, bbox_inches="tight", **kwargs)
        outputs.append(path)
    plt.close(fig)
    qa = {}
    for path in outputs:
        if path.suffix == ".svg":
            text_nodes = len(re.findall(r"<text(?:\s|>)", path.read_text(encoding="utf-8")))
            if text_nodes < 10:
                raise RuntimeError(f"svg_text_not_editable: {text_nodes}")
            qa[path.name] = {"editable_text_nodes": text_nodes}
        elif path.suffix == ".png":
            image = np.asarray(Image.open(path).convert("RGB"))
            nonwhite = float((image < 245).any(axis=2).mean())
            if min(image.shape[:2]) < 500 or nonwhite <= 0.01:
                raise RuntimeError(f"png_visual_qa_failed: {path.name}")
            qa[path.name] = {"shape": list(image.shape), "nonwhite_fraction": nonwhite}
        else:
            qa[path.name] = {"bytes": path.stat().st_size}
    manifest = {
        "run_id": a.output_dir.name,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "inputs": {path.name: {"bytes": path.stat().st_size, "sha256": sha(path)} for path in (a.taxonomy, a.profile_delta)},
        "outputs": {path.name: {"bytes": path.stat().st_size, "sha256": sha(path)} for path in outputs},
        "qa": qa,
        "claim_boundary": taxonomy.get("boundary"),
        "final_release_authorized": False,
    }
    (a.output_dir / "figure6_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": a.output_dir.name, "files": len(outputs), "qa_passed": True}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
