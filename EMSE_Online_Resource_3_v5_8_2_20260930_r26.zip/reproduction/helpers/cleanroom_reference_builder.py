"""Build a run-local V3 input-reference gate from clean-room artifacts.

This is a compatibility adapter for the released preparation/model scripts.
It does not import or reuse any pre-existing input-reference manifest.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


SCOPE = "time_locked_cna_affected_field_structural_addition_v3"
EXPECTED_COHORT_ROWS = 77218
EXPECTED_STATUS = {"defer": 70309, "excluded": 38, "review": 6481, "withdraw": 390}
EXPECTED_OUTCOMES = {
    "affected_field_structural_addition": 6378,
    "cna_cvss_escalation_to_high": 149,
    "overlap": 46,
    "union": 6481,
}
EXPECTED_HEAD = "1642a6b9bb01c7f4eb11801ee45f5bc929c00c16"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo), *args], capture_output=True, text=True,
        encoding="utf-8", errors="replace", check=True,
    )
    return result.stdout.strip()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--asof", type=Path, required=True)
    parser.add_argument("--asof-manifest", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"output_exists:{args.output}")

    asof_manifest = json.loads(args.asof_manifest.read_text(encoding="utf-8"))
    labels = json.loads(args.labels.read_text(encoding="utf-8"))
    head = git(args.repo, "rev-parse", "HEAD")
    shallow = git(args.repo, "rev-parse", "--is-shallow-repository")
    asof_hash, label_hash = sha256(args.asof), sha256(args.labels)
    checks = {
        "frozen_head_matches": head == EXPECTED_HEAD,
        "repository_is_not_shallow": shallow == "false",
        "cohort_hash_matches_its_manifest": asof_manifest.get("records_sha256") == asof_hash,
        "cohort_count_matches": asof_manifest.get("selected_count") == EXPECTED_COHORT_ROWS,
        "cohort_manifest_head_matches": asof_manifest.get("repo_head") == head,
        "labels_bind_rebuilt_cohort": labels.get("source_asof_jsonl_sha256") == asof_hash,
        "label_builder_is_v3": labels.get("run_type") == "time_locked_cna_structural_addition_and_cvss_labels_v3",
        "label_horizon_is_90_days": labels.get("horizon_days") == 90,
        "label_status_counts_match": labels.get("status_counts") == EXPECTED_STATUS,
        "eligible_outcome_counts_match": labels.get("outcome_counts_eligible") == EXPECTED_OUTCOMES,
    }
    passed = all(checks.values())
    reference = {
        "run_id": args.run_id,
        "reference_kind": "independent_cleanroom_gate_not_prior_run_manifest",
        "scope": SCOPE,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "passed": passed,
        "asof_sha256": asof_hash,
        "v3_labels_sha256": label_hash,
        "source_alias": "CVE List V5",
        "cve_repo_head": head,
        "artifact_sha256": {
            "asof_full_records.jsonl": asof_hash,
            "asof_full_manifest.json": sha256(args.asof_manifest),
            "v3_labels.json": label_hash,
        },
        "cleanroom_checks": checks,
        "constraints": [
            "Reconstructed source cohort and V3 labels are hash-bound in this run.",
            "This adapter does not assert historical V1/V2 audit artifacts were independently rerun.",
            "Affected-field structural addition is not semantic affected-range expansion.",
            "Provider metadata remains evaluation-only and is not a model feature.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(reference, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": passed, "checks": checks, "asof_sha256": asof_hash, "labels_sha256": label_hash}, ensure_ascii=False))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
