from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def dump_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--cohort-counts", type=Path, required=True)
    p.add_argument("--labels", type=Path, required=True)
    p.add_argument("--report", type=Path, required=True)
    p.add_argument("--tie-aware", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    a = p.parse_args()
    a.output_dir.mkdir(parents=True, exist_ok=False)
    cohort = json.loads(a.cohort_counts.read_text(encoding="utf-8"))
    labels = json.loads(a.labels.read_text(encoding="utf-8"))
    report = json.loads(a.report.read_text(encoding="utf-8"))
    tie = json.loads(a.tie_aware.read_text(encoding="utf-8"))
    years = []
    for year, item in sorted(cohort["by_publication_year"].items()):
        lab = labels["outcome_counts_by_cohort_year"][year]
        n = lab["eligible"]
        positives = lab["affected_field_structural_addition"]
        years.append({
            "cohort_year": year,
            "source_count": item["selected"],
            "eligible_count": n,
            "structural_addition": positives,
            "structural_event_rate": positives / n,
        })
    dump_csv(a.output_dir / "table1_yearly_cohort.csv", years)

    model_order = ["prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured"]
    metrics = []
    for name in model_order:
        model = report["test_models"][name]
        m = model["metrics"]
        ci = model.get("bootstrap_95", {})
        pr_ci = ci.get("pr_auc", {"lower_95": m["pr_auc"], "upper_95": m["pr_auc"]})
        brier_ci = ci.get("brier", {"lower_95": m["brier"], "upper_95": m["brier"]})
        ece_ci = ci.get("ece_10", {"lower_95": m["ece_10"], "upper_95": m["ece_10"]})
        row = {
            "model": name,
            "record_count": report["split_counts"]["test"],
            "positive_count": report["split_counts"]["test_positive"],
            "pr_auc": m["pr_auc"], "pr_auc_lower_95": pr_ci["lower_95"], "pr_auc_upper_95": pr_ci["upper_95"],
            "brier": m["brier"], "brier_lower_95": brier_ci["lower_95"], "brier_upper_95": brier_ci["upper_95"],
            "ece_10": m["ece_10"], "ece_10_lower_95": ece_ci["lower_95"], "ece_10_upper_95": ece_ci["upper_95"],
            "recall_at_5_pct": m["recall_at_5_pct"], "recall_at_10_pct": m["recall_at_10_pct"], "recall_at_20_pct": m["recall_at_20_pct"],
        }
        if name in tie["baselines"]:
            for k, field in [("5", "recall_at_5_pct"), ("10", "recall_at_10_pct"), ("20", "recall_at_20_pct")]:
                row[field] = tie["baselines"][name][k]["expected_recall"]
        metrics.append(row)
    dump_csv(a.output_dir / "table2_primary_metrics.csv", metrics)
    print(json.dumps({"year_rows": len(years), "model_rows": len(metrics), "output_directory_name": a.output_dir.name}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
