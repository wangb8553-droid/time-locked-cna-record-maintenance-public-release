from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--inputs", type=Path, nargs=3, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    a = p.parse_args()
    a.output_dir.mkdir(parents=True, exist_ok=False)
    for src in a.inputs:
        report = json.loads(src.read_text(encoding="utf-8"))
        metric = report["test_metrics"]
        ci = report["row_stratified_bootstrap_95"]
        adapted = {
            "run_id": report["run_id"],
            "group": report["group"],
            "status": report["status"],
            "test_models": {
                "structured_cna": {
                    "metrics": {"pr_auc": metric["pr_auc"]},
                    "bootstrap_95": {"pr_auc": ci["pr_auc"]},
                }
            },
            "adaptation_note": "Visualization adapter only; values copied from the clean-room group_holdout_report.json without model or metric recomputation.",
        }
        (a.output_dir / f"{report['group']}_plot_adapter.json").write_text(
            json.dumps(adapted, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    print(json.dumps({"adapted_report_count": len(a.inputs), "output_directory_name": a.output_dir.name}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
