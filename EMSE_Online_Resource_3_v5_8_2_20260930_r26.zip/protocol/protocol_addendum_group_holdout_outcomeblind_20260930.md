# Protocol addendum: outcome-blind group holdout sensitivity

**Status:** frozen for the new run below; written after the earlier group-holdout results were visible. This is not a retrospective preregistration and must be reported as a post hoc, outcome-blind sensitivity analysis.

## Question and scope

Re-evaluate the existing V3 primary endpoint, `affected_field_structural_addition`, under vendor-, product-, and CNA-group holdouts whose selected identities are chosen without consulting outcome labels. This does not replace the fixed chronological primary evaluation and does not change its labels, cohort, features, or predictions.

## Frozen rules

- Use the hash-bound V3 model rows and the existing train/test dates: training observations through 2024-06-30; test observations from 2025-01-01 through 2025-09-30.
- For each grouping variable (`vendor`, `product`, `cna`), count each non-missing token in the 2025 test cohort without reading any outcome field.
- Eligible tokens have test-cohort support of at least 10 records. Select the first 20 tokens after sorting by decreasing support and then ascending token string. If fewer than 20 are eligible, select all eligible tokens. This is deterministic and outcome-blind, but uses unlabeled test-cohort support; it is not a random sample of entities.
- A test record is held out if it carries any selected token. A training record is purged if it carries any selected token. Do not change or replace selected tokens after inspecting labels or scores.
- Report both (a) overlap of the selected tokens with retained training records (which must be zero by construction) and (b) overlap of all tokens carried by held-out test records with all tokens carried by retained training records. Do not call the latter zero unless measured.
- Fit only the existing full structured-CNA logistic-regression model. Preserve its V3 feature construction and settings. Report test support, positives, prevalence, PR-AUC relative to the within-set prevalence baseline, R@10% relative to the exact random-selection expectation, and 2,000 row-stratified bootstrap intervals.
- Row-bootstrap intervals are conditional on the selected fixed records. They are not uncertainty intervals for arbitrary unseen groups or future populations.

## Interpretation boundary

Because this addendum was devised after prior results were visible, it cannot establish confirmatory evidence or retrospective preregistration. It can reveal whether the reported transfer limitation persists under a deterministic selection rule that does not use outcomes. The selection is still based on unlabeled support in the fixed test cohort, so claims must remain limited to this benchmark and selected high-support groups.

## Run identity

The run-family ID is `group_holdout_outcome_blind_v3_primary_20260930_r01`; its three subrun IDs are `group_holdout_outcome_blind_v3_primary_vendor_20260930_r01`, `group_holdout_outcome_blind_v3_primary_product_20260930_r01`, and `group_holdout_outcome_blind_v3_primary_cna_20260930_r01`. Any engineering repair must preserve these first-attempt directories and use a new run-family/subrun ID. A scientifically unestimable result is retained and reported; groups must not be swapped to obtain a desired class balance or score.
