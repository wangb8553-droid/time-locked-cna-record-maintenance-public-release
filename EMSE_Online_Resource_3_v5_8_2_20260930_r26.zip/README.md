# Online Resource 3: post hoc entity-holdout sensitivity and reproduction materials

Article: A Time-Locked Benchmark for CNA Record Maintenance: Identity Dependence and Transfer Limits  
Journal: Empirical Software Engineering  
Authors: Bo Wang; Jiapeng Wei  
Affiliation 1: School of Computer Science & Artificial Intelligence, Lanzhou Institute of Technology, Lanzhou, Gansu 730300, China  
Affiliation 2: Department of Physical Education, Lanzhou Institute of Technology, Lanzhou, Gansu 730300, China  
Corresponding author: Jiapeng Wei, weijp@lzit.edu.cn

## Scope and status

This resource accompanies the r26 submission package. It contains post hoc protocol addenda, source code, aggregate summaries, figure and table source data, regenerated figure exports, and a sanitized report of the author-side clean-room reconstruction. The outcome-blind group analysis was defined after earlier group-holdout results were visible. It is post hoc, not retrospectively preregistered, and is a sensitivity analysis rather than a probability sample of unseen entities.

The group selector uses unlabeled support in the fixed 2025 test cohort. For each of vendor, product, and CNA, it retains tokens with support of at least 10 and selects up to 20 by descending support with lexical tie-breaking. The strict sensitivity removes training rows carrying any token present in any held-out test row. The completed runs had zero all-token train/test overlap. The intervals are 2,000-replicate stratified row-bootstrap intervals conditional on the fixed test rows.

## Contents

- protocol/: frozen post hoc selection and strict-purge addenda. The JSON addendum contains selection-manifest hashes but no selected group names.
- src_v3/: selection and strict-purge implementations and the model/input validation modules they import.
- source_data/: current-numbered source data for Tables 1–6 and Figures 1–6.
- figures/: editable vector PDF/SVG, 600-dpi LZW TIFF, and PNG preview files for Figures 1–6.
- reports/: sanitized aggregate results and the author-side clean-room reproduction summary. No case identifiers or selected group names are included.
- reproduction/REPRODUCE.md: ordered commands, required inputs, output expectations, and validation values for the author-side reconstruction.
- reproduction/helpers/: path-neutral adapters used for reference binding, protocol rebinding, aggregate report conversion, figure source data, plotting, and final auditing.
- requirements-model.lock: pinned modeling environment used by the project.

## Reproduction and privacy boundary

The author-side clean-room reconstruction was completed on 2026-09-30 in a new local workspace from freshly fetched CVE List V5 and CISA KEV histories and isolated, locked environments. It rebuilt the 77,218-row cohort, frozen V3 labels, dual V5 full-window replay, 76,790-row model input, fixed chronological models, predictions, transfer sensitivities, source tables, and manuscript Figures 1–6. The cohort, label, model-input, and prediction hashes matched the frozen artifacts; the V5 implementations had zero mismatches; an independent metric auditor found zero numeric differences; and the r11 public-release unit suite passed 16/16. A separate r14 archived pytest suite passed 18 tests (14 warnings). These are distinct version-specific test suites. They check implementation behavior, not semantic validity. This is author-side computational reproduction, not external institutional replication.

The version 5.8.2-r14 Zenodo record and archived release files (DOI 10.5281/zenodo.23033297) predate the revision-specific sensitivity materials and remain unchanged. The public GitHub repository now also mirrors this r26 resource and Online Resource 2 under separate versioned filenames; the original r14 files remain byte-identical, and no r26 Zenodo DOI is claimed. This resource does not redistribute upstream Git histories, original CVE/KEV record text, derived row-level model inputs, labels, predictions, complete trajectories, case identifiers, selected group-token manifests, dependency binaries, or private run outputs. The helper scripts are path-neutral copies of the adapters used for local reconstruction; only machine-specific path strings and path-bearing output metadata were removed. Their data-processing and metric behavior was not changed.

The root-level LICENSE and RIGHTS_AND_ATTRIBUTION.md specify the license for project-authored code and protocol documentation in this resource. The separate reproduction/LICENSE and reproduction/RIGHTS_AND_ATTRIBUTION.md apply to the clean-room runbook and path-neutral adapters. Aggregate source tables and figures are supplied for access and inspection only; no separate reuse license is granted for those outputs. Upstream CVE and KEV data are not redistributed, and their terms apply independently.

The full command order and expected output checks are in reproduction/REPRODUCE.md. Readers must retrieve the public upstream histories directly, pin the specified commits, and regenerate all record-level intermediates locally. Do not redistribute those intermediates.
