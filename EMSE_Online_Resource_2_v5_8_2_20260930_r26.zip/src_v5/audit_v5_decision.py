"""Apply the predeclared V5 decision rule without inspecting model scores."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trajectory-audit", type=Path, required=True)
    parser.add_argument("--diff", type=Path, required=True)
    parser.add_argument("--v5-labels", type=Path, required=True)
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output_dir.exists(): raise RuntimeError("v5_decision_output_exists")
    trajectory, diff = (json.loads(path.read_text(encoding="utf-8")) for path in (args.trajectory_audit, args.diff))
    model_ids = {json.loads(line).get("cve_id") for line in args.model_rows.read_text(encoding="utf-8").splitlines() if line.strip()}
    differences = diff.get("differences", [])
    all_terminal = all(item.get("v3_status") == item.get("v5_status") == "withdraw" for item in differences)
    changed_model_rows = sorted(item["cve_id"] for item in differences if item.get("cve_id") in model_ids)
    passed_replay = trajectory.get("passed") is True and trajectory.get("replay_mismatch_count") == 0
    branch = "retain_v3_model_results_with_v5_full_window_sensitivity" if passed_replay and all_terminal and not changed_model_rows else "rebuild_all_fixed_models_from_v5"
    result = {"run_id": args.run_id, "predeclared_rule": {"retain_condition": "V5 does not change non-withdrawal training/test rows or labels", "rebuild_condition": "Any train row, test label, positive count, or test ranking changes", "freeze_condition": "V5 replay disagreement"}, "evidence": {"trajectory_audit_sha256": digest(args.trajectory_audit), "diff_sha256": digest(args.diff), "v5_labels_sha256": digest(args.v5_labels), "model_rows_sha256": digest(args.model_rows)}, "replay_passed": passed_replay, "v3_v5_difference_count": len(differences), "all_differences_terminal_withdrawals": all_terminal, "changed_model_rows": changed_model_rows, "decision": branch, "completed_at_utc": datetime.now(timezone.utc).isoformat()}
    args.output_dir.mkdir(parents=True)
    (args.output_dir / "v5_decision.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "v5_decision_table.md").write_text(
        "# V5 Predeclared Decision\n\n| Gate | Result |\n| --- | --- |\n"
        f"| Independent replays agree | {passed_replay} |\n| V3/V5 differences | {len(differences)} |\n| All differences terminal withdrawals | {all_terminal} |\n| Changed model rows | {len(changed_model_rows)} |\n| Decision | `{branch}` |\n\n"
        "The decision is based only on label and row membership, not model performance.\n", encoding="utf-8")
    print(json.dumps({"decision": branch, "changed_model_rows": len(changed_model_rows)}))
    return 0


if __name__ == "__main__": raise SystemExit(main())
