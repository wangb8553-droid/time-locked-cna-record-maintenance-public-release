"""Rename the V5 structural taxonomy without asserting unmeasured semantics."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--taxonomy", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("v5_1_taxonomy_output_exists")
    prior = json.loads(args.taxonomy.read_text(encoding="utf-8"))
    old_counts = prior.get("counts", {})
    rewrite_count = old_counts.get("incomparable_version_or_range_rewrite", 0)
    output = {
        "run_id": args.run_id,
        "purpose": "V5.1 presentation correction for the V5 event taxonomy; no labels, events, or model results changed",
        "source_taxonomy_sha256": sha256(args.taxonomy),
        "event_count": prior["event_count"],
        "counts": {
            "new_vendor_or_product": old_counts.get("new_vendor_or_product", 0),
            "version_or_range_rewrite_semantic_comparability_not_assessed": rewrite_count,
            "other_json_structural_change": old_counts.get("other_json_structural_change", 0),
            "unknown": old_counts.get("unknown", 0),
        },
        "categories": [
            "new_vendor_or_product",
            "version_or_range_rewrite_semantic_comparability_not_assessed",
            "other_json_structural_change",
            "unknown",
        ],
        "semantic_boundary": "No version-interval comparator was implemented. Therefore version/range rewrites are structurally observed but their semantic comparability was not assessed; no category establishes semantic affected-scope expansion.",
        "passed": sum(old_counts.values()) == prior["event_count"],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": output["passed"], "event_count": output["event_count"]}))
    return 0 if output["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
