"""Fixed, post-freeze text identity masking sensitivity for the V5 decision."""
from __future__ import annotations
import argparse, hashlib, json, re
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss

BUDGETS=(.05,.10,.20)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def compile_maskers(tokens):
    """Compile one alternation per identity class so masking is linear in text."""
    grouped = {' VENDOR ': set(), ' PRODUCT ': set(), ' HOST ': set()}
    for token, replacement in tokens:
        if token and len(token) > 2:
            grouped[replacement].add(token)
    maskers = []
    for replacement, values in grouped.items():
        if not values:
            continue
        # Longest-first keeps a specific token from being swallowed by a prefix.
        pattern = r'(?<![A-Za-z0-9])(?:' + '|'.join(
            re.escape(v) for v in sorted(values, key=lambda value: (-len(value), value.casefold()))
        ) + r')(?![A-Za-z0-9])'
        maskers.append((re.compile(pattern, flags=re.IGNORECASE), replacement))
    return maskers

def mask_text(text, maskers):
    for pattern, replacement in maskers:
        text = pattern.sub(replacement, text)
    return text
def ece_10(y, s):
    bins = np.linspace(0.0, 1.0, 11)
    assignment = np.digitize(s, bins[1:-1], right=False)
    return float(sum(abs(y[assignment == idx].mean() - s[assignment == idx].mean()) * (assignment == idx).mean()
                     for idx in range(10) if np.any(assignment == idx)))

def score_metrics(y,s):
    order=np.argsort(-s,kind='mergesort'); out={'pr_auc':float(average_precision_score(y,s)),'brier':float(brier_score_loss(y,s)),'ece_10':ece_10(y,s)}
    for b in BUDGETS:
        n=int(np.ceil(len(y)*b)); out[f'recall_at_{int(b*100)}_pct']=float(y[order[:n]].sum()/y.sum()); out[f'capacity_at_{int(b*100)}_pct']=n; out[f'false_deferral_at_{int(b*100)}_pct']=int(y.sum()-y[order[:n]].sum())
    return out
def main():
    p=argparse.ArgumentParser();p.add_argument('--rows',type=Path,required=True);p.add_argument('--frozen-predictions',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--run-id',required=True);a=p.parse_args()
    if a.output_dir.exists():raise RuntimeError('mask_output_exists')
    rows=[json.loads(x) for x in a.rows.read_text(encoding='utf-8').splitlines() if x.strip()]
    train=[r for r in rows if r['t_obs'][:10]<='2024-06-30']; test=[r for r in rows if '2025-01-01'<=r['t_obs'][:10]<='2025-09-30']; ytr=np.array([r['outcome_affected_field_structural_addition'] for r in train],dtype=int); y=np.array([r['outcome_affected_field_structural_addition'] for r in test],dtype=int)
    tokens=[]
    for r in train:
        for value,replacement in ((r.get('vendors',''),' VENDOR '),(r.get('products',''),' PRODUCT '),(r.get('reference_hosts',''),' HOST ')):
            for token in value.split('|'):
                if token.strip():tokens.append((token.strip(),replacement))
    unique=[];seen=set()
    for token,replacement in sorted(tokens,key=lambda x:-len(x[0])):
        if token.casefold() not in seen:seen.add(token.casefold());unique.append((token,replacement))
    maskers = compile_maskers(unique)
    tr_text=[mask_text(r['text'],maskers) for r in train]; te_text=[mask_text(r['text'],maskers) for r in test]
    word=TfidfVectorizer(lowercase=True,ngram_range=(1,2),min_df=2,max_features=150000,sublinear_tf=True);char=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=2,max_features=150000,sublinear_tf=True)
    xw=word.fit_transform(tr_text); ew=word.transform(te_text); xc=char.fit_transform(tr_text); ec=char.transform(te_text); x=csr_matrix(hstack([xw,xc])); e=csr_matrix(hstack([ew,ec])); model=LogisticRegression(C=1.,class_weight='balanced',solver='liblinear',max_iter=500,random_state=20260905).fit(x,ytr); pred=model.predict_proba(e)[:,1]
    frozen = {row['cve_id']: row for row in (json.loads(line) for line in a.frozen_predictions.read_text(encoding='utf-8').splitlines() if line.strip())}
    ids = [r['cve_id'] for r in test]
    if set(ids) != set(frozen) or any(frozen[cve]['label'] != int(label) for cve, label in zip(ids, y)):
        raise RuntimeError('frozen_prediction_alignment_failed')
    base_pred = np.array([frozen[cve]['tfidf_word_character'] for cve in ids], dtype=float)
    rng=np.random.default_rng(20260909); keys=('pr_auc','recall_at_5_pct','recall_at_10_pct','recall_at_20_pct','brier','ece_10'); boot={k:[] for k in keys}; delta_boot={k:[] for k in keys}
    for _ in range(2000):
        idx=np.concatenate((rng.choice(np.flatnonzero(y),len(np.flatnonzero(y)),replace=True),rng.choice(np.flatnonzero(1-y),len(np.flatnonzero(1-y)),replace=True))); one=score_metrics(y[idx],pred[idx]);
        baseline_one=score_metrics(y[idx],base_pred[idx])
        for k in boot:
            boot[k].append(one[k]); delta_boot[k].append(one[k]-baseline_one[k])
    metrics=score_metrics(y,pred); baseline_metrics=score_metrics(y,base_pred); intervals={k:{'lower_95':float(np.quantile(v,.025)),'upper_95':float(np.quantile(v,.975))} for k,v in boot.items()}; delta_intervals={k:{'estimate':metrics[k]-baseline_metrics[k],'lower_95':float(np.quantile(v,.025)),'upper_95':float(np.quantile(v,.975))} for k,v in delta_boot.items()}
    result={'run_id':a.run_id,'purpose':'post-freeze exploratory text identity masking sensitivity; labels/split/capacities unchanged','rows_sha256':sha(a.rows),'frozen_predictions_sha256':sha(a.frozen_predictions),'train_count':len(train),'test_count':len(test),'test_positive_count':int(y.sum()),'masked_token_count':len(unique),'masked_classes':['vendor','product','reference_host'],'metrics':metrics,'bootstrap_95':intervals,'frozen_text_metrics':baseline_metrics,'paired_stratified_bootstrap_delta_masked_minus_frozen_text':delta_intervals,'bootstrap_replicates':2000,'not_causal':True,'not_text_deidentification_beyond_listed_tokens':True,'completed_at_utc':datetime.now(timezone.utc).isoformat()}
    a.output_dir.mkdir(parents=True);(a.output_dir/'text_identity_mask_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');(a.output_dir/'test_predictions.jsonl').write_text(''.join(json.dumps({'cve_id':cve,'label':int(label),'masked_tfidf_word_character':float(score)})+'\n' for cve,label,score in zip(ids,y,pred)),encoding='utf-8');(a.output_dir/'v5_text_mask_manifest.json').write_text(json.dumps({'run_id':a.run_id,'rows_sha256':sha(a.rows),'frozen_predictions_sha256':sha(a.frozen_predictions),'mask_rule':'training-derived exact vendor/product/reference-host tokens only; case-insensitive token boundaries','labels_unchanged':True,'split_unchanged':True,'capacities_unchanged':True,'test_cve_ids_aligned_to_frozen_predictions':True},indent=2)+'\n',encoding='utf-8');print(json.dumps({'test_rows':len(test),'positives':int(y.sum()),'masked_tokens':len(unique),'pr_auc':metrics['pr_auc']}))
if __name__=='__main__':main()
