"""V5 full-window label replay A: per-path commits in chronological order.

This implementation deliberately does not import V3 code.  It reads immutable
Git objects and keeps scanning after REJECTED/DISPUTED.  Its output is an
auditable full trajectory, not a replacement for the sealed V3 artifact.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

WITHDRAWN = {"REJECTED", "DISPUTED"}
HIGH = {"HIGH", "CRITICAL"}


def stamp(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(repo), *args], text=True, encoding="utf-8", capture_output=True, check=False)
    if result.returncode:
        raise RuntimeError(f"git_failed:{' '.join(args)}:{result.stderr.strip()}")
    return result.stdout


class Reader:
    def __init__(self, repo: Path) -> None:
        self.proc = subprocess.Popen(["git", "-C", str(repo), "cat-file", "--batch"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        assert self.proc.stdin and self.proc.stdout

    def json(self, spec: str) -> dict | None:
        assert self.proc.stdin and self.proc.stdout
        self.proc.stdin.write((spec + "\n").encode()); self.proc.stdin.flush()
        header = self.proc.stdout.readline().decode().strip()
        if header.endswith(" missing"):
            return None
        fields = header.split()
        if len(fields) != 3 or fields[1] != "blob":
            raise RuntimeError(f"unexpected_object:{header}")
        raw = self.proc.stdout.read(int(fields[2])); self.proc.stdout.read(1)
        try:
            value = json.loads(raw.decode())
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None
        return value if isinstance(value, dict) else None

    def close(self) -> None:
        assert self.proc.stdin
        self.proc.stdin.close(); self.proc.wait(timeout=60)


def cna(record: dict | None) -> dict:
    containers = record.get("containers") if isinstance(record, dict) else None
    value = containers.get("cna") if isinstance(containers, dict) else None
    return value if isinstance(value, dict) else {}


def state(record: dict | None) -> str:
    metadata = record.get("cveMetadata") if isinstance(record, dict) else None
    return str(metadata.get("state", "")).upper() if isinstance(metadata, dict) else ""


def signatures(container: dict) -> set[str]:
    result: set[str] = set()
    for item in container.get("affected", []) if isinstance(container.get("affected"), list) else []:
        if not isinstance(item, dict):
            continue
        vendor, product = str(item.get("vendor", "")).strip().casefold(), str(item.get("product", "")).strip().casefold()
        versions = item.get("versions")
        if not isinstance(versions, list) or not versions:
            result.add(json.dumps([vendor, product, "all_versions"], sort_keys=True)); continue
        for version in versions:
            if isinstance(version, dict):
                result.add(json.dumps([vendor, product, {k: version[k] for k in ("version", "status", "lessThan", "lessThanOrEqual", "versionType", "changes") if k in version}], sort_keys=True))
    return result


def severity(container: dict) -> int:
    maximum = 0
    for metric in container.get("metrics", []) if isinstance(container.get("metrics"), list) else []:
        if not isinstance(metric, dict): continue
        for key, value in metric.items():
            if key.casefold().startswith("cvss") and isinstance(value, dict):
                name = str(value.get("baseSeverity", "")).upper()
                try:
                    score = float(value.get("baseScore", 0))
                except (TypeError, ValueError):
                    score = 0.0
                maximum = max(maximum, 4 if name == "CRITICAL" or score >= 9 else 3 if name == "HIGH" or score >= 7 else 2 if name == "MEDIUM" or score >= 4 else 1 if name == "LOW" or score > 0 else 0)
    return maximum


def summary(record: dict | None) -> dict:
    sigs = signatures(cna(record))
    return {"state": state(record), "signature_count": len(sigs), "signature_sha256": hashlib.sha256("\n".join(sorted(sigs)).encode()).hexdigest(), "max_severity": severity(cna(record))}


def path_changes(repo: Path, start: str, end: str, years: set[int]) -> dict[str, list[tuple[str, datetime]]]:
    found: dict[str, list[tuple[str, datetime]]] = defaultdict(list)
    for year in sorted(years):
        commit = when = None
        for line in git(repo, "log", "--format=@@%H\t%cI", "--name-only", "--reverse", f"{start}..{end}", "--", f"cves/{year}").splitlines():
            if line.startswith("@@"):
                commit, raw = line[2:].split("\t", 1); when = stamp(raw)
            elif commit and when and line.startswith(f"cves/{year}/") and line.endswith(".json"):
                found[line].append((commit, when))
    return {key: sorted(value, key=lambda item: (item[1], item[0])) for key, value in found.items()}


def main() -> int:
    parser = argparse.ArgumentParser(); parser.add_argument("--repo", type=Path, required=True); parser.add_argument("--asof", type=Path, required=True); parser.add_argument("--output-dir", type=Path, required=True); parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output_dir.exists(): raise RuntimeError("v5_output_exists")
    rows = [json.loads(line) for line in args.asof.read_text(encoding="utf-8").splitlines() if line.strip()]
    ids = [row.get("cve_id") for row in rows]
    if len(ids) != len(set(ids)): raise RuntimeError("duplicate_source_ids")
    refs = dict(line.split("\t", 1) for line in git(args.repo, "for-each-ref", "--format=%(refname:strip=2)\t%(objectname)", "refs/tags").splitlines() if "\t" in line)
    start, end = refs["2023-03-28_baseline"], refs["2025-12-31_baseline"]
    changes = path_changes(args.repo, start, end, {int(row["cohort_year"]) for row in rows})
    reader, records, status_counts, post_rows = Reader(args.repo), [], Counter(), []
    try:
        for row in rows:
            observed, boundary = stamp(row["t_obs"]), stamp(row["t_obs"]) + timedelta(days=90)
            initial = reader.json(f"{row['asof_baseline_tag']}:{row['path']}")
            if row.get("status") != "included" or not cna(initial) or state(initial) in WITHDRAWN:
                records.append({"cve_id": row["cve_id"], "status": "excluded", "reason": "asof_excluded", "event_flags": None, "trajectory": []}); status_counts["excluded"] += 1; continue
            prior = initial; before = summary(prior); withdraw = None; pre, post, trajectory = {"affected": False, "cvss": False}, {"affected": False, "cvss": False}, []
            for commit, when in changes.get(row["path"], []):
                if not observed < when <= boundary: continue
                current = reader.json(f"{commit}:{row['path']}")
                if current is None: continue
                after = summary(current); additions = max(0, after["signature_count"] - before["signature_count"]) if False else len(signatures(cna(current)) - signatures(cna(prior)))
                event_type = []
                if additions: event_type.append("affected_field_structural_addition")
                if before["max_severity"] < 3 <= after["max_severity"]: event_type.append("cna_cvss_escalation_to_high")
                if before["state"] != after["state"]: event_type.append("state_transition")
                phase = "post_withdrawal" if withdraw else "pre_withdrawal"
                if after["state"] in WITHDRAWN and withdraw is None: withdraw = {"commit": commit, "time": when.isoformat(), "state": after["state"]}; phase = "withdrawal"
                target = post if withdraw and phase == "post_withdrawal" else pre
                target["affected"] |= bool(additions); target["cvss"] |= before["max_severity"] < 3 <= after["max_severity"]
                trajectory.append({"commit": commit, "time": when.isoformat(), "phase": phase, "events": event_type, "before": before, "after": after, "added_signature_count": additions})
                prior, before = current, after
            flags = {"affected_field_structural_addition": pre["affected"] or post["affected"], "cna_cvss_escalation_to_high": pre["cvss"] or post["cvss"]}
            flags["overlap"], flags["union"] = flags["affected_field_structural_addition"] and flags["cna_cvss_escalation_to_high"], flags["affected_field_structural_addition"] or flags["cna_cvss_escalation_to_high"]
            status = "withdraw" if withdraw else "review" if flags["union"] else "defer"; status_counts[status] += 1
            record = {"cve_id": row["cve_id"], "status": status, "t_obs": observed.isoformat(), "t_end": boundary.isoformat(), "event_flags": flags, "withdraw_event": withdraw, "pre_withdrawal_flags": pre, "post_withdrawal_flags": post, "final_disposition": summary(prior), "trajectory": trajectory}
            records.append(record)
            if withdraw: post_rows.append({"cve_id": row["cve_id"], "withdraw_commit": withdraw["commit"], "withdraw_time": withdraw["time"], "post_withdrawal_change_count": sum(1 for e in trajectory if e["phase"] == "post_withdrawal"), "post_withdrawal_affected": post["affected"], "post_withdrawal_cvss": post["cvss"]})
    finally:
        reader.close()
    args.output_dir.mkdir(parents=True)
    payload = {"run_id": args.run_id, "implementation": "A_per_path_commit_order", "source_asof_sha256": digest(args.asof), "repo_head": git(args.repo, "rev-parse", "HEAD").strip(), "status_counts": dict(status_counts), "records": records}
    (args.output_dir / "labels_v5_full_window.json").write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
    with (args.output_dir / "withdrawal_post_window_events.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["cve_id", "withdraw_commit", "withdraw_time", "post_withdrawal_change_count", "post_withdrawal_affected", "post_withdrawal_cvss"]); writer.writeheader(); writer.writerows(post_rows)
    (args.output_dir / "v5_a_manifest.json").write_text(json.dumps({"run_id": args.run_id, "labels_sha256": digest(args.output_dir / "labels_v5_full_window.json"), "record_count": len(records), "withdrawal_records": len(post_rows)}, indent=2) + "\n")
    print(json.dumps({"records": len(records), "withdrawals": len(post_rows)})); return 0

if __name__ == "__main__": raise SystemExit(main())
