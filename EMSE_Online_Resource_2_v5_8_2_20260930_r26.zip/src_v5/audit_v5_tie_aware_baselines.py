"""Tie-aware expected-capacity audit for constant-score baselines."""
from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from math import exp, lgamma
from pathlib import Path
import numpy as np

def digest(p: Path) -> str: return hashlib.sha256(p.read_bytes()).hexdigest()
def metrics(y: np.ndarray, budget: float) -> dict:
    capacity = int(np.ceil(len(y) * budget)); positives = int(y.sum()); expected = capacity * positives / len(y)
    return {"capacity": capacity, "expected_caught": expected, "expected_recall": expected / positives, "expected_missed": positives - expected, "expected_deferred_event_rate": (positives - expected) / (len(y) - capacity)}

def log_choose(n: int, k: int) -> float:
    if k < 0 or k > n:
        return float("-inf")
    return lgamma(n + 1) - lgamma(k + 1) - lgamma(n - k + 1)

def hypergeometric_reference_interval(record_count: int, positive_count: int, capacity: int) -> dict:
    """Central probability interval for one uniformly random fixed-capacity selection."""
    lower = max(0, capacity - (record_count - positive_count))
    upper = min(capacity, positive_count)
    support = np.arange(lower, upper + 1, dtype=int)
    log_denom = log_choose(record_count, capacity)
    probabilities = np.array([exp(log_choose(positive_count, int(x)) + log_choose(record_count - positive_count, capacity - int(x)) - log_denom) for x in support])
    cdf = probabilities.cumsum()
    return {
        "caught_lower_95": int(support[np.searchsorted(cdf, 0.025, side="left")]),
        "caught_upper_95": int(support[np.searchsorted(cdf, 0.975, side="left")]),
        "recall_lower_95": float(support[np.searchsorted(cdf, 0.025, side="left")] / positive_count),
        "recall_upper_95": float(support[np.searchsorted(cdf, 0.975, side="left")] / positive_count),
        "distribution": "Hypergeometric(N, K, k); central probability reference interval for one random selection",
    }
def main() -> int:
    p=argparse.ArgumentParser(); p.add_argument('--predictions',type=Path,required=True); p.add_argument('--output',type=Path,required=True); p.add_argument('--run-id',required=True); a=p.parse_args()
    if a.output.exists(): raise RuntimeError('tie_audit_output_exists')
    rows=[json.loads(x) for x in a.predictions.read_text(encoding='utf-8').splitlines() if x.strip()]; y=np.array([x['label'] for x in rows],dtype=int)
    budgets=(.05,.10,.20)
    baseline = {str(int(b*100)):metrics(y,b) for b in budgets}
    intervals = {str(int(b*100)):hypergeometric_reference_interval(len(y),int(y.sum()),baseline[str(int(b*100))]['capacity']) for b in budgets}
    result={'run_id':a.run_id,'purpose':'tie-aware constant-score baseline; expected recall is an analytic random-selection expectation independent of CVE ID order','prediction_sha256':digest(a.predictions),'record_count':len(y),'positive_count':int(y.sum()),'baselines':{name:baseline for name in ('prevalence','year_only')},'expected_recall_is_deterministic':True,'expected_recall_interval':None,'single_random_selection_reference_intervals':intervals,'interval_method':'exact hypergeometric central probability intervals; not bootstrap confidence intervals','deprecated_fields_not_reported':['bootstrap_replicates','bootstrap_95'],'passed':True,'completed_at_utc':datetime.now(timezone.utc).isoformat()}
    a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps({'passed':True,'expected_recall_at_10':result['baselines']['prevalence']['10']['expected_recall']}))
if __name__=='__main__': raise SystemExit(main())
