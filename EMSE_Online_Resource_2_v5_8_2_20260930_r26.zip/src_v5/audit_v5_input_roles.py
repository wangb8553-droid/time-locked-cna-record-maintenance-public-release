"""Superseding role audit; preserves the conflicting V3 manifest as history."""
from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path
def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def main()->int:
 p=argparse.ArgumentParser();p.add_argument('--rows',type=Path,required=True);p.add_argument('--old-manifest',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--run-id',required=True);a=p.parse_args()
 if a.output.exists():raise RuntimeError('input_role_output_exists')
 old=json.loads(a.old_manifest.read_text(encoding='utf-8')); rows=[json.loads(x) for x in a.rows.read_text(encoding='utf-8').splitlines() if x.strip()]
 result={'run_id':a.run_id,'purpose':'V5 superseding input-role audit; does not overwrite V3 manifest','model_rows_sha256':sha(a.rows),'row_count':len(rows),'historical_manifest_sha256':sha(a.old_manifest),'historical_error':{'vendors_products_listed_as_evaluation_only':True},'model_identity_features':['vendors','products','reference_hosts','cohort_year'],'model_features':['affected_count','cwe','description_count','max_cvss_band','metric_count','product_count','products','reference_count','reference_host_count','reference_hosts','text','title_present','vendor_count','vendors','version_entry_count','cohort_year'],'evaluation_only_features':['cna_group'],'forbidden_model_inputs':['ADP','NVD','KEV','EPSS','post_t_obs_CNA','current_web_content','provider_metadata'],'passed':set(old['evaluation_only_fields'])=={'cna_group','vendors','products'} and all('cna_group' in r for r in rows),'completed_at_utc':datetime.now(timezone.utc).isoformat()}
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'row_count':len(rows)}))
if __name__=='__main__':raise SystemExit(main())
