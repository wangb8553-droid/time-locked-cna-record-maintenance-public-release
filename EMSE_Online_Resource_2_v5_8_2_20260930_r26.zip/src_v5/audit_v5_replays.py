"""Compare V5 A/B replay outputs and make required trajectory-diff artifacts."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normal(record: dict) -> dict:
    trajectory = []
    for event in record.get("trajectory", []):
        kinds = event.get("events", event.get("event_kinds", []))
        trajectory.append({"commit": event.get("commit"), "time": event.get("time"), "phase": event.get("phase"), "kinds": sorted(kinds), "added_signature_count": event.get("added_signature_count")})
    final = record.get("final_disposition") or {}
    return {key: record.get(key) for key in ("status", "event_flags", "withdraw_event", "pre_withdrawal_flags", "post_withdrawal_flags")} | {"final_disposition": {key: final.get(key) for key in ("state", "signature_count", "max_severity")}, "trajectory": trajectory}


def main() -> int:
    parser = argparse.ArgumentParser(); parser.add_argument("--a", type=Path, required=True); parser.add_argument("--b", type=Path, required=True); parser.add_argument("--v3", type=Path, required=True); parser.add_argument("--output-dir", type=Path, required=True); parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output_dir.exists(): raise RuntimeError("v5_compare_output_exists")
    a, b, old = (json.loads(path.read_text(encoding="utf-8")) for path in (args.a, args.b, args.v3))
    a_rows, b_rows = {r["cve_id"]: r for r in a["records"]}, {r["cve_id"]: r for r in b["records"]}
    v3_rows = {r["cve_id"]: r for r in old["records"]}
    ids_a, ids_b, ids_v3 = set(a_rows), set(b_rows), set(v3_rows)
    mismatches, differences, post_rows = [], [], []
    for cve_id in sorted(ids_a | ids_b | ids_v3):
        if cve_id not in ids_a or cve_id not in ids_b:
            mismatches.append({"cve_id": cve_id, "reason": "missing_from_v5_replay", "in_a": cve_id in ids_a, "in_b": cve_id in ids_b}); continue
        if normal(a_rows[cve_id]) != normal(b_rows[cve_id]):
            mismatches.append({"cve_id": cve_id, "reason": "replay_disagreement"})
        v3 = v3_rows.get(cve_id, {})
        a_flags, old_flags = a_rows[cve_id].get("event_flags"), v3.get("event_flags")
        if a_rows[cve_id].get("status") != v3.get("status") or a_flags != old_flags:
            differences.append({"cve_id": cve_id, "v3_status": v3.get("status"), "v5_status": a_rows[cve_id].get("status"), "v3_flags": old_flags, "v5_flags": a_flags, "withdraw_event": a_rows[cve_id].get("withdraw_event"), "explanation": "full-window trajectory retained after terminal withdrawal; inspect event trace"})
        if a_rows[cve_id].get("withdraw_event"):
            post = a_rows[cve_id].get("post_withdrawal_flags", {})
            post_rows.append({"cve_id": cve_id, "withdraw_commit": a_rows[cve_id]["withdraw_event"]["commit"], "withdraw_time": a_rows[cve_id]["withdraw_event"]["time"], "post_withdrawal_change_count": sum(e.get("phase") == "post_withdrawal" for e in a_rows[cve_id].get("trajectory", [])), "post_withdrawal_affected": post.get("affected", False), "post_withdrawal_cvss": post.get("cvss", False)})
    args.output_dir.mkdir(parents=True)
    with (args.output_dir / "withdrawal_post_window_events.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["cve_id", "withdraw_commit", "withdraw_time", "post_withdrawal_change_count", "post_withdrawal_affected", "post_withdrawal_cvss"]); writer.writeheader(); writer.writerows(post_rows)
    (args.output_dir / "v3_vs_v5_label_diff.json").write_text(json.dumps({"run_id": args.run_id, "v3_sha256": digest(args.v3), "v5_a_sha256": digest(args.a), "difference_count": len(differences), "differences": differences}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    report = {"run_id": args.run_id, "purpose": "V5 independent full-window replay agreement audit", "implementation_a_sha256": digest(args.a), "implementation_b_sha256": digest(args.b), "source_id_counts": {"a": len(ids_a), "b": len(ids_b), "v3": len(ids_v3)}, "duplicate_id_check": len(ids_a) == len(a_rows) and len(ids_b) == len(b_rows), "replay_mismatch_count": len(mismatches), "mismatches": mismatches[:100], "v3_v5_difference_count": len(differences), "withdrawal_record_count": len(post_rows), "withdrawals_with_post_change": sum(row["post_withdrawal_change_count"] > 0 for row in post_rows), "passed": not mismatches and ids_a == ids_b, "completed_at_utc": datetime.now(timezone.utc).isoformat()}
    (args.output_dir / "trajectory_v5_replay_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "v5_source_label_run_manifest.json").write_text(json.dumps({"run_id": args.run_id, "a": str(args.a), "b": str(args.b), "v3": str(args.v3), "sha256": {"a": digest(args.a), "b": digest(args.b), "v3": digest(args.v3)}}, indent=2) + "\n")
    print(json.dumps({"passed": report["passed"], "mismatches": len(mismatches), "v3_v5_differences": len(differences), "withdrawals_with_post_change": report["withdrawals_with_post_change"]}))
    return 0 if report["passed"] else 1


if __name__ == "__main__": raise SystemExit(main())
