"""V5 full-window replay B: immutable snapshot-diff implementation.

Unlike replay A, this reader treats every path change as a before/after Git
snapshot diff.  It has its own parsers and event logic and never imports V3 or
replay A.  It retains state changes after withdrawal through the fixed horizon.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

TERMINAL = frozenset(("REJECTED", "DISPUTED"))


def parse(value: str) -> datetime: return datetime.fromisoformat(value.replace("Z", "+00:00"))
def checksum(path: Path) -> str: return hashlib.sha256(path.read_bytes()).hexdigest()
def invoke(repo: Path, *args: str) -> str:
    outcome = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, encoding="utf-8", check=False)
    if outcome.returncode: raise RuntimeError(f"git_error:{' '.join(args)}")
    return outcome.stdout


class Snapshots:
    def __init__(self, repo: Path) -> None:
        self.child = subprocess.Popen(["git", "-C", str(repo), "cat-file", "--batch"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        assert self.child.stdin and self.child.stdout
    def object(self, reference: str) -> dict | None:
        assert self.child.stdin and self.child.stdout
        self.child.stdin.write((reference + "\n").encode("utf-8")); self.child.stdin.flush()
        header = self.child.stdout.readline().decode("utf-8").rstrip()
        if header.endswith(" missing"): return None
        token = header.split()
        if len(token) != 3 or token[1] != "blob": raise RuntimeError(f"object_header:{header}")
        data = self.child.stdout.read(int(token[2])); self.child.stdout.read(1)
        try: candidate = json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError): return None
        return candidate if isinstance(candidate, dict) else None
    def finish(self) -> None:
        assert self.child.stdin; self.child.stdin.close(); self.child.wait(timeout=60)


def field(record: dict | None) -> dict:
    return record.get("containers", {}).get("cna", {}) if isinstance(record, dict) and isinstance(record.get("containers"), dict) else {}
def lifecycle(record: dict | None) -> str:
    return str(record.get("cveMetadata", {}).get("state", "")).upper() if isinstance(record, dict) and isinstance(record.get("cveMetadata"), dict) else ""
def affected(record: dict | None) -> set[tuple[str, str, str]]:
    values: set[tuple[str, str, str]] = set()
    for item in field(record).get("affected", []) if isinstance(field(record).get("affected"), list) else ():
        if not isinstance(item, dict): continue
        vendor, product = str(item.get("vendor", "")).strip().casefold(), str(item.get("product", "")).strip().casefold()
        versions = item.get("versions")
        if not isinstance(versions, list) or not versions: values.add((vendor, product, "all_versions")); continue
        for version in versions:
            if isinstance(version, dict): values.add((vendor, product, json.dumps({k: version[k] for k in ("version", "status", "lessThan", "lessThanOrEqual", "versionType", "changes") if k in version}, sort_keys=True)))
    return values
def cvss(record: dict | None) -> int:
    answer = 0
    for metric in field(record).get("metrics", []) if isinstance(field(record).get("metrics"), list) else ():
        if not isinstance(metric, dict): continue
        for key, payload in metric.items():
            if not key.casefold().startswith("cvss") or not isinstance(payload, dict): continue
            level = str(payload.get("baseSeverity", "")).upper()
            try: score = float(payload.get("baseScore", 0))
            except (TypeError, ValueError): score = 0.0
            answer = max(answer, 4 if level == "CRITICAL" or score >= 9 else 3 if level == "HIGH" or score >= 7 else 2 if level == "MEDIUM" or score >= 4 else 1 if level == "LOW" or score > 0 else 0)
    return answer
def fingerprint(record: dict | None) -> dict:
    values = affected(record)
    return {"state": lifecycle(record), "signature_count": len(values), "signature_sha256": hashlib.sha256(repr(sorted(values)).encode()).hexdigest(), "max_severity": cvss(record)}


def commit_paths(repo: Path, start: str, end: str, years: set[int]) -> dict[str, list[tuple[str, datetime]]]:
    index: dict[str, list[tuple[str, datetime]]] = defaultdict(list)
    # This is a snapshot inventory, not replay A's per-row traversal.
    for year in sorted(years):
        lines = invoke(repo, "log", "--reverse", "--format=%H%x09%cI", "--name-only", f"{start}..{end}", "--", f"cves/{year}").splitlines()
        commit = timestamp = None
        for line in lines:
            if "\t" in line and len(line.split("\t", 1)[0]) == 40:
                commit, raw = line.split("\t", 1); timestamp = parse(raw)
            elif commit and timestamp and line.startswith(f"cves/{year}/") and line.endswith(".json"):
                index[line].append((commit, timestamp))
    return index


def main() -> int:
    parser = argparse.ArgumentParser(); parser.add_argument("--repo", type=Path, required=True); parser.add_argument("--asof", type=Path, required=True); parser.add_argument("--output", type=Path, required=True); parser.add_argument("--run-id", required=True)
    options = parser.parse_args()
    if options.output.exists(): raise RuntimeError("v5_b_output_exists")
    sources = [json.loads(x) for x in options.asof.read_text(encoding="utf-8").splitlines() if x.strip()]
    if len({item.get("cve_id") for item in sources}) != len(sources): raise RuntimeError("duplicate_cve_id")
    tags = dict(x.split("\t", 1) for x in invoke(options.repo, "for-each-ref", "--format=%(refname:strip=2)%09%(objectname)", "refs/tags").splitlines() if "\t" in x)
    catalogue = commit_paths(options.repo, tags["2023-03-28_baseline"], tags["2025-12-31_baseline"], {int(x["cohort_year"]) for x in sources})
    reader, answers, totals = Snapshots(options.repo), [], Counter()
    try:
        for source in sources:
            begin, finish = parse(source["t_obs"]), parse(source["t_obs"]) + timedelta(days=90)
            root = reader.object(f"{source['asof_baseline_tag']}:{source['path']}")
            if source.get("status") != "included" or not field(root) or lifecycle(root) in TERMINAL:
                answers.append({"cve_id": source["cve_id"], "status": "excluded", "event_flags": None, "withdraw_event": None, "trajectory": []}); totals["excluded"] += 1; continue
            previous, prior = root, fingerprint(root); was_withdrawn = False; withdrawal = None; all_events: list[dict] = []; flags = {"affected_field_structural_addition": False, "cna_cvss_escalation_to_high": False}; pre = {"affected": False, "cvss": False}; post = {"affected": False, "cvss": False}
            for commit, moment in catalogue.get(source["path"], []):
                if moment <= begin or moment > finish: continue
                next_record = reader.object(f"{commit}:{source['path']}")
                if next_record is None: continue
                current = fingerprint(next_record); added = affected(next_record).difference(affected(previous)); escalated = prior["max_severity"] < 3 <= current["max_severity"]
                phase = "post_withdrawal" if was_withdrawn else "pre_withdrawal"
                if not was_withdrawn and current["state"] in TERMINAL:
                    was_withdrawn, phase = True, "withdrawal"; withdrawal = {"commit": commit, "time": moment.isoformat(), "state": current["state"]}
                bucket = post if phase == "post_withdrawal" else pre
                bucket["affected"] |= bool(added); bucket["cvss"] |= escalated; flags["affected_field_structural_addition"] |= bool(added); flags["cna_cvss_escalation_to_high"] |= escalated
                all_events.append({"commit": commit, "time": moment.isoformat(), "phase": phase, "event_kinds": [name for name, hit in (("affected_field_structural_addition", bool(added)), ("cna_cvss_escalation_to_high", escalated), ("state_transition", prior["state"] != current["state"])) if hit], "before": prior, "after": current, "added_signature_count": len(added)})
                previous, prior = next_record, current
            flags["overlap"] = flags["affected_field_structural_addition"] and flags["cna_cvss_escalation_to_high"]; flags["union"] = flags["affected_field_structural_addition"] or flags["cna_cvss_escalation_to_high"]
            disposition = "withdraw" if withdrawal else "review" if flags["union"] else "defer"; totals[disposition] += 1
            answers.append({"cve_id": source["cve_id"], "status": disposition, "t_obs": begin.isoformat(), "t_end": finish.isoformat(), "event_flags": flags, "withdraw_event": withdrawal, "pre_withdrawal_flags": pre, "post_withdrawal_flags": post, "final_disposition": prior, "trajectory": all_events})
    finally:
        reader.finish()
    result = {"run_id": options.run_id, "implementation": "B_snapshot_diff", "source_asof_sha256": checksum(options.asof), "repo_head": invoke(options.repo, "rev-parse", "HEAD").strip(), "status_counts": dict(totals), "records": answers}
    options.output.parent.mkdir(parents=True, exist_ok=True); options.output.write_text(json.dumps(result, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"records": len(answers), "withdrawals": totals["withdraw"]})); return 0

if __name__ == "__main__": raise SystemExit(main())
