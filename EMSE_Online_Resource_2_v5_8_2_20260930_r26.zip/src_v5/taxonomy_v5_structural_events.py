"""Post-freeze structural-event taxonomy; no semantic interval claim."""
from __future__ import annotations
import argparse,csv,json,subprocess
from pathlib import Path
from collections import Counter
def get(repo,*a):
 r=subprocess.run(['git','-C',str(repo),*a],capture_output=True,text=True,encoding='utf-8');
 if r.returncode:raise RuntimeError(r.stderr)
 return r.stdout
class BatchObjects:
 def __init__(self, repo):
  self.process=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 def obj(self,ref):
  self.process.stdin.write((ref+'\n').encode());self.process.stdin.flush()
  head=self.process.stdout.readline().decode().strip()
  if head.endswith(' missing'):return {}
  tokens=head.split()
  if len(tokens)!=3 or tokens[1]!='blob':raise RuntimeError('unexpected_cat_file_header:'+head)
  raw=self.process.stdout.read(int(tokens[2]));self.process.stdout.read(1)
  try:return json.loads(raw.decode())
  except (UnicodeDecodeError,json.JSONDecodeError):return {}
 def close(self):
  self.process.stdin.close();self.process.wait(timeout=60)
def parts(r):
 out={}
 for x in r.get('containers',{}).get('cna',{}).get('affected',[]) or []:
  if not isinstance(x,dict):continue
  k=(str(x.get('vendor','')).strip().casefold(),str(x.get('product','')).strip().casefold());out.setdefault(k,[]).append(x.get('versions',[]))
 return out
def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--labels',type=Path,required=True);p.add_argument('--asof',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--run-id',required=True);a=p.parse_args()
 if a.output.exists():raise RuntimeError('taxonomy_output_exists')
 labels=json.loads(a.labels.read_text(encoding='utf-8'))['records']; source={r['cve_id']:r for r in (json.loads(x) for x in a.asof.read_text(encoding='utf-8').splitlines() if x.strip())}; rows=[];counts=Counter(); reader=BatchObjects(a.repo)
 try:
  for r in labels:
   if not (r.get('event_flags') or {}).get('affected_field_structural_addition'):continue
   prior=reader.obj(f"{source[r['cve_id']]['asof_baseline_tag']}:{source[r['cve_id']]['path']}")
   for e in r.get('trajectory',[]):
    if 'affected_field_structural_addition' not in e.get('events',[]):continue
    current=reader.obj(f"{e['commit']}:{source[r['cve_id']]['path']}");before,after=parts(prior),parts(current);new_keys=set(after)-set(before);shared=set(after)&set(before)
    malformed=not before or not after
    changed_shared=any(before[key]!=after[key] for key in shared)
    if malformed: category='unknown'
    elif new_keys: category='new_vendor_or_product'
    elif changed_shared: category='version_or_range_rewrite_semantic_comparability_not_assessed'
    else: category='other_json_structural_change'
    # Exact JSON signatures cannot establish range containment; no semantic expansion is inferred.
    counts[category]+=1;rows.append({'cve_id':r['cve_id'],'commit':e['commit'],'time':e['time'],'phase':e['phase'],'taxonomy':category,'possible_scope_change':category=='new_vendor_or_product','semantic_boundary':'not_established'})
    prior=current
 finally: reader.close()
 out={'run_id':a.run_id,'purpose':'post-freeze V5 event taxonomy; no interval containment implementation','event_count':len(rows),'counts':dict(counts),'categories':['new_vendor_or_product','version_or_range_rewrite_semantic_comparability_not_assessed','other_json_structural_change','unknown'],'boundary':'Version/range rewrites are structurally observed, but semantic comparability was not assessed because no version-interval comparator was implemented. Only new vendor/product is a possible scope-change proxy; neither category establishes semantic affected-scope expansion.'}
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n');
 with (a.output.parent/'v5_structural_event_taxonomy.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys() if rows else ['cve_id']);w.writeheader();w.writerows(rows)
 print(json.dumps(out['counts']))
if __name__=='__main__':main()
