"""Fail-closed V5 local-computation audit without asserting publication readiness."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("v5_json_object_required")
    return value


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--decision", type=Path, required=True)
    parser.add_argument("--trajectory", type=Path, required=True)
    parser.add_argument("--taxonomy", type=Path, required=True)
    parser.add_argument("--tie-aware", type=Path, required=True)
    parser.add_argument("--input-roles", type=Path, required=True)
    parser.add_argument("--text-mask", type=Path, required=True)
    parser.add_argument("--test-audit", type=Path, required=True)
    parser.add_argument("--manuscript", type=Path, required=True)
    parser.add_argument("--v4-final-audit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("v5_final_audit_output_exists")
    decision, trajectory, taxonomy, ties, roles, mask, tests, v4 = [load(path) for path in (
        args.decision, args.trajectory, args.taxonomy, args.tie_aware, args.input_roles,
        args.text_mask, args.test_audit, args.v4_final_audit,
    )]
    manuscript = args.manuscript.read_text(encoding="utf-8")
    failures = []
    if decision.get("decision") != "retain_v3_model_results_with_v5_full_window_sensitivity":
        failures.append("v5_decision_not_predeclared_retain_case")
    if decision.get("changed_model_rows") != []:
        failures.append("v5_changed_model_rows_present")
    if not trajectory.get("passed") or trajectory.get("replay_mismatch_count") != 0:
        failures.append("v5_dual_replay_not_exact")
    if taxonomy.get("event_count") != sum(taxonomy.get("counts", {}).values()):
        failures.append("v5_taxonomy_count_inconsistent")
    if not ties.get("passed"):
        failures.append("v5_tie_aware_baseline_failed")
    if roles.get("evaluation_only_features") != ["cna_group"]:
        failures.append("v5_input_roles_invalid")
    delta = mask.get("paired_stratified_bootstrap_delta_masked_minus_frozen_text", {}).get("pr_auc", {})
    if mask.get("test_count") != 26103 or "estimate" not in delta:
        failures.append("v5_text_mask_incomplete")
    if tests.get("status") != "passed" or tests.get("return_code") != 0:
        failures.append("v5_test_audit_failed")
    for required in ("V5 full-window dual replay", "tie-aware expected recall", "The V5 event-level taxonomy found"):
        if required not in manuscript:
            failures.append(f"v5_manuscript_missing:{required}")
    if not v4.get("local_computational_analysis_complete"):
        failures.append("v4_frozen_evidence_not_locally_complete")
    evidence_paths = [args.decision, args.trajectory, args.taxonomy, args.tie_aware, args.input_roles,
                      args.text_mask, args.test_audit, args.manuscript, args.v4_final_audit]
    payload = {
        "run_id": args.run_id,
        "purpose": "V5 terminal local-scientific audit; not public-release or publication authorization",
        "evidence": {str(path): sha256(path) for path in evidence_paths},
        "local_scientific_audit_complete": not failures,
        "public_release_authorized": False,
        "publication_claim_permitted": False,
        "remaining_external_release_requirements": v4.get("remaining_external_release_requirements", []),
        "failures": failures,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"local_scientific_audit_complete": not failures, "failures": failures}))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
