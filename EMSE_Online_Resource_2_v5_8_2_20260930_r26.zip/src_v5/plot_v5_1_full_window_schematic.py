"""Rebuild the V5 full-window replay schematic from public aggregate audit data."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({"font.size": 7, "axes.linewidth": 0.8, "legend.frameon": False})

BLUE = "#0F4D92"
TEAL = "#42949E"
RED = "#B64342"
GRAY = "#767676"
LIGHT = "#E9EEF5"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def box(ax, x: float, y: float, text: str, color: str, width: float = 0.18, height: float = 0.12) -> None:
    patch = plt.Rectangle((x, y), width, height, facecolor=color, edgecolor="#4D4D4D", linewidth=0.7)
    ax.add_patch(patch)
    ax.text(x + width / 2, y + height / 2, text, ha="center", va="center", fontsize=6.2, wrap=True)


def arrow(ax, start: tuple[float, float], end: tuple[float, float], color: str = "#4D4D4D") -> None:
    ax.annotate("", xy=end, xytext=start, arrowprops={"arrowstyle": "->", "lw": 0.9, "color": color})


def save(fig: plt.Figure, stem: Path) -> list[Path]:
    outputs: list[Path] = []
    for suffix, kwargs in (("svg", {}), ("pdf", {}), ("tiff", {"dpi": 600}), ("png", {"dpi": 300})):
        path = stem.with_suffix("." + suffix)
        fig.savefig(path, bbox_inches="tight", **kwargs)
        outputs.append(path)
    plt.close(fig)
    return outputs


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-summary", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise RuntimeError("v5_1_figure_output_exists")
    audit = json.loads(args.audit_summary.read_text(encoding="utf-8"))
    replay_mismatches = audit.get("replay_mismatches", audit.get("replay_mismatch_count"))
    records_replayed = audit.get("records_replayed", audit.get("source_id_counts", {}).get("a"))
    withdrawal_records = audit.get("withdrawal_records", audit.get("withdrawal_record_count"))
    post_terminal_changes = audit.get(
        "withdrawals_with_post_withdrawal_changes", audit.get("withdrawals_with_post_change")
    )
    label_differences = audit.get("v3_v5_label_differences", audit.get("v3_v5_difference_count"))
    if not audit.get("passed") or replay_mismatches != 0:
        raise RuntimeError("unpassed_trajectory_audit")
    if any(value is None for value in (records_replayed, withdrawal_records, post_terminal_changes, label_differences)):
        raise RuntimeError("incomplete_public_aggregate_audit_summary")
    args.output_dir.mkdir(parents=True)

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.55), gridspec_kw={"width_ratios": [2.2, 1.0]}, layout="constrained")
    ax = axes[0]
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.text(-0.05, 1.02, "a", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax.text(0.03, 0.93, "Time-locked observation and full-window replay", fontsize=8, fontweight="bold")
    box(ax, 0.04, 0.63, "CVE publication\n$t_{pub}$", LIGHT)
    box(ax, 0.29, 0.63, "Frozen CNA-only\nobservation $t_{obs}$", "#DDF3DE", width=0.22)
    box(ax, 0.61, 0.63, "End of 90-day\nwindow $t_{end}$", LIGHT)
    arrow(ax, (0.22, 0.69), (0.29, 0.69)); arrow(ax, (0.51, 0.69), (0.61, 0.69))
    ax.text(0.40, 0.77, "only fields available within 24 h", ha="center", color=GRAY, fontsize=6)
    box(ax, 0.29, 0.28, "rank from early\nCNA fields", "#DDEAF7", width=0.22)
    arrow(ax, (0.40, 0.63), (0.40, 0.40), BLUE)
    box(ax, 0.60, 0.28, "scan every qualifying\nrevision through $t_{end}$", "#DDEAF7", width=0.26)
    arrow(ax, (0.72, 0.63), (0.72, 0.40), BLUE)
    ax.text(0.73, 0.14, "new affected-field signature\nis a record event, not proof of\nsemantic affected-scope expansion", ha="center", va="center", fontsize=6, color=GRAY)

    ax = axes[1]
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.text(-0.11, 1.02, "b", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax.text(0.02, 0.93, "Terminal disposition is not a scan stop", fontsize=8, fontweight="bold")
    box(ax, 0.10, 0.66, "withdrawal /\ndispute occurs", "#F6CFCB", width=0.38)
    box(ax, 0.55, 0.66, "continue replay\nto $t_{end}$", "#DDEAF7", width=0.34)
    arrow(ax, (0.48, 0.72), (0.55, 0.72), RED)
    box(ax, 0.55, 0.38, "record post-terminal\nevents in\ntrajectory", "#DDF3DE", width=0.43)
    arrow(ax, (0.72, 0.66), (0.72, 0.50), TEAL)
    box(ax, 0.10, 0.15, "terminal withdrawal/dispute\nexcluded from binary evaluation", "#F6CFCB", width=0.79)
    arrow(ax, (0.72, 0.38), (0.50, 0.27), RED)

    stem = args.output_dir / "figure_s1_v5_full_window_replay"
    outputs = save(fig, stem)
    source_rows = [
        {"measure": "records replayed", "value": records_replayed},
        {"measure": "replay mismatches", "value": replay_mismatches},
        {"measure": "terminal-withdrawal records", "value": withdrawal_records},
        {"measure": "withdrawals with post-terminal changes", "value": post_terminal_changes},
        {"measure": "V3/V5 label differences", "value": label_differences},
    ]
    with (args.output_dir / "figure_s1_v5_full_window_replay_source_data.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["measure", "value"]); writer.writeheader(); writer.writerows(source_rows)
    qa: dict[str, dict] = {}
    for path in outputs:
        if path.suffix == ".png":
            pixels = np.asarray(Image.open(path).convert("RGB"))
            fraction = float((pixels < 245).any(axis=2).mean())
            if fraction <= 0.01:
                raise RuntimeError("blank_png_detected")
            qa[path.name] = {"nonwhite_fraction": fraction, "shape": list(pixels.shape)}
        elif path.suffix == ".svg":
            text_nodes = len(re.findall(r"<text(?:\s|>)", path.read_text(encoding="utf-8")))
            if text_nodes == 0:
                raise RuntimeError("svg_text_not_editable")
            qa[path.name] = {"editable_text_nodes": text_nodes}
    manifest = {
        "run_id": args.run_id,
        "purpose": "Python-only V5.1 full-window-replay schematic; not a quantitative effect figure",
        "backend": {"python": sys.version, "matplotlib": matplotlib.__version__},
        "figure_contract": {
            "core_conclusion": "V5 scans the full 90-day window after withdrawal or dispute, while terminally withdrawn or disputed rows remain excluded from binary evaluation.",
            "archetype": "schematic-led composite",
            "final_size_inches": [7.2, 2.55],
            "panel_map": {
                "a": "24-hour observation, early-field ranking and full 90-day replay",
                "b": "post-terminal events are retained in the trajectory, but terminal rows are excluded from binary evaluation",
            },
            "evidence_hierarchy": "trajectory-audit counts validate the workflow; no causal, workload, or deployment claim.",
            "reviewer_risk": "Diagram does not prove semantic scope growth or practical benefit; labels and exclusions are explicit. CVSS is not a V5 endpoint.",
        },
        "inputs": {args.audit_summary.name: sha256(args.audit_summary)},
        "outputs": {path.name: sha256(path) for path in outputs},
        "qa": qa,
        "source_data": "figure_s1_v5_full_window_replay_source_data.csv",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "platform": platform.platform(),
        "author_public_release_scope_authorized": True,
        "public_archive_published": False,
    }
    (args.output_dir / "figure_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": True, "outputs": len(outputs), "figure": stem.name}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
