"""Independently verify a V4 KEV descriptive-overlap artifact."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_show(repo: Path, revision: str) -> bytes:
    return subprocess.run(
        ["git", "-C", str(repo), "show", revision], check=True, capture_output=True
    ).stdout


def expected(rows: list[dict], kev_ids: set[str], fraction: float) -> tuple[int, int, int]:
    ranked = sorted(rows, key=lambda row: (-float(row["structured_cna"]), row["cve_id"]))
    count = math.ceil(len(ranked) * fraction)
    selected = {row["cve_id"] for row in ranked[:count]}
    cohort = {row["cve_id"] for row in rows}
    cohort_kev = cohort & kev_ids
    return count, len(cohort_kev), len(selected & kev_ids)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--kev-repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("kev_audit_output_exists")
    analysis = json.loads(args.analysis.read_text(encoding="utf-8"))
    lines = args.predictions.read_text(encoding="utf-8").splitlines()
    rows = [json.loads(line) for line in lines]
    failures = []
    if analysis.get("prediction_provenance", {}).get("sha256") != digest(args.predictions):
        failures.append("prediction_hash_mismatch")
    snapshot = analysis.get("kev_snapshot", {})
    commit = snapshot.get("commit")
    if not isinstance(commit, str):
        failures.append("snapshot_commit_missing")
        payload_bytes = b"{}"
    else:
        payload_bytes = git_show(args.kev_repo, f"{commit}:known_exploited_vulnerabilities.json")
        if snapshot.get("json_blob_sha256") != hashlib.sha256(payload_bytes).hexdigest():
            failures.append("kev_blob_hash_mismatch")
        commit_time = git_show(args.kev_repo, f"{commit}^{{commit}}").decode("utf-8")
        # Resolve and read commit metadata independently of the analysis producer.
        actual_time = subprocess.run(
            ["git", "-C", str(args.kev_repo), "show", "-s", "--format=%cI", commit],
            check=True, capture_output=True, text=True,
        ).stdout.strip()
        if snapshot.get("commit_time") != actual_time:
            failures.append("kev_commit_time_mismatch")
        deadline = datetime.fromisoformat(str(snapshot.get("not_after")).replace("Z", "+00:00"))
        if datetime.fromisoformat(actual_time) > deadline:
            failures.append("kev_snapshot_after_deadline")
    payload = json.loads(payload_bytes.decode("utf-8"))
    vulnerabilities = payload.get("vulnerabilities", [])
    kev_ids = {row.get("cveID") for row in vulnerabilities if isinstance(row, dict) and isinstance(row.get("cveID"), str)}
    if len(kev_ids) != len(vulnerabilities):
        failures.append("kev_ids_invalid_or_duplicate")
    if snapshot.get("catalog_record_count") != len(kev_ids):
        failures.append("kev_catalog_count_mismatch")
    expected_rows = []
    for item in analysis.get("capacities", []):
        fraction = item.get("capacity_fraction")
        if not isinstance(fraction, (float, int)):
            failures.append("invalid_capacity")
            continue
        selected_count, cohort_count, selected_kev = expected(rows, kev_ids, float(fraction))
        expected_rows.append({"capacity_fraction": fraction, "selected_record_count": selected_count, "cohort_kev_count": cohort_count, "selected_kev_count": selected_kev})
        for key, value in expected_rows[-1].items():
            if item.get(key) != value:
                failures.append(f"capacity_{fraction}_{key}_mismatch")
    if len(expected_rows) != 3:
        failures.append("capacity_count_not_three")
    result = {
        "run_id": args.run_id,
        "purpose": "independent reparse of V4 KEV descriptive analysis; not a KEV effectiveness claim",
        "analysis_sha256": digest(args.analysis),
        "prediction_sha256": digest(args.predictions),
        "recomputed_capacities": expected_rows,
        "failures": failures,
        "passed": not failures,
        "boundary": "This audit verifies frozen-snapshot overlap arithmetic only. It does not establish exploitation timing, causal model utility, or operational benefit.",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "failures": failures}))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
