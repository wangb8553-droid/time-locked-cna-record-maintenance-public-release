"""Run the project unittest suite and preserve an auditable terminal record."""

from __future__ import annotations

import argparse
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise RuntimeError("v4_test_audit_output_exists")
    root = args.project_root.resolve()
    command = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"]
    completed = subprocess.run(command, cwd=root, text=True, capture_output=True, check=False)
    args.output_dir.mkdir(parents=True)
    (args.output_dir / "stdout.log").write_text(completed.stdout, encoding="utf-8")
    (args.output_dir / "stderr.log").write_text(completed.stderr, encoding="utf-8")
    tests_run = None
    for line in completed.stderr.splitlines():
        if line.startswith("Ran ") and " tests" in line:
            tests_run = int(line.split()[1])
            break
    payload = {
        "run_id": args.run_id,
        "command": command,
        "working_directory": str(root),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "platform": platform.platform(),
        "test_framework": "unittest",
        "tests_run": tests_run,
        "return_code": completed.returncode,
        "status": "passed" if completed.returncode == 0 else "failed",
        "stdout_log": "stdout.log",
        "stderr_log": "stderr.log",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    (args.output_dir / "test_audit.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"status": payload["status"], "tests_run": tests_run, "return_code": completed.returncode}))
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(main())
