"""Materialize CNA-only V3 model rows with evaluation-only group metadata."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from collections import Counter
from pathlib import Path

from v3_input_reference import validate_reference
from build_full_cohort_batch import CatFileBatch, load_json


ALLOWED_CNA_FIELDS = ("affected", "descriptions", "metrics", "problemTypes", "references", "title")
OUTCOMES = ("affected_field_structural_addition", "cna_cvss_escalation_to_high", "overlap", "union")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def english_text(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(row.get("value", "")).strip() for row in value if isinstance(row, dict) and row.get("lang") == "en" and str(row.get("value", "")).strip()]


def cwe_values(problem_types: object) -> list[str]:
    values = []
    if not isinstance(problem_types, list):
        return values
    for row in problem_types:
        if not isinstance(row, dict) or not isinstance(row.get("descriptions"), list):
            continue
        for description in row["descriptions"]:
            if isinstance(description, dict) and description.get("cweId"):
                values.append(str(description["cweId"]).strip())
    return sorted(set(values))


def max_cvss_band(metrics: object) -> int:
    declared = {"NONE": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
    best = 0
    if not isinstance(metrics, list):
        return best
    for metric in metrics:
        if not isinstance(metric, dict):
            continue
        for name, payload in metric.items():
            if not name.lower().startswith("cvss") or not isinstance(payload, dict):
                continue
            band = declared.get(str(payload.get("baseSeverity", "")).upper(), 0)
            try:
                score = float(payload.get("baseScore", 0))
            except (TypeError, ValueError):
                score = 0.0
            best = max(best, band, 4 if score >= 9 else 3 if score >= 7 else 2 if score >= 4 else 1 if score > 0 else 0)
    return best


def group_value(provider_metadata: object) -> str:
    if not isinstance(provider_metadata, dict):
        return "__missing__"
    for key in ("shortName", "orgId"):
        value = str(provider_metadata.get(key, "")).strip().casefold()
        if value:
            return value
    return "__missing__"


def cna_features(record: dict) -> dict:
    containers = record.get("containers")
    cna = containers.get("cna") if isinstance(containers, dict) else None
    if not isinstance(cna, dict):
        raise RuntimeError("asof_cna_missing")
    descriptions = english_text(cna.get("descriptions"))
    title = str(cna.get("title", "")).strip() if cna.get("title") else ""
    affected = cna.get("affected") if isinstance(cna.get("affected"), list) else []
    vendors = sorted({str(row.get("vendor", "")).strip().casefold() for row in affected if isinstance(row, dict) and str(row.get("vendor", "")).strip()})
    products = sorted({str(row.get("product", "")).strip().casefold() for row in affected if isinstance(row, dict) and str(row.get("product", "")).strip()})
    versions = sum(len(row.get("versions", [])) for row in affected if isinstance(row, dict) and isinstance(row.get("versions"), list))
    references = cna.get("references") if isinstance(cna.get("references"), list) else []
    reference_hosts = []
    for reference in references:
        url = reference.get("url") if isinstance(reference, dict) else None
        if isinstance(url, str) and "://" in url:
            reference_hosts.append(url.split("://", 1)[1].split("/", 1)[0].casefold())
    return {
        "text": " ".join([title, *descriptions, *cwe_values(cna.get("problemTypes"))]),
        "title_present": int(bool(title)),
        "description_count": len(descriptions),
        "affected_count": len(affected),
        "version_entry_count": versions,
        "vendor_count": len(vendors),
        "product_count": len(products),
        "reference_count": len(references),
        "reference_host_count": len(set(reference_hosts)),
        "metric_count": len(cna.get("metrics", [])) if isinstance(cna.get("metrics"), list) else 0,
        "max_cvss_band": max_cvss_band(cna.get("metrics")),
        "cwe": "|".join(cwe_values(cna.get("problemTypes"))) or "__missing__",
        "vendors": "|".join(vendors) or "__missing__",
        "products": "|".join(products) or "__missing__",
        "reference_hosts": "|".join(sorted(set(reference_hosts))) or "__missing__",
        "cna_group": group_value(cna.get("providerMetadata")),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--asof-jsonl", type=Path, required=True)
    parser.add_argument("--v3-labels", type=Path, required=True)
    parser.add_argument("--v3-input-reference", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists() or args.manifest.exists():
        raise RuntimeError("output_or_manifest_already_exists")
    gate = validate_reference(args.v3_input_reference, args.v3_labels, args.asof_jsonl, args.repo.resolve())
    labels = {row["cve_id"]: row for row in json.loads(args.v3_labels.read_text(encoding="utf-8"))["records"]}
    asof_rows = [json.loads(line) for line in args.asof_jsonl.read_text(encoding="utf-8").splitlines() if line.strip()]
    eligible_rows = []
    for row in asof_rows:
        label = labels.get(row.get("cve_id"))
        if row.get("status") != "included" or not label or label.get("status") not in {"review", "defer"}:
            continue
        eligible_rows.append((row, label))
    reader = CatFileBatch(args.repo.resolve())
    output_rows = []
    try:
      for row, label in eligible_rows:
        payload = reader.get(f"{row['asof_baseline_tag']}:{row['path']}")
        if payload is None:
            raise RuntimeError(f"asof_payload_missing:{row['asof_baseline_tag']}:{row['path']}")
        record = load_json(payload)
        if record is None:
            raise RuntimeError(f"asof_payload_invalid_json:{row['asof_baseline_tag']}:{row['path']}")
        features = cna_features(record)
        flags = label["event_flags"]
        output_rows.append({
            "cve_id": row["cve_id"],
            "t_obs": row["t_obs"],
            "cohort_year": row["cohort_year"],
            "label_status": label["status"],
            "asof_record_sha256": row["asof_record_sha256"],
            **{f"outcome_{name}": int(flags[name]) for name in OUTCOMES},
            **features,
        })
    finally:
        reader.close()
    if not output_rows:
        raise RuntimeError("no_eligible_model_rows")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in output_rows), encoding="utf-8")
    outcome_counts = {name: sum(row[f"outcome_{name}"] for row in output_rows) for name in OUTCOMES}
    manifest = {
        "run_id": args.run_id,
        "purpose": "CNA-only t_obs model input; V3 structural-change outcomes and evaluation-only grouping",
        "input_reference_sha256": sha256(args.v3_input_reference),
        "v3_labels_sha256": sha256(args.v3_labels),
        "source_asof_sha256": sha256(args.asof_jsonl),
        "model_rows_sha256": sha256(args.output),
        "row_count": len(output_rows),
        "outcome_counts": outcome_counts,
        "allowed_cna_fields": list(ALLOWED_CNA_FIELDS),
        "evaluation_only_fields": ["cna_group", "vendors", "products"],
        "forbidden_inputs": ["ADP", "NVD", "KEV", "EPSS", "post_t_obs_CNA", "current_web_content", "providerMetadata_model_feature"],
        "python": sys.version,
        "platform": platform.platform(),
    }
    args.manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"rows": len(output_rows), "outcome_counts": outcome_counts, "output": str(args.output)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
