"""Independently replay frozen V3 labels from immutable Git objects.

This verifier intentionally does not import the V3 label builder or its
helpers. It obtains both as-of and post-observation JSON via ``git cat-file``
at explicit tags/commits, so a dirty source worktree cannot affect the result.
It recomputes structural additions, CNA-CVSS escalation, withdrawals, and
timestamp/identity integrity before comparing the frozen labels row by row.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path


FREEZE = datetime.fromisoformat("2025-12-31T23:59:59+00:00")
HIGH = 3
STATE_WITHDRAWN = {"REJECTED", "DISPUTED"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def git_text(repo: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, encoding="utf-8", check=False)
    if result.returncode:
        raise RuntimeError(f"git_failed:{' '.join(args)}:{result.stderr.strip()}")
    return result.stdout


class ObjectReader:
    """Minimal, independent binary protocol implementation for git cat-file."""

    def __init__(self, repo: Path) -> None:
        self.process = subprocess.Popen(
            ["git", "-C", str(repo), "cat-file", "--batch"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        assert self.process.stdin is not None and self.process.stdout is not None

    def read_blob(self, spec: str) -> bytes | None:
        assert self.process.stdin is not None and self.process.stdout is not None
        self.process.stdin.write(spec.encode("utf-8") + b"\n")
        self.process.stdin.flush()
        header = self.process.stdout.readline().decode("utf-8", errors="strict").strip()
        if header.endswith(" missing"):
            return None
        fields = header.split()
        if len(fields) != 3 or fields[1] != "blob":
            raise RuntimeError(f"unexpected_cat_file_header:{header}")
        size = int(fields[2])
        payload = self.process.stdout.read(size)
        self.process.stdout.read(1)  # newline after the object payload
        return payload

    def read_json(self, spec: str) -> dict | None:
        payload = self.read_blob(spec)
        if payload is None:
            return None
        try:
            value = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None
        return value if isinstance(value, dict) else None

    def close(self) -> None:
        if self.process.stdin:
            self.process.stdin.close()
        self.process.wait(timeout=30)
        if self.process.returncode:
            raise RuntimeError("git_cat_file_failed")


def cna_container(record: dict | None) -> dict | None:
    containers = record.get("containers") if isinstance(record, dict) else None
    value = containers.get("cna") if isinstance(containers, dict) else None
    return value if isinstance(value, dict) else None


def record_state(record: dict | None) -> str:
    metadata = record.get("cveMetadata") if isinstance(record, dict) else None
    return str(metadata.get("state", "")).upper() if isinstance(metadata, dict) else ""


def structural_signatures(container: dict) -> set[str]:
    """Independent structural signature implementation; no range semantics."""
    result: set[str] = set()
    entries = container.get("affected")
    if not isinstance(entries, list):
        return result
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        vendor = str(entry.get("vendor", "")).strip().casefold()
        product = str(entry.get("product", "")).strip().casefold()
        versions = entry.get("versions")
        if not isinstance(versions, list) or not versions:
            result.add(json.dumps([vendor, product, "all_versions"], sort_keys=True))
            continue
        for version in versions:
            if not isinstance(version, dict):
                continue
            range_data = {key: version[key] for key in ("version", "status", "lessThan", "lessThanOrEqual", "versionType", "changes") if key in version}
            result.add(json.dumps([vendor, product, range_data], sort_keys=True))
    return result


def numeric_severity(container: dict) -> int:
    declared = {"NONE": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
    maximum = 0
    metrics = container.get("metrics")
    if not isinstance(metrics, list):
        return maximum
    for metric in metrics:
        if not isinstance(metric, dict):
            continue
        for name, payload in metric.items():
            if not name.casefold().startswith("cvss") or not isinstance(payload, dict):
                continue
            severity = declared.get(str(payload.get("baseSeverity", "")).upper(), 0)
            try:
                score = float(payload.get("baseScore", 0))
            except (TypeError, ValueError):
                score = 0.0
            maximum = max(maximum, severity, 4 if score >= 9.0 else 3 if score >= 7.0 else 2 if score >= 4.0 else 1 if score > 0 else 0)
    return maximum


def event_flags(affected: bool, escalation: bool) -> dict[str, bool]:
    return {
        "affected_field_structural_addition": affected,
        "cna_cvss_escalation_to_high": escalation,
        "overlap": affected and escalation,
        "union": affected or escalation,
    }


def recompute_window(initial: dict | None, changes: list[tuple[str, datetime, dict | None]], observed: datetime, end: datetime) -> tuple[str, str | None, dict[str, bool], list[dict], dict | None]:
    base = cna_container(initial)
    if base is None:
        return "excluded", "asof_missing_cna", event_flags(False, False), [], None
    if record_state(initial) in STATE_WITHDRAWN:
        return "excluded", "withdrawn_at_observation", event_flags(False, False), [], None
    scope, severity = structural_signatures(base), numeric_severity(base)
    affected, escalation, evidence, withdrawal = False, False, [], None
    for commit, commit_time, payload in changes:
        if not observed < commit_time <= end or not isinstance(payload, dict):
            continue
        if record_state(payload) in STATE_WITHDRAWN:
            withdrawal = {"commit": commit, "time": commit_time.isoformat(), "event": "withdraw"}
            evidence.append(withdrawal)
            break
        next_cna = cna_container(payload)
        if next_cna is None:
            continue
        next_scope, next_severity = structural_signatures(next_cna), numeric_severity(next_cna)
        additions = next_scope - scope
        if additions:
            affected = True
            evidence.append({"commit": commit, "time": commit_time.isoformat(), "event": "affected_field_structural_addition", "added_signature_count": len(additions)})
        if severity < HIGH <= next_severity:
            escalation = True
            evidence.append({"commit": commit, "time": commit_time.isoformat(), "event": "cna_cvss_escalation_to_high"})
        scope, severity = next_scope, next_severity
    flags = event_flags(affected, escalation)
    return ("withdraw" if withdrawal else "review" if flags["union"] else "defer"), None, flags, evidence, withdrawal


def changes_by_path(repo: Path, start: str, end: str, years: set[int]) -> dict[str, list[tuple[str, datetime]]]:
    result: dict[str, list[tuple[str, datetime]]] = defaultdict(list)
    for year in sorted(years):
        output = git_text(repo, "log", "--format=@@%H\t%cI", "--name-only", "--reverse", f"{start}..{end}", "--", f"cves/{year}")
        commit = None
        when = None
        for line in output.splitlines():
            if line.startswith("@@"):
                fields = line[2:].split("\t", 1)
                commit, when = fields[0], parse_time(fields[1]) if len(fields) == 2 else None
            elif commit and when and line.startswith(f"cves/{year}/") and line.endswith(".json"):
                result[line].append((commit, when))
    return {path: sorted(items, key=lambda item: (item[1], item[0])) for path, items in result.items()}


def baseline_tags(repo: Path) -> list[tuple[str, datetime]]:
    tags = []
    for line in git_text(repo, "for-each-ref", "--format=%(refname:strip=2)\t%(committerdate:iso-strict)", "refs/tags").splitlines():
        tag, separator, stamp = line.partition("\t")
        if separator and tag.endswith("_baseline"):
            tags.append((tag, parse_time(stamp)))
    return sorted(tags, key=lambda item: (item[1], item[0]))


def evidence_projection(events: list[dict]) -> list[dict]:
    return [{key: event[key] for key in ("commit", "time", "event", "added_signature_count") if key in event} for event in events]


def comparable_label(status: str, reason: str | None, observed: datetime, end: datetime, flags: dict[str, bool], evidence: list[dict], withdrawal: dict | None) -> dict:
    """Mirror the published schema: observation-time exclusions are minimal rows."""
    if status == "excluded":
        return {
            "status": status,
            "reason": reason,
            "t_obs": None,
            "t_end": None,
            "event_flags": None,
            "evidence": [],
            "withdraw_event": None,
        }
    return {
        "status": status,
        "reason": reason,
        "t_obs": observed.isoformat(),
        "t_end": end.isoformat(),
        "event_flags": flags,
        "evidence": evidence_projection(evidence),
        "withdraw_event": withdrawal,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--asof-jsonl", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--max-records", type=int, default=0, help="Smoke-test limit; zero independently audits the full cohort.")
    args = parser.parse_args()
    if args.output.exists() or args.max_records < 0:
        raise RuntimeError("invalid_independent_label_audit_request")
    repo = args.repo.resolve()
    source_rows = [json.loads(line) for line in args.asof_jsonl.read_text(encoding="utf-8").splitlines() if line.strip()]
    frozen = json.loads(args.labels.read_text(encoding="utf-8"))
    label_rows = frozen.get("records")
    if not isinstance(label_rows, list):
        raise RuntimeError("invalid_label_records")
    if args.max_records:
        source_rows = source_rows[:args.max_records]
    labels = {row.get("cve_id"): row for row in label_rows if isinstance(row, dict) and row.get("cve_id")}
    source_ids = [row.get("cve_id") for row in source_rows]
    duplicate_source_ids = sorted(identifier for identifier, count in Counter(source_ids).items() if identifier and count > 1)
    duplicate_label_ids = len(labels) != len(label_rows)
    years = {int(row["cohort_year"]) for row in source_rows if str(row.get("cohort_year", "")).isdigit()}
    tags = baseline_tags(repo)
    tag_times = dict(tags)
    tag_names = set(tag_times)
    commits = {line.split("\t", 1)[0]: line.split("\t", 1)[1] for line in git_text(repo, "for-each-ref", "--format=%(refname:strip=2)\t%(objectname)", "refs/tags").splitlines() if "\t" in line}
    start, end = commits.get("2023-03-28_baseline"), commits.get("2025-12-31_baseline")
    if not start or not end:
        raise RuntimeError("required_frozen_baseline_tag_missing")
    changed = changes_by_path(repo, start, end, years)
    failures, status_counts, outcome_counts, timestamp_failures = [], Counter(), Counter(), Counter()
    reader = ObjectReader(repo)
    try:
        for row in source_rows:
            cve_id = row.get("cve_id")
            frozen_row = labels.get(cve_id)
            if not isinstance(frozen_row, dict):
                failures.append({"cve_id": cve_id, "failure": "label_missing"})
                continue
            if row.get("status") != "included":
                if frozen_row.get("status") != "excluded" or frozen_row.get("reason") != "asof_excluded":
                    failures.append({"cve_id": cve_id, "failure": "asof_exclusion_mismatch"})
                continue
            try:
                published, observed = parse_time(row["t_pub"]), parse_time(row["t_obs"])
                end_time = observed + timedelta(days=90)
            except (KeyError, TypeError, ValueError):
                timestamp_failures["invalid_timestamp"] += 1
                failures.append({"cve_id": cve_id, "failure": "invalid_source_timestamp"})
                continue
            delay = (observed - published).total_seconds() / 3600
            if not 0 <= delay <= 24:
                timestamp_failures["outside_24h"] += 1
                failures.append({"cve_id": cve_id, "failure": "observation_outside_24h", "delay_hours": delay})
            if end_time > FREEZE:
                timestamp_failures["after_freeze"] += 1
                failures.append({"cve_id": cve_id, "failure": "outcome_after_frozen_boundary"})
            if row.get("asof_baseline_tag") not in tag_names:
                failures.append({"cve_id": cve_id, "failure": "asof_baseline_tag_missing"})
                continue
            if observed != tag_times[row["asof_baseline_tag"]]:
                timestamp_failures["asof_tag_time_mismatch"] += 1
                failures.append({"cve_id": cve_id, "failure": "asof_tag_time_mismatch", "t_obs": observed.isoformat(), "tag_time": tag_times[row["asof_baseline_tag"]].isoformat()})
            initial_blob = reader.read_blob(f"{row['asof_baseline_tag']}:{row['path']}")
            if initial_blob is None:
                failures.append({"cve_id": cve_id, "failure": "asof_blob_missing"})
            else:
                if hashlib.sha256(initial_blob).hexdigest() != row.get("asof_record_sha256"):
                    failures.append({"cve_id": cve_id, "failure": "asof_blob_sha256_mismatch"})
                if len(initial_blob) != row.get("record_bytes"):
                    failures.append({"cve_id": cve_id, "failure": "asof_blob_size_mismatch"})
            try:
                parsed_initial = json.loads(initial_blob.decode("utf-8")) if initial_blob is not None else None
            except (UnicodeDecodeError, json.JSONDecodeError):
                parsed_initial = None
            initial = parsed_initial if isinstance(parsed_initial, dict) else None
            payloads = [(commit, when, reader.read_json(f"{commit}:{row['path']}")) for commit, when in changed.get(row["path"], []) if observed < when <= end_time]
            status, reason, flags, evidence, withdrawal = recompute_window(initial, payloads, observed, end_time)
            status_counts[status] += 1
            for key, value in flags.items():
                outcome_counts[key] += int(value and status in {"review", "defer"})
            expected = comparable_label(status, reason, observed, end_time, flags, evidence, withdrawal)
            actual = {
                "status": frozen_row.get("status"),
                "reason": frozen_row.get("reason"),
                "t_obs": frozen_row.get("t_obs"),
                "t_end": frozen_row.get("t_end"),
                "event_flags": frozen_row.get("event_flags"),
                "evidence": evidence_projection(frozen_row.get("evidence") or []),
                "withdraw_event": frozen_row.get("withdraw_event"),
            }
            if expected != actual:
                failures.append({"cve_id": cve_id, "failure": "independent_label_mismatch", "expected": expected, "actual": actual})
    finally:
        reader.close()
    result = {
        "run_id": args.run_id,
        "purpose": "independent Git-object replay of V3 as-of record and deterministic labels; does not import the label builder",
        "repo": str(repo),
        "repo_head": git_text(repo, "rev-parse", "HEAD").strip(),
        "source_asof_sha256": sha256(args.asof_jsonl),
        "labels_sha256": sha256(args.labels),
        "source_record_count": len(source_rows),
        "label_record_count": len(label_rows),
        "duplicate_source_cve_ids": duplicate_source_ids[:100],
        "duplicate_label_cve_ids_detected": duplicate_label_ids,
        "recomputed_status_counts": dict(sorted(status_counts.items())),
        "recomputed_outcome_counts_eligible": dict(sorted(outcome_counts.items())),
        "timestamp_failure_counts": dict(sorted(timestamp_failures.items())),
        "mismatch_count": len(failures),
        "mismatches": failures[:100],
        "passed": not failures and not duplicate_source_ids and not duplicate_label_ids,
        "boundary": "This verifies frozen Git objects and V3's structural signature definition. It does not establish semantic affected-scope expansion, human agreement, model effectiveness, or deployment validity.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "source_records": len(source_rows), "mismatches": len(failures)}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
