"""Independent paired-bootstrap gate for a frozen V3 fusion-model comparison."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import average_precision_score


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--candidate", default="fused_tfidf_structured")
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--replicates", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20261506)
    parser.add_argument("--required-improvement", type=float, default=0.02)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists() or args.replicates != 2000:
        raise RuntimeError("invalid_delta_audit_request")
    report = json.loads(args.report.read_text(encoding="utf-8"))
    rows = [json.loads(line) for line in args.predictions.read_text(encoding="utf-8").splitlines() if line.strip()]
    if report.get("test_predictions_sha256") != sha256(args.predictions):
        raise RuntimeError("prediction_hash_mismatch")
    if args.candidate not in rows[0] or args.baseline not in rows[0]:
        raise RuntimeError("model_score_missing")
    y = np.array([row["label"] for row in rows], dtype=int)
    candidate = np.array([row[args.candidate] for row in rows], dtype=float)
    baseline = np.array([row[args.baseline] for row in rows], dtype=float)
    positive, negative = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    if not len(positive) or not len(negative):
        raise RuntimeError("binary_outcome_required")
    point = float(average_precision_score(y, candidate) - average_precision_score(y, baseline))
    rng, deltas = np.random.default_rng(args.seed), []
    for _ in range(args.replicates):
        index = np.concatenate((rng.choice(positive, len(positive), replace=True), rng.choice(negative, len(negative), replace=True)))
        deltas.append(float(average_precision_score(y[index], candidate[index]) - average_precision_score(y[index], baseline[index])))
    lower, upper = float(np.quantile(deltas, 0.025)), float(np.quantile(deltas, 0.975))
    passed = point >= args.required_improvement and lower > 0
    result = {
        "run_id": args.run_id,
        "purpose": "independent paired-bootstrap fusion-improvement gate from frozen predictions",
        "prediction_sha256": sha256(args.predictions),
        "report_sha256": sha256(args.report),
        "candidate": args.candidate,
        "baseline": args.baseline,
        "bootstrap_replicates": args.replicates,
        "point_pr_auc_difference": point,
        "paired_bootstrap_95": {"lower_95": lower, "upper_95": upper},
        "required": {"minimum_point_improvement": args.required_improvement, "ci_lower_must_exceed": 0.0},
        "passed": passed,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": passed, "point_difference": point, "lower_95": lower, "upper_95": upper}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
