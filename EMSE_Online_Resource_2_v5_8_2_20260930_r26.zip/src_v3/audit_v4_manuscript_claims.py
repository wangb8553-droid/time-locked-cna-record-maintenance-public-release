"""Fail closed on core V5.1 manuscript claim and provenance boundaries."""

from __future__ import annotations

import re
from pathlib import Path


REQUIRED_PHRASES = (
    "### Study design in one view",
"**Table 1. Frozen cohort and outcome support.**",
"**Table 2. Primary 2025 structural-addition ranking.**",
"**Table 3. Fixed-budget deferred structural events for the structured-CNA",
"**Table 4. Sensitivity and generalization checks.**",
    "post-results revision",
"not retrospective preregistration",
"not a semantic claim about versions or populations",
"secondary catalog-overlap analysis is descriptive only",
    "passed 58 tests with zero failures and zero errors",
"PR-AUC change +0.00080 (95% CI -0.01052 to 0.01337)",
    "Constant-score baselines are analytic tie-aware expected recall",
    "The V5.1 event-level taxonomy found",
    "semantic comparability was not assessed",
    "exact hypergeometric 95% reference intervals",
    "V5 independently scans the full 90-day",
    "For the secondary union endpoint (2,454 positives)",
    "within the verified core of directly related work, we did not identify a source",
"This is a bounded task distinction",
    "dependence sensitivities, and the product holdout constrains transfer claims",
    "CVE Program. *Terms of Use*",
    "100-row evidence audit matrix",
)

FORBIDDEN_PHRASES = (
    "52 tests with zero failures",
    "review capacity",
    "pre-registered models",
    "a preregistered comparator",
    "four received restricted full-text review",
)

REQUIRED_SOURCE_DATA = (
    "outputs/table_source_export_v3_20260908_r04/table1_yearly_cohort.csv",
    "outputs/table_source_export_v3_20260908_r04/table2_primary_metrics.csv",
    "outputs/table_source_export_v3_20260908_r04/table3_sensitivity.csv",
    "outputs/v5_1_presentation_20260910_r01/evidence_tables_r02/fixed_budget_deferred_events.csv",
    "outputs/v5_1_presentation_20260910_r01/evidence_tables_r02/group_holdout_fairness.csv",
)


def audit(project_root: Path) -> list[str]:
    manuscript_path = project_root / "docs" / "manuscript_v5_draft.md"
    if not manuscript_path.is_file():
        manuscript_path = project_root / "docs" / "manuscript_v4_draft.md"
    manuscript = manuscript_path.read_text(encoding="utf-8")
    normalized = re.sub(r"\s+", " ", manuscript).casefold()
    failures = [f"missing_required_phrase:{phrase}" for phrase in REQUIRED_PHRASES if phrase.casefold() not in normalized]
    failures.extend(f"forbidden_phrase:{phrase}" for phrase in FORBIDDEN_PHRASES if phrase.casefold() in normalized)
    failures.extend(
        f"missing_table_source:{relative}"
        for relative in REQUIRED_SOURCE_DATA
        if not (project_root / relative).is_file()
    )
    return failures
