"""Fail closed on V3 gates that computational audits cannot establish."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("protocol_audit_json_object_required")
    return value


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--blind-review-manifest", type=Path, required=True)
    parser.add_argument(
        "--human-review-audit",
        type=Path,
        help="Output of audit_v3_human_blind_review.py; required to authorize a next stage.",
    )
    parser.add_argument("--formal-run-audit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("protocol_conformance_output_exists")
    blind, formal = load(args.blind_review_manifest), load(args.formal_run_audit)
    human_audit = load(args.human_review_audit) if args.human_review_audit else None
    human_complete = human_audit is not None and human_audit.get("human_reviews_completed") is True
    multiclass_kappa = (human_audit or {}).get("multiclass", {}).get("cohen_kappa")
    binary_kappa = (human_audit or {}).get("binary_needs_review", {}).get("cohen_kappa")
    kappa_complete = all(isinstance(value, (int, float)) for value in (multiclass_kappa, binary_kappa))
    kappa_passes = kappa_complete and min(float(multiclass_kappa), float(binary_kappa)) >= 0.80
    blocking = []
    evidence_failures = []
    if human_audit is None:
        evidence_failures.append("human_review_audit_not_supplied")
    else:
        if human_audit.get("template_manifest_sha256") != sha256(args.blind_review_manifest):
            evidence_failures.append("human_review_audit_template_hash_mismatch")
        if human_audit.get("case_count") != 200:
            evidence_failures.append("human_review_audit_case_count_not_200")
        reviewer_ids = human_audit.get("reviewer_ids")
        if (
            not isinstance(reviewer_ids, list)
            or len(reviewer_ids) != 2
            or not all(isinstance(item, str) and item.strip() for item in reviewer_ids)
            or reviewer_ids[0] == reviewer_ids[1]
        ):
            evidence_failures.append("human_review_audit_reviewer_identity_invalid")
        if human_audit.get("independence_attested") is not True:
            evidence_failures.append("human_review_audit_independence_not_attested")
        if human_audit.get("reviewer_expertise_self_declared") is not True:
            evidence_failures.append("human_review_audit_expertise_not_declared")
        if human_audit.get("kappa_passed") is not True:
            evidence_failures.append("human_review_audit_kappa_pass_flag_missing_or_false")
    if not human_complete:
        blocking.append("two_independent_human_blind_reviews_not_completed")
    if not kappa_complete:
        blocking.append("cohen_kappa_not_computed")
    if kappa_complete and not kappa_passes:
        blocking.append("cohen_kappa_below_0_80_or_missing")
    blocking.extend(evidence_failures)
    result = {
        "run_id": args.run_id,
        "purpose": "V3 protocol-conformance gate separate from computational run audits",
        "blind_review_manifest_sha256": sha256(args.blind_review_manifest),
        "human_review_audit_sha256": sha256(args.human_review_audit) if args.human_review_audit else None,
        "formal_run_audit_sha256": sha256(args.formal_run_audit),
        "computational_artifacts_passed": formal.get("passed") is True,
        "human_review_gate": {
            "case_count": blind.get("case_count"),
            "per_class": blind.get("per_class"),
            "human_reviews_completed": human_complete,
            "kappa_computed": kappa_complete,
            "multiclass_cohen_kappa": multiclass_kappa,
            "binary_cohen_kappa": binary_kappa,
            "kappa_threshold": 0.80,
            "passes": human_complete and kappa_complete and kappa_passes and not evidence_failures,
        },
        "publication_or_next_stage_authorized": not blocking and formal.get("passed") is True,
        "blocking_gates": blocking,
        "permitted_while_blocked": [
            "source-preserving literature retrieval and substantive reading",
            "documentation, software testing, and reproducibility packaging",
            "human-review recruitment and independent completion",
        ],
        "prohibited_while_blocked": [
            "QLoRA training or inference ablation",
            "KEV stress analysis",
            "release freeze or submission-ready completion claim",
            "claims that human agreement has been established",
        ],
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"authorized": result["publication_or_next_stage_authorized"], "blocking_gates": blocking}))
    return 0 if result["publication_or_next_stage_authorized"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
