"""Paired profile-ablation differences for identical V3 test IDs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import average_precision_score


MODELS = ("structured_cna", "fused_tfidf_structured", "tfidf_word_character")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--full-predictions", type=Path, required=True)
    parser.add_argument("--ablated-predictions", type=Path, required=True)
    parser.add_argument("--full-report", type=Path, required=True)
    parser.add_argument("--ablated-report", type=Path, required=True)
    parser.add_argument("--replicates", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20261606)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists() or args.replicates != 2000:
        raise RuntimeError("invalid_profile_delta_request")
    full = [json.loads(line) for line in args.full_predictions.read_text(encoding="utf-8").splitlines() if line.strip()]
    ablated = [json.loads(line) for line in args.ablated_predictions.read_text(encoding="utf-8").splitlines() if line.strip()]
    key = lambda row: (row["cve_id"], row["t_obs"])
    if [key(row) for row in full] != [key(row) for row in ablated] or [row["label"] for row in full] != [row["label"] for row in ablated]:
        raise RuntimeError("profile_test_rows_not_identical")
    y = np.array([row["label"] for row in full], dtype=int)
    positive, negative = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    if not len(positive) or not len(negative):
        raise RuntimeError("binary_outcome_required")
    rng = np.random.default_rng(args.seed)
    result_models = {}
    for index, model in enumerate(MODELS):
        full_scores = np.array([row[model] for row in full], dtype=float)
        ablated_scores = np.array([row[model] for row in ablated], dtype=float)
        values = []
        local_rng = np.random.default_rng(args.seed + index)
        for _ in range(args.replicates):
            sample = np.concatenate((local_rng.choice(positive, len(positive), replace=True), local_rng.choice(negative, len(negative), replace=True)))
            values.append(float(average_precision_score(y[sample], full_scores[sample]) - average_precision_score(y[sample], ablated_scores[sample])))
        result_models[model] = {
            "point_pr_auc_difference_full_minus_ablated": float(average_precision_score(y, full_scores) - average_precision_score(y, ablated_scores)),
            "paired_bootstrap_95": {"lower_95": float(np.quantile(values, 0.025)), "upper_95": float(np.quantile(values, 0.975))},
        }
    result = {
        "run_id": args.run_id,
        "purpose": "paired identity-ablation sensitivity from identical frozen test rows",
        "full_predictions_sha256": sha256(args.full_predictions),
        "ablated_predictions_sha256": sha256(args.ablated_predictions),
        "full_report_sha256": sha256(args.full_report),
        "ablated_report_sha256": sha256(args.ablated_report),
        "record_count": len(full),
        "positive_count": int(y.sum()),
        "bootstrap_replicates": args.replicates,
        "models": result_models,
        "passed": True,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": True, "records": len(full), "models": len(result_models)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
