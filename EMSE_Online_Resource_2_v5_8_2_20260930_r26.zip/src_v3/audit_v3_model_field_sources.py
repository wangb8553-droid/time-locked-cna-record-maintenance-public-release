"""Independently verify every V3 model row against its as-of CNA Git blob.

No feature-preparation module is imported. This verifier has its own Git blob
reader and feature extraction, then checks that all model values arise from the
declared CNA allow-list at the frozen observation tag. Provider metadata is
accepted only for the separately named evaluation-group column.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path


OUTCOMES = ("affected_field_structural_addition", "cna_cvss_escalation_to_high", "overlap", "union")
ALLOWED_CNA = {"affected", "descriptions", "metrics", "problemTypes", "references", "title"}
OUTPUT_COLUMNS = {"cve_id", "t_obs", "cohort_year", "label_status", "asof_record_sha256", *(f"outcome_{name}" for name in OUTCOMES)}
STRUCTURED_COLUMNS = {"title_present", "description_count", "affected_count", "version_entry_count", "vendor_count", "product_count", "reference_count", "reference_host_count", "metric_count", "max_cvss_band", "cwe", "vendors", "products", "reference_hosts"}
TEXT_COLUMNS = {"text"}
EVALUATION_ONLY_COLUMNS = {"cna_group"}
EXPECTED_COLUMNS = OUTPUT_COLUMNS | STRUCTURED_COLUMNS | TEXT_COLUMNS | EVALUATION_ONLY_COLUMNS
FORBIDDEN_TOKENS = ("adp", "nvd", "kev", "epss", "post_t_obs", "current_web", "provider_metadata")


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class GitBlobs:
    def __init__(self, repo: Path) -> None:
        self.process = subprocess.Popen(["git", "-C", str(repo), "cat-file", "--batch"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert self.process.stdin is not None and self.process.stdout is not None

    def get(self, spec: str) -> bytes | None:
        assert self.process.stdin is not None and self.process.stdout is not None
        self.process.stdin.write(spec.encode("utf-8") + b"\n")
        self.process.stdin.flush()
        header = self.process.stdout.readline().decode("utf-8", errors="strict").strip().split()
        if len(header) == 2 and header[1] == "missing":
            return None
        if len(header) != 3 or header[1] != "blob":
            raise RuntimeError("unexpected_git_blob_header")
        payload = self.process.stdout.read(int(header[2]))
        self.process.stdout.read(1)
        return payload

    def close(self) -> None:
        if self.process.stdin:
            self.process.stdin.close()
        self.process.wait(timeout=30)
        if self.process.returncode:
            raise RuntimeError("git_blob_reader_failed")


def english_descriptions(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(row.get("value", "")).strip() for row in value if isinstance(row, dict) and row.get("lang") == "en" and str(row.get("value", "")).strip()]


def cwes(value: object) -> list[str]:
    result = []
    if not isinstance(value, list):
        return result
    for entry in value:
        descriptions = entry.get("descriptions") if isinstance(entry, dict) else None
        if not isinstance(descriptions, list):
            continue
        result.extend(str(row["cweId"]).strip() for row in descriptions if isinstance(row, dict) and row.get("cweId"))
    return sorted(set(result))


def cvss_band(value: object) -> int:
    declared = {"NONE": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
    best = 0
    if not isinstance(value, list):
        return best
    for metric in value:
        if not isinstance(metric, dict):
            continue
        for name, detail in metric.items():
            if not name.casefold().startswith("cvss") or not isinstance(detail, dict):
                continue
            value_band = declared.get(str(detail.get("baseSeverity", "")).upper(), 0)
            try:
                score = float(detail.get("baseScore", 0))
            except (TypeError, ValueError):
                score = 0.0
            best = max(best, value_band, 4 if score >= 9 else 3 if score >= 7 else 2 if score >= 4 else 1 if score > 0 else 0)
    return best


def extract(record: dict) -> dict:
    containers = record.get("containers")
    cna = containers.get("cna") if isinstance(containers, dict) else None
    if not isinstance(cna, dict):
        raise RuntimeError("missing_cna")
    descriptions = english_descriptions(cna.get("descriptions"))
    title = str(cna.get("title", "")).strip() if cna.get("title") else ""
    affected = cna.get("affected") if isinstance(cna.get("affected"), list) else []
    vendors = sorted({str(item.get("vendor", "")).strip().casefold() for item in affected if isinstance(item, dict) and str(item.get("vendor", "")).strip()})
    products = sorted({str(item.get("product", "")).strip().casefold() for item in affected if isinstance(item, dict) and str(item.get("product", "")).strip()})
    version_entries = sum(len(item.get("versions", [])) for item in affected if isinstance(item, dict) and isinstance(item.get("versions"), list))
    references = cna.get("references") if isinstance(cna.get("references"), list) else []
    hosts = []
    for reference in references:
        url = reference.get("url") if isinstance(reference, dict) else None
        if isinstance(url, str) and "://" in url:
            hosts.append(url.split("://", 1)[1].split("/", 1)[0].casefold())
    provider = cna.get("providerMetadata") if isinstance(cna.get("providerMetadata"), dict) else {}
    group = next((str(provider.get(name, "")).strip().casefold() for name in ("shortName", "orgId") if str(provider.get(name, "")).strip()), "__missing__")
    cwe = cwes(cna.get("problemTypes"))
    return {
        "text": " ".join([title, *descriptions, *cwe]),
        "title_present": int(bool(title)),
        "description_count": len(descriptions),
        "affected_count": len(affected),
        "version_entry_count": version_entries,
        "vendor_count": len(vendors),
        "product_count": len(products),
        "reference_count": len(references),
        "reference_host_count": len(set(hosts)),
        "metric_count": len(cna.get("metrics", [])) if isinstance(cna.get("metrics"), list) else 0,
        "max_cvss_band": cvss_band(cna.get("metrics")),
        "cwe": "|".join(cwe) or "__missing__",
        "vendors": "|".join(vendors) or "__missing__",
        "products": "|".join(products) or "__missing__",
        "reference_hosts": "|".join(sorted(set(hosts))) or "__missing__",
        "cna_group": group,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--asof-jsonl", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("model_field_audit_output_exists")
    manifest = json.loads(args.model_manifest.read_text(encoding="utf-8"))
    source = {row["cve_id"]: row for row in (json.loads(line) for line in args.asof_jsonl.read_text(encoding="utf-8").splitlines() if line.strip())}
    labels = {row["cve_id"]: row for row in json.loads(args.labels.read_text(encoding="utf-8"))["records"]}
    model_rows = [json.loads(line) for line in args.model_rows.read_text(encoding="utf-8").splitlines() if line.strip()]
    failures, field_failures = [], Counter()
    expected_schema = None
    blob_reader = GitBlobs(args.repo.resolve())
    try:
        for model in model_rows:
            cve_id = model.get("cve_id")
            keys = set(model)
            if expected_schema is None:
                expected_schema = keys
            elif keys != expected_schema:
                failures.append({"cve_id": cve_id, "failure": "inconsistent_model_row_schema"})
            source_row, label = source.get(cve_id), labels.get(cve_id)
            if not source_row or not label:
                failures.append({"cve_id": cve_id, "failure": "missing_source_or_label"})
                continue
            if source_row.get("status") != "included" or label.get("status") not in {"review", "defer"}:
                failures.append({"cve_id": cve_id, "failure": "model_row_not_binary_eligible"})
                continue
            for name, expected in (("t_obs", source_row.get("t_obs")), ("cohort_year", source_row.get("cohort_year")), ("label_status", label.get("status")), ("asof_record_sha256", source_row.get("asof_record_sha256"))):
                if model.get(name) != expected:
                    failures.append({"cve_id": cve_id, "failure": f"provenance_mismatch:{name}"})
            for outcome in OUTCOMES:
                if model.get(f"outcome_{outcome}") != int(bool(label["event_flags"][outcome])):
                    failures.append({"cve_id": cve_id, "failure": f"label_mismatch:{outcome}"})
            blob = blob_reader.get(f"{source_row['asof_baseline_tag']}:{source_row['path']}")
            if blob is None:
                failures.append({"cve_id": cve_id, "failure": "asof_blob_missing"})
                continue
            if sha256(blob) != source_row.get("asof_record_sha256"):
                failures.append({"cve_id": cve_id, "failure": "asof_blob_hash_mismatch"})
            try:
                expected_features = extract(json.loads(blob.decode("utf-8")))
            except (UnicodeDecodeError, json.JSONDecodeError, RuntimeError) as error:
                failures.append({"cve_id": cve_id, "failure": f"asof_feature_extraction_failed:{type(error).__name__}"})
                continue
            for field, expected in expected_features.items():
                if model.get(field) != expected:
                    field_failures[field] += 1
                    if len(failures) < 100:
                        failures.append({"cve_id": cve_id, "failure": f"feature_mismatch:{field}"})
    finally:
        blob_reader.close()
    actual_schema = expected_schema or set()
    schema_failures = {
        "missing_columns": sorted(EXPECTED_COLUMNS - actual_schema),
        "unexpected_columns": sorted(actual_schema - EXPECTED_COLUMNS),
        "forbidden_token_columns": sorted(name for name in actual_schema if any(token in name.casefold() for token in FORBIDDEN_TOKENS)),
    }
    manifest_checks = {
        "row_count_matches": manifest.get("row_count") == len(model_rows),
        "model_rows_sha256_matches": manifest.get("model_rows_sha256") == sha256(args.model_rows.read_bytes()),
        "allowed_cna_fields_matches": set(manifest.get("allowed_cna_fields", [])) == ALLOWED_CNA,
        "evaluation_only_fields_matches": set(manifest.get("evaluation_only_fields", [])) == {"cna_group", "vendors", "products"},
    }
    passed = not failures and not any(schema_failures.values()) and all(manifest_checks.values())
    result = {
        "run_id": args.run_id,
        "purpose": "independent raw-Git CNA field-source and future-input audit for frozen V3 model rows",
        "asof_sha256": sha256(args.asof_jsonl.read_bytes()),
        "labels_sha256": sha256(args.labels.read_bytes()),
        "model_rows_sha256": sha256(args.model_rows.read_bytes()),
        "model_row_count": len(model_rows),
        "model_feature_columns": sorted((actual_schema - OUTPUT_COLUMNS) - EVALUATION_ONLY_COLUMNS),
        "evaluation_only_columns": sorted(actual_schema & EVALUATION_ONLY_COLUMNS),
        "schema_failures": schema_failures,
        "manifest_checks": manifest_checks,
        "feature_mismatch_counts": dict(sorted(field_failures.items())),
        "failure_count": len(failures),
        "failures": failures[:100],
        "passed": passed,
        "boundary": "The cna_group column is verified as evaluation metadata only. This audit does not establish model generalization, semantic scope expansion, human agreement, or deployment validity.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": passed, "rows": len(model_rows), "failure_count": len(failures)}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
