"""Export source data for the V4 KEV descriptive supplementary table."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise RuntimeError("kev_table_output_exists")
    analysis = json.loads(args.analysis.read_text(encoding="utf-8"))
    audit = json.loads(args.audit.read_text(encoding="utf-8"))
    if audit.get("passed") is not True or audit.get("analysis_sha256") != sha256(args.analysis):
        raise RuntimeError("kev_table_requires_passing_hash_bound_audit")
    args.output_dir.mkdir(parents=True)
    table = args.output_dir / "table4_kev_snapshot_overlap.csv"
    fields = [
        "capacity_fraction", "selected_record_count", "cohort_kev_count",
        "selected_kev_count", "unselected_kev_count", "kev_capture_fraction",
        "selected_kev_proportion", "selected_kev_proportion_lower_95",
        "selected_kev_proportion_upper_95",
    ]
    with table.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in analysis["capacities"]:
            interval = row["selected_kev_proportion_wilson_95"]
            writer.writerow({
                **{key: row[key] for key in fields[:7]},
                "selected_kev_proportion_lower_95": interval["lower_95"],
                "selected_kev_proportion_upper_95": interval["upper_95"],
            })
    manifest = {
        "run_id": args.output_dir.name,
        "purpose": "V4 KEV snapshot-overlap source data; descriptive only",
        "analysis_sha256": sha256(args.analysis),
        "audit_sha256": sha256(args.audit),
        "table": {"path": table.name, "sha256": sha256(table), "bytes": table.stat().st_size},
        "boundaries": analysis["boundaries"],
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    (args.output_dir / "table4_kev_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": args.output_dir.name, "rows": len(analysis["capacities"])}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
