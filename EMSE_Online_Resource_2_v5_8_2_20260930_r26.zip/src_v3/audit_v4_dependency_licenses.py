"""Capture package metadata for a dependency-license review checkpoint.

Package metadata is evidence for triage only. It is not a substitute for
reviewing authoritative licence texts before redistribution.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata as metadata
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lock", action="append", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("dependency_license_output_exists")
    package_names = set()
    lock_files = []
    for lock in args.lock:
        lock_files.append({"path": str(lock), "sha256": sha256(lock)})
        for line in lock.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            name = line.split("==", 1)[0].split(" @ ", 1)[0].strip()
            if name:
                package_names.add(name)
    packages = []
    for name in sorted(package_names, key=str.casefold):
        try:
            dist = metadata.distribution(name)
            packages.append({
                "name": name,
                "version": dist.version,
                "metadata_license": dist.metadata.get("License"),
                "license_classifiers": dist.metadata.get_all("Classifier") or [],
                "license_files": sorted(str(item) for item in dist.files or [] if item.name.upper() in {"LICENSE", "LICENSE.TXT", "COPYING", "NOTICE"}),
                "status": "metadata_only_authoritative_text_review_pending",
            })
        except metadata.PackageNotFoundError:
            packages.append({"name": name, "status": "not_installed_in_audited_environment"})
    result = {
        "run_id": args.run_id,
        "purpose": "dependency licence metadata inventory; not legal clearance",
        "python": sys.version,
        "platform": platform.platform(),
        "lock_files": lock_files,
        "packages": packages,
        "package_count": len(packages),
        "authoritative_text_review_complete": False,
        "public_release_authorized": False,
        "limitation": "importlib metadata can be absent, abbreviated, or inconsistent with bundled third-party licence texts; review authoritative licence files before release.",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": args.run_id, "package_count": len(packages), "authoritative_text_review_complete": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
