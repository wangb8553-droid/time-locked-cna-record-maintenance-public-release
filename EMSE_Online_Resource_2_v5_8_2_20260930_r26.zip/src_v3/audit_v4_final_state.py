"""Audit V4 local computational completion without overclaiming public release."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("v4_final_audit_json_object_required")
    return value


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--kev-audit", type=Path, required=True)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--manuscript", type=Path, required=True)
    parser.add_argument("--citation-evidence", type=Path, required=True)
    parser.add_argument("--test-audit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("v4_final_audit_output_exists")
    protocol, kev, inventory = load(args.protocol), load(args.kev_audit), load(args.inventory)
    test_audit = load(args.test_audit)
    manuscript = args.manuscript.read_text(encoding="utf-8")
    citation_evidence = args.citation_evidence.read_text(encoding="utf-8")
    failures = []
    if protocol.get("computational_gate_passed") is not True:
        failures.append("v4_computational_gate_not_passed")
    if protocol.get("kev_descriptive_analysis_authorized") is not True:
        failures.append("kev_was_not_authorized")
    if protocol.get("human_review", {}).get("claim_permitted") is not False:
        failures.append("human_claim_boundary_invalid")
    if kev.get("passed") is not True:
        failures.append("kev_independent_audit_not_passed")
    if inventory.get("computational_evidence_complete") is not True:
        failures.append("inventory_computational_state_invalid")
    if inventory.get("public_release_authorized") is not False:
        failures.append("inventory_improperly_authorizes_public_release")
    if "citation needed" in manuscript.lower():
        failures.append("manuscript_has_unresolved_citation_placeholder")
    if "## Rejected candidates" not in citation_evidence or "Support boundary" not in citation_evidence:
        failures.append("citation_evidence_incomplete")
    if test_audit.get("status") != "passed" or test_audit.get("return_code") != 0:
        failures.append("locked_environment_test_audit_not_passed")
    result = {
        "run_id": args.run_id,
        "purpose": "V4 local computational completion audit; not publication or public-release authorization",
        "evidence": {
            "protocol": {"sha256": digest(args.protocol), "path": str(args.protocol)},
            "kev_audit": {"sha256": digest(args.kev_audit), "path": str(args.kev_audit)},
            "inventory": {"sha256": digest(args.inventory), "path": str(args.inventory)},
            "manuscript": {"sha256": digest(args.manuscript), "path": str(args.manuscript)},
            "citation_evidence": {"sha256": digest(args.citation_evidence), "path": str(args.citation_evidence)},
            "test_audit": {"sha256": digest(args.test_audit), "path": str(args.test_audit)},
        },
        "local_computational_analysis_complete": not failures,
        "public_release_authorized": False,
        "publication_claim_permitted": False,
        "remaining_external_release_requirements": inventory.get("external_release_requirements", []),
        "failures": failures,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"local_computational_analysis_complete": not failures, "public_release_authorized": False, "failures": failures}))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
