"""Fail-closed terminal audit for one formal V3 group-held-out sensitivity."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


REQUIRED_MODELS = {
    "prevalence",
    "year_only",
    "structured_cna",
    "tfidf_word_character",
    "fused_tfidf_structured",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--metric-audit", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--input-reference", type=Path, required=True)
    parser.add_argument("--time-lock-audit", type=Path, required=True)
    parser.add_argument("--runner", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("group_holdout_audit_output_exists")

    report, metrics, manifest, reference, time_lock = (
        load(path)
        for path in (
            args.report,
            args.metric_audit,
            args.model_manifest,
            args.input_reference,
            args.time_lock_audit,
        )
    )
    failures: list[str] = []

    def require(condition: bool, name: str) -> None:
        if not condition:
            failures.append(name)

    prediction_hash = sha256(args.predictions)
    report_hash = sha256(args.report)
    require(report.get("formal") is True, "report_not_formal")
    require(report.get("bootstrap_replicates") == 2000, "report_bootstrap_not_2000")
    require(report.get("group") in {"vendor", "product", "cna"}, "invalid_group")
    require(not report.get("train_test_group_overlap"), "train_test_group_overlap")
    require(report.get("split_counts", {}).get("heldout_test_positive", 0) >= 100, "heldout_positive_gate_failed")
    require(report.get("test_predictions_sha256") == prediction_hash, "report_prediction_hash_mismatch")
    require(metrics.get("passed") is True, "independent_metric_audit_failed")
    require(metrics.get("bootstrap_replicates") == 2000, "metric_audit_bootstrap_not_2000")
    require(metrics.get("prediction_sha256") == prediction_hash, "metric_audit_prediction_hash_mismatch")
    require(metrics.get("report_sha256") == report_hash, "metric_audit_report_hash_mismatch")
    require(report.get("model_rows_sha256") == manifest.get("model_rows_sha256"), "model_rows_hash_mismatch")
    require(report.get("model_manifest_sha256") == sha256(args.model_manifest), "model_manifest_hash_mismatch")
    require(report.get("v3_input_reference_sha256") == sha256(args.input_reference), "input_reference_hash_mismatch")
    require(reference.get("passed") is True, "input_reference_not_passed")
    require(time_lock.get("passed") is True, "time_lock_audit_failed")
    require(time_lock.get("model_rows_sha256") == manifest.get("model_rows_sha256"), "time_lock_model_rows_hash_mismatch")
    require(set(report.get("test_models", {})) == REQUIRED_MODELS, "required_model_set_mismatch")
    runner_source = args.runner.read_text(encoding="utf-8")
    require("providerMetadata" not in runner_source, "runner_mentions_prohibited_provider_metadata")

    result = {
        "run_id": args.run_id,
        "purpose": "terminal, fail-closed audit for one V3 group-held-out sensitivity",
        "group_run_id": report.get("run_id"),
        "group": report.get("group"),
        "report_sha256": report_hash,
        "prediction_sha256": prediction_hash,
        "metric_audit_sha256": sha256(args.metric_audit),
        "heldout_test_positive": report.get("split_counts", {}).get("heldout_test_positive"),
        "train_test_group_overlap": report.get("train_test_group_overlap"),
        "bootstrap_replicates": report.get("bootstrap_replicates"),
        "failures": failures,
        "passed": not failures,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "failures": failures}))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
