"""Audit a same-code V3 rerun without mislabelling it as independent validation."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


MODELS = ("prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured")
PROTOCOL = "fixed chronological V3 evaluation; no random split or test tuning"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--first-report", type=Path, required=True)
    parser.add_argument("--first-predictions", type=Path, required=True)
    parser.add_argument("--second-report", type=Path, required=True)
    parser.add_argument("--second-predictions", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("rerun_audit_output_exists")
    first, second = (json.loads(path.read_text(encoding="utf-8")) for path in (args.first_report, args.second_report))
    failures: list[str] = []

    def require(condition: bool, failure: str) -> None:
        if not condition:
            failures.append(failure)

    require(first.get("run_id") != second.get("run_id"), "run_ids_not_distinct")
    require(first.get("protocol") == PROTOCOL and second.get("protocol") == PROTOCOL, "protocol_not_v3_chronological")
    require(first.get("formal") is True and second.get("formal") is True, "rerun_not_formal")
    require(first.get("bootstrap_replicates") == 2000 and second.get("bootstrap_replicates") == 2000, "bootstrap_count_not_2000")
    for field in ("outcome", "profile", "v3_input_reference_sha256", "v3_input_reference_run_id", "model_rows_sha256", "model_manifest_sha256"):
        require(first.get(field) == second.get(field), f"mismatch:{field}")
    require(first.get("test_predictions_sha256") == sha256(args.first_predictions), "first_prediction_hash_mismatch")
    require(second.get("test_predictions_sha256") == sha256(args.second_predictions), "second_prediction_hash_mismatch")
    differences = {}
    for model in MODELS:
        first_metrics = first.get("test_models", {}).get(model, {}).get("metrics", {})
        second_metrics = second.get("test_models", {}).get(model, {}).get("metrics", {})
        if not first_metrics or not second_metrics:
            failures.append(f"missing_test_metrics:{model}")
            continue
        differences[model] = {
            "pr_auc_absolute_difference": abs(float(first_metrics["pr_auc"]) - float(second_metrics["pr_auc"])),
            "ece_10_absolute_difference": abs(float(first_metrics["ece_10"]) - float(second_metrics["ece_10"])),
        }
    require(all(value["pr_auc_absolute_difference"] <= 0.01 and value["ece_10_absolute_difference"] <= 0.02 for value in differences.values()), "metric_tolerance_failed")
    result = {
        "run_id": args.run_id,
        "purpose": "deterministic reproducibility rerun audit; not independent implementation validation",
        "first_model_run_id": first.get("run_id"),
        "second_model_run_id": second.get("run_id"),
        "outcome": first.get("outcome"),
        "profile": first.get("profile"),
        "first_report_sha256": sha256(args.first_report),
        "second_report_sha256": sha256(args.second_report),
        "first_prediction_sha256": sha256(args.first_predictions),
        "second_prediction_sha256": sha256(args.second_predictions),
        "tolerances": {"pr_auc": 0.01, "ece_10": 0.02},
        "differences": differences,
        "failures": failures,
        "passed": not failures,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "failures": failures}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
