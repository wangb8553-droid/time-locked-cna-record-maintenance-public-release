"""Create an evidence-backed requirement matrix for V4 completion review."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--kev-audit", type=Path, required=True)
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--source-reuse", type=Path)
    parser.add_argument("--test-audit", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("v4_completion_matrix_output_exists")
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    kev = json.loads(args.kev_audit.read_text(encoding="utf-8"))
    inventory = json.loads(args.inventory.read_text(encoding="utf-8"))
    computational = protocol.get("computational_gate_passed") is True and kev.get("passed") is True
    items = [
        {"requirement": 1, "status": "complete_with_post_results_revision", "evidence": ["V4_OBJECTIVE.md", "docs/protocol_revision_v4_20260908.md"]},
        {"requirement": 2, "status": "complete", "evidence": ["outputs/independent_label_audit_v3_20260908_r04/independent_label_audit.json"]},
        {"requirement": 3, "status": "complete", "evidence": ["outputs/independent_label_audit_v3_20260908_r04/independent_label_audit.json", "outputs/model_field_source_audit_v3_20260908_r01/model_field_source_audit.json"]},
        {"requirement": 4, "status": "complete", "evidence": ["outputs/table_source_export_v3_20260908_r04/table1_yearly_cohort.csv"]},
        {"requirement": 5, "status": "not_applicable_in_v4", "evidence": ["outputs/protocol_conformance_v4_20260908_r01/protocol_conformance.json"], "boundary": "No human-review or kappa claim is made."},
        {"requirement": 6, "status": "complete", "evidence": ["outputs/formal_run_audit_v3_structural_full_20260906_r02/formal_run_audit.json", "outputs/formal_run_audit_v3_union_full_20260906_r01/formal_run_audit.json"]},
        {"requirement": 7, "status": "complete_with_negative_fusion_hypothesis", "evidence": ["outputs/metric_audit_v3_structural_full_20260906_r01/metric_audit.json", "outputs/profile_delta_audit_v3_structural_20260906_r01/profile_delta_audit.json"]},
        {"requirement": 8, "status": "optional_not_executed", "evidence": ["docs/research_protocol_v4.md"], "boundary": "QLoRA is not a completion condition and no result is claimed."},
        {"requirement": 9, "status": "complete_descriptive_only", "evidence": ["outputs/kev_descriptive_v4_20260908_r01/kev_descriptive.json", "outputs/kev_descriptive_audit_v4_20260908_r01/kev_descriptive_audit.json"]},
        {"requirement": 10, "status": "partial_external_release_blockers", "evidence": [
            str(args.inventory), "docs/release_audit_checklist_v4.md",
            "docs/release_authorization_dossier_v4_20260909.md",
            "docs/objective_evidence_ledger_v4_20260909.md",
            "docs/citation_evidence_v4_20260908.md",
            "docs/references_verified_v4.ris",
        ], "open_requirements": inventory.get("external_release_requirements", [])},
    ]
    if args.source_reuse:
        source = json.loads(args.source_reuse.read_text(encoding="utf-8"))
        items[1]["evidence"].append("outputs/source_reuse_audit_v4_20260908_r02/source_reuse_audit.json")
        items[1]["source_reuse_audit_passed"] = all(
            row.get("fsck_connectivity_exit") == 0 and not row.get("missing_required_tags")
            for row in source.get("sources", [])
        )
    if args.test_audit:
        test_audit = json.loads(args.test_audit.read_text(encoding="utf-8"))
        items[9]["evidence"].append(str(args.test_audit))
        items[9]["tests_passed"] = test_audit.get("status") == "passed"
    result = {
        "run_id": args.run_id,
        "purpose": "V4 requirement-by-requirement completion audit",
        "evidence": {
            "protocol_sha256": digest(args.protocol),
            "kev_audit_sha256": digest(args.kev_audit),
            "inventory_sha256": digest(args.inventory),
        },
        "computational_analysis_complete": computational,
        "all_objective_requirements_complete": False,
        "public_release_authorized": False,
        "items": items,
        "blocking_external_requirements": inventory.get("external_release_requirements", []),
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"computational_analysis_complete": computational, "all_objective_requirements_complete": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
