"""Create a hash-bound V3 input reference without changing V1 or V2."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


SCOPE = "time_locked_cna_affected_field_structural_addition_v3"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_value(repo: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, encoding="utf-8", check=False)
    if result.returncode:
        raise RuntimeError(f"git_command_failed:{' '.join(args)}:{result.stderr.strip()}")
    return result.stdout.strip()


def validate_reference(reference_path: Path, labels_path: Path, asof_path: Path | None = None, cve_repo: Path | None = None) -> dict:
    if not reference_path.is_file():
        raise RuntimeError("v3_input_reference_missing")
    reference = json.loads(reference_path.read_text(encoding="utf-8"))
    if reference.get("scope") != SCOPE or not reference.get("passed"):
        raise RuntimeError("v3_input_reference_not_passed")
    if reference.get("v3_labels_sha256") != sha256(labels_path):
        raise RuntimeError("v3_labels_hash_mismatch")
    if asof_path is not None and reference.get("asof_sha256") != sha256(asof_path):
        raise RuntimeError("v3_asof_hash_mismatch")
    if cve_repo is not None:
        if Path(reference.get("cve_repo", "")).resolve() != cve_repo.resolve():
            raise RuntimeError("v3_cve_repo_path_mismatch")
        if reference.get("cve_repo_head") != git_value(cve_repo, "rev-parse", "HEAD"):
            raise RuntimeError("v3_cve_repo_head_mismatch")
    return reference


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--asof-jsonl", type=Path, required=True)
    parser.add_argument("--v3-labels", type=Path, required=True)
    parser.add_argument("--cve-repo", type=Path, required=True)
    parser.add_argument("--v1-source-manifest", type=Path, required=True)
    parser.add_argument("--v2-reference", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("v3_reference_output_exists")

    labels = json.loads(args.v3_labels.read_text(encoding="utf-8"))
    source = json.loads(args.v1_source_manifest.read_text(encoding="utf-8"))
    v2 = json.loads(args.v2_reference.read_text(encoding="utf-8"))
    counts = labels.get("outcome_counts_eligible", {})
    required_outcomes = {"affected_field_structural_addition", "cna_cvss_escalation_to_high", "overlap", "union"}
    passed = (
        labels.get("run_type") == "time_locked_cna_structural_addition_and_cvss_labels_v3"
        and labels.get("source_asof_jsonl_sha256") == sha256(args.asof_jsonl)
        and labels.get("horizon_days") == 90
        and required_outcomes.issubset(counts)
        and source.get("repo_head") == git_value(args.cve_repo, "rev-parse", "HEAD")
        and v2.get("passed") is True
    )
    artifacts = (args.asof_jsonl, args.v3_labels, args.v1_source_manifest, args.v2_reference)
    reference = {
        "run_id": args.run_id,
        "scope": SCOPE,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "passed": bool(passed),
        "asof_sha256": sha256(args.asof_jsonl),
        "v3_labels_sha256": sha256(args.v3_labels),
        "cve_repo": str(args.cve_repo.resolve()),
        "cve_repo_head": git_value(args.cve_repo, "rev-parse", "HEAD"),
        "v2_reference_sha256": sha256(args.v2_reference),
        "artifact_sha256": {str(path.resolve()): sha256(path) for path in artifacts},
        "outcome_counts_eligible": counts,
        "constraints": [
            "Affected-field structural addition is a canonical CNA affected-signature addition, not semantic range containment or affected-scope expansion.",
            "CNA provider metadata is evaluation-only grouping information and must never be a model feature.",
            "No human reliability, exploitability, patch-priority, analyst-replacement, CVSS-forecasting, or deployment-stability claim.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(reference, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": reference["passed"], "v3_labels_sha256": reference["v3_labels_sha256"]}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
