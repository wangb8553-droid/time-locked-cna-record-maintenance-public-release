"""Deterministic leakage-audited group holdout splits for V3.

This helper selects test groups from the fixed 2025 cohort and removes every
training record sharing any selected vendor/product/CNA group token. It is
separate from the model runner so group-disjointness is auditable before model
fitting.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path


GROUP_FIELDS = {"vendor": "vendors", "product": "products", "cna": "cna_group"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def values(row: dict, field: str) -> set[str]:
    raw = str(row[GROUP_FIELDS[field]])
    return {item for item in raw.split("|") if item and item != "__missing__"}


def select_groups(test: list[dict], field: str, outcome: str, count: int) -> list[str]:
    label = "outcome_" + outcome
    support = Counter(token for row in test for token in values(row, field))
    positives = Counter(token for row in test if row[label] for token in values(row, field))
    eligible = [token for token in support if support[token] >= 10 and positives[token] >= 1]
    return sorted(eligible, key=lambda token: (-positives[token], -support[token], token))[:count]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--outcome", choices=("affected_field_structural_addition", "union"), required=True)
    parser.add_argument("--group", choices=tuple(GROUP_FIELDS), required=True)
    parser.add_argument("--group-count", type=int, default=20)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists() or args.group_count <= 0:
        raise RuntimeError("invalid_group_holdout_request")
    rows = [json.loads(line) for line in args.model_rows.read_text(encoding="utf-8").splitlines() if line.strip()]
    train = [row for row in rows if row["t_obs"][:10] <= "2024-06-30"]
    test = [row for row in rows if "2025-01-01" <= row["t_obs"][:10] <= "2025-09-30"]
    groups = select_groups(test, args.group, args.outcome, args.group_count)
    selected = set(groups)
    heldout_test = [row for row in test if values(row, args.group) & selected]
    retained_train = [row for row in train if not (values(row, args.group) & selected)]
    leaked = sorted({token for row in retained_train for token in values(row, args.group)} & selected)
    label = "outcome_" + args.outcome
    result = {
        "run_id": args.run_id,
        "purpose": "deterministic group selection and overlap audit before group-held-out fitting",
        "model_rows_sha256": sha256(args.model_rows),
        "outcome": args.outcome,
        "group": args.group,
        "selected_groups": groups,
        "split_counts": {"original_train": len(train), "purged_train": len(retained_train), "heldout_test": len(heldout_test), "heldout_test_positive": sum(row[label] for row in heldout_test)},
        "train_test_group_overlap": leaked,
        "passed": bool(groups) and not leaked and len({row[label] for row in retained_train}) == 2,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], **result["split_counts"]}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
