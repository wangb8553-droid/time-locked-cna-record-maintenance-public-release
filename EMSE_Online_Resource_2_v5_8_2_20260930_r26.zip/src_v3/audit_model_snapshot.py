"""Independently verify the locally downloaded protocol-pinned Qwen snapshot."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


EXPECTED = {
    "config.json": (659, "18e18afcaccafade98daf13a54092927904649e1dd4eba8299ab717d5d94ff45"),
    "generation_config.json": (242, "e558847a8b4402616f1273797b015104dc266fe4b520056fca88823ba8f8ebe6"),
    "LICENSE": (11343, "832dd9e00a68dd83b3c3fb9f5588dad7dcf337a0db50f7d9483f310cd292e92e"),
    "merges.txt": (1671839, "599bab54075088774b1733fde865d5bd747cbcc7a547c5bc12610e874e26f5e3"),
    "model.safetensors": (988097824, "fdf756fa7fcbe7404d5c60e26bff1a0c8b8aa1f72ced49e7dd0210fe288fb7fe"),
    "README.md": (4917, "b19c806a904db6dc878a0462e70b551f6b7ac78dfbb88c2eb966ca2b9109ae15"),
    "tokenizer_config.json": (7305, "5b5d4f65d0acd3b2d56a35b56d374a36cbc1c8fa5cf3b3febbbfabf22f359583"),
    "tokenizer.json": (7031645, "c0382117ea329cdf097041132f6d735924b697924d6f6fc3945713e96ce87539"),
    "vocab.json": (2776833, "ca10d7e9fb3ed18575dd1e277a2579c16d108e32f27439684afa0e10b1440910"),
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("snapshot_audit_output_exists")
    records = {}
    for name, (expected_size, expected_hash) in EXPECTED.items():
        path = args.model_dir / name
        actual_size = path.stat().st_size if path.is_file() else None
        actual_hash = digest(path) if path.is_file() else None
        records[name] = {"expected_bytes": expected_size, "actual_bytes": actual_size, "expected_sha256": expected_hash, "actual_sha256": actual_hash, "passed": actual_size == expected_size and actual_hash == expected_hash}
    result = {"run_id": args.run_id, "model_id": "Qwen/Qwen2.5-0.5B-Instruct", "pinned_hf_revision": "2b01de6d1108f9b2b5e46a726aa678a359b6c03b", "source": "ModelScope official Qwen mirror, verified against its public API file manifest", "verified_at": datetime.now(timezone.utc).isoformat(), "files": records, "passed": all(row["passed"] for row in records.values())}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "files": len(records)}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
