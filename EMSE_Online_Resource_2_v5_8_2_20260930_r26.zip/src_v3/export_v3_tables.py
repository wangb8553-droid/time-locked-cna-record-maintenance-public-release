"""Export manuscript table source data from hash-bound V3 JSON artifacts."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


FIELD_COLUMNS = (
    "title_present", "description_count", "affected_count", "version_entry_count",
    "vendor_count", "product_count", "reference_count", "reference_host_count",
    "metric_count", "cwe",
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def metric_rows(report: dict) -> list[dict]:
    rows = []
    for model, payload in report["test_models"].items():
        metrics = payload["metrics"]
        interval = payload["bootstrap_95"]
        rows.append({
            "model": model,
            "record_count": metrics["record_count"],
            "positive_count": metrics["positive_count"],
            "pr_auc": metrics["pr_auc"],
            "pr_auc_lower_95": interval["pr_auc"]["lower_95"],
            "pr_auc_upper_95": interval["pr_auc"]["upper_95"],
            "brier": metrics["brier"],
            "brier_lower_95": interval["brier"]["lower_95"],
            "brier_upper_95": interval["brier"]["upper_95"],
            "ece_10": metrics["ece_10"],
            "ece_10_lower_95": interval["ece_10"]["lower_95"],
            "ece_10_upper_95": interval["ece_10"]["upper_95"],
            "recall_at_5_pct": metrics["recall_at_5_pct"],
            "recall_at_10_pct": metrics["recall_at_10_pct"],
            "recall_at_20_pct": metrics["recall_at_20_pct"],
        })
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--profile-delta", type=Path, required=True)
    parser.add_argument("--cluster-cna", type=Path, required=True)
    parser.add_argument("--cluster-month", type=Path, required=True)
    parser.add_argument("--holdout-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise SystemExit("output_dir_exists: " + str(args.output_dir))
    inputs = [args.labels, args.model_rows, args.report, args.profile_delta,
              args.cluster_cna, args.cluster_month]
    inputs += sorted(args.holdout_dir.glob(
        "formal_group_holdout_audit_v3_structural_full_*/formal_group_holdout_audit.json"
    ))
    missing = [str(p) for p in inputs if not p.is_file()]
    if missing:
        raise SystemExit("missing_input_artifacts: " + ", ".join(missing))

    labels = json.loads(args.labels.read_text(encoding="utf-8"))
    report = json.loads(args.report.read_text(encoding="utf-8"))
    delta = json.loads(args.profile_delta.read_text(encoding="utf-8"))
    cluster_cna = json.loads(args.cluster_cna.read_text(encoding="utf-8"))
    cluster_month = json.loads(args.cluster_month.read_text(encoding="utf-8"))
    model_rows = [json.loads(line) for line in args.model_rows.read_text(encoding="utf-8").splitlines() if line]

    yearly = {}
    for row in labels["records"]:
        year = str(row["t_obs"][:4]) if row.get("t_obs") else row["cve_id"].split("-")[1]
        item = yearly.setdefault(year, {"cohort_year": int(year), "source_count": 0, "eligible_count": 0,
                                        "review_count": 0, "defer_count": 0, "withdraw_count": 0,
                                        "excluded_count": 0, "structural_addition": 0,
                                        "cna_cvss_escalation_to_high": 0, "overlap": 0, "union": 0})
        item["source_count"] += 1
        status = row["status"]
        item[status + "_count"] += 1
        if status in {"review", "defer"}:
            item["eligible_count"] += 1
            event_keys = {
                "structural_addition": "affected_field_structural_addition",
                "cna_cvss_escalation_to_high": "cna_cvss_escalation_to_high",
                "overlap": "overlap",
                "union": "union",
            }
            for key, source_key in event_keys.items():
                item[key] += int(row["event_flags"][source_key])
    yearly_rows = []
    for item in sorted(yearly.values(), key=lambda x: x["cohort_year"]):
        item["structural_event_rate"] = item["structural_addition"] / item["eligible_count"]
        item["union_event_rate"] = item["union"] / item["eligible_count"]
        yearly_rows.append(item)

    coverage = []
    n = len(model_rows)
    for field in FIELD_COLUMNS:
        if field == "cwe":
            present = sum(bool(row.get(field)) for row in model_rows)
        elif field.endswith("_count"):
            present = sum(int(row.get(field, 0)) > 0 for row in model_rows)
        else:
            present = sum(bool(row.get(field)) for row in model_rows)
        coverage.append({"field": field, "row_count": n, "present_count": present, "coverage": present / n})

    sensitivity = []
    for model, values in delta["models"].items():
        sensitivity.append({"analysis": "identity_ablation", "model": model,
                            "pr_auc_difference_full_minus_ablated": values["point_pr_auc_difference_full_minus_ablated"],
                            "lower_95": values["paired_bootstrap_95"]["lower_95"],
                            "upper_95": values["paired_bootstrap_95"]["upper_95"]})
    for path in inputs[6:]:
        audit = json.loads(path.read_text(encoding="utf-8"))
        sensitivity.append({"analysis": "group_holdout", "model": "structured_cna",
                            "group": audit["group"], "heldout_test_positive": audit["heldout_test_positive"],
                            "train_test_group_overlap_count": len(audit["train_test_group_overlap"]),
                            "passed": audit["passed"]})
    for analysis, audit in (("cluster_cna", cluster_cna), ("cluster_month", cluster_month)):
        interval = audit["models"]["structured_cna"]["bootstrap_95"]["pr_auc"]
        sensitivity.append({
            "analysis": analysis,
            "model": "structured_cna",
            "group": audit["grouping"],
            "cluster_count": audit["cluster_count"],
            "pr_auc_point": audit["models"]["structured_cna"]["point_estimate"]["pr_auc"],
            "lower_95": interval["lower_95"],
            "upper_95": interval["upper_95"],
            "valid_replicates": interval["valid_replicates"],
            "passed": audit["passed"],
        })

    args.output_dir.mkdir(parents=True)
    write_csv(args.output_dir / "table1_yearly_cohort.csv", yearly_rows, list(yearly_rows[0]))
    write_csv(args.output_dir / "table1_field_coverage.csv", coverage, list(coverage[0]))
    model_table = metric_rows(report)
    write_csv(args.output_dir / "table2_primary_metrics.csv", model_table, list(model_table[0]))
    write_csv(args.output_dir / "table3_sensitivity.csv", sensitivity, sorted({k for row in sensitivity for k in row}))
    provenance = {
        "run_id": args.output_dir.name,
        "purpose": "manuscript table source-data export from frozen V3 artifacts",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "inputs": {str(path.relative_to(args.project_root)): {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in inputs},
        "outputs": {p.name: {"bytes": p.stat().st_size, "sha256": sha256(p)} for p in args.output_dir.iterdir() if p.is_file()},
        "python": sys.version,
        "platform": platform.platform(),
        "final_release_authorized": False,
    }
    (args.output_dir / "table_export_manifest.json").write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": args.output_dir.name, "year_rows": len(yearly_rows), "model_rows": len(model_table), "output": str(args.output_dir)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
