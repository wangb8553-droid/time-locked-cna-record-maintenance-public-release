"""Independent metric recomputation for immutable V3 prediction files.

This module intentionally does not import the model runner.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import average_precision_score, brier_score_loss


MODELS = ("prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured")
BUDGETS = (0.05, 0.10, 0.20)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def capacity(y: np.ndarray, scores: np.ndarray, ids: np.ndarray, budget: float) -> tuple[float, int, int]:
    count = int(np.ceil(len(y) * budget))
    selected = y[np.lexsort((ids, -scores))[:count]]
    caught = int(selected.sum())
    return caught / int(y.sum()), caught, count


def calibration_error(y: np.ndarray, scores: np.ndarray) -> float:
    total = 0.0
    for index in range(10):
        lower, upper = index / 10, (index + 1) / 10
        mask = (scores >= lower) & ((scores < upper) if index < 9 else (scores <= upper))
        if mask.any():
            total += float(mask.mean()) * abs(float(y[mask].mean()) - float(scores[mask].mean()))
    return total


def metric_set(y: np.ndarray, scores: np.ndarray, ids: np.ndarray) -> dict:
    result = {"pr_auc": float(average_precision_score(y, scores)), "brier": float(brier_score_loss(y, scores)), "ece_10": calibration_error(y, scores), "positive_count": int(y.sum()), "record_count": int(len(y))}
    for budget in BUDGETS:
        recall, caught, count = capacity(y, scores, ids, budget)
        key = str(int(budget * 100))
        result[f"recall_at_{key}_pct"] = recall
        result[f"false_deferral_at_{key}_pct"] = int(y.sum() - caught)
        result[f"capacity_at_{key}_pct"] = count
    result["risk_coverage"] = [
        {
            "coverage": budget,
            "deferred_risk": float(
                (y.sum() - capacity(y, scores, ids, budget)[1])
                / max(len(y) - capacity(y, scores, ids, budget)[2], 1)
            ),
        }
        for budget in BUDGETS
    ]
    return result


def bootstrap(y: np.ndarray, scores: np.ndarray, ids: np.ndarray, replicates: int, seed: int) -> dict:
    rng = np.random.default_rng(seed)
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    values = {key: [] for key in ("pr_auc", "brier", "ece_10", "recall_at_5_pct", "recall_at_10_pct", "recall_at_20_pct")}
    for _ in range(replicates):
        index = np.concatenate((rng.choice(pos, len(pos), replace=True), rng.choice(neg, len(neg), replace=True)))
        record = metric_set(y[index], scores[index], ids[index])
        for key in values:
            values[key].append(record[key])
    return {key: {"lower_95": float(np.quantile(value, 0.025)), "upper_95": float(np.quantile(value, 0.975))} for key, value in values.items()}


def numeric_differences(reported, recomputed, prefix: str = "") -> dict[str, float]:
    """Compare a JSON metric tree without importing model-runner code."""
    if isinstance(reported, dict) and isinstance(recomputed, dict):
        if set(reported) != set(recomputed):
            raise RuntimeError(f"metric_key_mismatch:{prefix or 'root'}")
        result: dict[str, float] = {}
        for key in sorted(reported):
            result.update(numeric_differences(reported[key], recomputed[key], f"{prefix}.{key}" if prefix else key))
        return result
    if isinstance(reported, list) and isinstance(recomputed, list):
        if len(reported) != len(recomputed):
            raise RuntimeError(f"metric_length_mismatch:{prefix}")
        result = {}
        for index, (one, two) in enumerate(zip(reported, recomputed)):
            result.update(numeric_differences(one, two, f"{prefix}[{index}]"))
        return result
    if isinstance(reported, (int, float)) and isinstance(recomputed, (int, float)):
        return {prefix: abs(float(reported) - float(recomputed))}
    if reported != recomputed:
        raise RuntimeError(f"metric_value_mismatch:{prefix}")
    return {prefix: 0.0}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--bootstrap-seed", type=int, default=20261006)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("metric_audit_output_exists")
    report = json.loads(args.report.read_text(encoding="utf-8"))
    rows = [json.loads(line) for line in args.predictions.read_text(encoding="utf-8").splitlines() if line.strip()]
    y, ids = np.array([row["label"] for row in rows], dtype=int), np.array([row["cve_id"] for row in rows])
    if not len(rows) or len(set(y.tolist())) != 2 or report.get("test_predictions_sha256") != sha256(args.predictions):
        raise RuntimeError("prediction_file_or_hash_invalid")
    replicates = int(report["bootstrap_replicates"])
    recomputed, differences = {}, {}
    for index, model in enumerate(MODELS):
        scores = np.array([row[model] for row in rows], dtype=float)
        one = metric_set(y, scores, ids)
        interval = bootstrap(y, scores, ids, replicates, args.bootstrap_seed + index)
        recomputed[model] = {"metrics": one, "bootstrap_95": interval}
        reported = report["test_models"][model]
        differences[model] = numeric_differences(reported, recomputed[model])
    passed = all(max(values.values()) <= 1e-12 for values in differences.values())
    result = {"run_id": args.run_id, "purpose": "independent prediction-metric audit", "prediction_sha256": sha256(args.predictions), "report_sha256": sha256(args.report), "outcome": report.get("outcome"), "profile": report.get("profile"), "bootstrap_replicates": replicates, "bootstrap_seed": args.bootstrap_seed, "recomputed": recomputed, "absolute_differences": differences, "passed": passed}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": passed, "models": len(MODELS)}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
