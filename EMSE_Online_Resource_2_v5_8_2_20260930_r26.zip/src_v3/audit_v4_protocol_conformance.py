"""Verify V4 computational prerequisites without inferring human validation."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("v4_protocol_json_object_required")
    return value


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require_passed(name: str, path: Path, failures: list[str], evidence: dict) -> None:
    try:
        payload = load(path)
    except (OSError, json.JSONDecodeError, RuntimeError):
        failures.append(f"{name}_unreadable")
        return
    evidence[name] = {"path": str(path), "sha256": digest(path), "passed": payload.get("passed")}
    if payload.get("passed") is not True:
        failures.append(f"{name}_not_passed")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--time-lock", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--field-sources", type=Path, required=True)
    parser.add_argument("--structural-formal", type=Path, required=True)
    parser.add_argument("--union-formal", type=Path, required=True)
    parser.add_argument("--structural-identity", type=Path, required=True)
    parser.add_argument("--union-identity", type=Path, required=True)
    parser.add_argument("--rerun", type=Path, required=True)
    parser.add_argument("--vendor-holdout", type=Path, required=True)
    parser.add_argument("--product-holdout", type=Path, required=True)
    parser.add_argument("--cna-holdout", type=Path, required=True)
    parser.add_argument("--month-cluster", type=Path, required=True)
    parser.add_argument("--cna-cluster", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("v4_protocol_output_exists")

    failures: list[str] = []
    evidence: dict = {}
    for name, path in (
        ("time_lock", args.time_lock),
        ("independent_labels", args.labels),
        ("field_sources", args.field_sources),
        ("structural_formal", args.structural_formal),
        ("union_formal", args.union_formal),
        ("structural_identity", args.structural_identity),
        ("union_identity", args.union_identity),
        ("deterministic_rerun", args.rerun),
        ("vendor_holdout", args.vendor_holdout),
        ("product_holdout", args.product_holdout),
        ("cna_holdout", args.cna_holdout),
        ("month_cluster", args.month_cluster),
        ("cna_cluster", args.cna_cluster),
    ):
        require_passed(name, path, failures, evidence)

    result = {
        "run_id": args.run_id,
        "purpose": "V4 computational-conformance gate; no human-validation inference",
        "revision_status": "post_results_revision_not_retroactively_preregistered",
        "evidence": evidence,
        "human_review": {
            "applicability": "not_applicable",
            "completed": False,
            "claim_permitted": False,
            "reason": "V4 uses deterministic events and independent computation only; no independent human reviewers are available.",
        },
        "computational_gate_passed": not failures,
        "kev_descriptive_analysis_authorized": not failures,
        "qlora_authorized": False,
        "final_release_authorized": False,
        "blocking_gates": failures,
        "prohibited_claims": [
            "human agreement or expert-label reliability",
            "semantic affected-scope expansion",
            "exploitability, first exploitation, patch priority, or analyst benefit",
            "QLoRA performance without a separate executed audit",
            "public release or journal acceptance",
        ],
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"authorized": result["kev_descriptive_analysis_authorized"], "blocking_gates": failures}))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
