"""Fixed chronological CNA-only V2 model evaluation with no human claim."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction import DictVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss

from v2_input_reference import validate_reference


NUMERIC = ("title_present", "description_count", "affected_count", "version_entry_count", "vendor_count", "product_count", "reference_count", "reference_host_count", "metric_count", "max_cvss_band")
CATEGORICAL = ("cohort_year", "cwe", "vendors", "products", "reference_hosts")
BUDGETS = (0.05, 0.10, 0.20)
INT32_MAX = np.iinfo(np.int32).max


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sklearn_csr(matrix) -> csr_matrix:
    """Return an equivalent CSR matrix with sklearn-compatible 32-bit indices.

    SciPy 1.17 can choose 64-bit sparse indices on Windows even for small
    matrices, whereas sklearn 1.9's liblinear path rejects them. This function
    changes representation only and fails rather than truncating an oversized
    matrix.
    """
    value = matrix.tocsr(copy=False)
    if value.shape[0] > INT32_MAX or value.shape[1] > INT32_MAX or value.nnz > INT32_MAX:
        raise RuntimeError("sparse_matrix_exceeds_int32_index_capacity")
    if value.indices.dtype == np.int32 and value.indptr.dtype == np.int32:
        return value
    return csr_matrix(
        (value.data, value.indices.astype(np.int32, copy=False), value.indptr.astype(np.int32, copy=False)),
        shape=value.shape,
        copy=False,
    )


def require_model_manifest(rows_path: Path, manifest_path: Path) -> dict:
    if not manifest_path.is_file():
        raise RuntimeError("model_input_manifest_missing")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("model_rows_sha256") != sha256(rows_path):
        raise RuntimeError("model_rows_hash_mismatch")
    if manifest.get("purpose") != "CNA-only t_obs model input; V2 deterministic-source validation":
        raise RuntimeError("model_input_manifest_purpose_invalid")
    return manifest


def load_rows(path: Path) -> list[dict]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows or any(row.get("label_status") not in {"review", "defer"} for row in rows):
        raise RuntimeError("invalid_model_rows")
    return rows


def select(rows: list[dict], start: str | None, end: str | None) -> list[dict]:
    return [row for row in rows if (start is None or row["t_obs"][:10] >= start) and (end is None or row["t_obs"][:10] <= end)]


def structured(row: dict, *, year_only: bool = False) -> dict:
    if year_only:
        return {"year=" + str(row["cohort_year"]): 1.0}
    value = {"year=" + str(row["cohort_year"]): 1.0}
    value.update({"num=" + key: float(row[key]) for key in NUMERIC})
    value.update({key + "=" + str(row[key]): 1.0 for key in CATEGORICAL if key != "cohort_year"})
    return value


def text_matrix(train: list[dict], other: list[dict]):
    # Fixed, predeclared sparse text representation. Character features retain
    # product/version tokens that word tokenization can split inconsistently.
    word = TfidfVectorizer(lowercase=True, ngram_range=(1, 2), min_df=2, max_features=150_000, sublinear_tf=True)
    char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=2, max_features=150_000, sublinear_tf=True)
    train_text, other_text = [row["text"] for row in train], [row["text"] for row in other]
    return (
        sklearn_csr(hstack([word.fit_transform(train_text), char.fit_transform(train_text)])),
        sklearn_csr(hstack([word.transform(other_text), char.transform(other_text)])),
    )


def dict_matrix(train: list[dict], other: list[dict], *, year_only: bool = False):
    vectorizer = DictVectorizer(sparse=True)
    return (
        sklearn_csr(vectorizer.fit_transform([structured(row, year_only=year_only) for row in train])),
        sklearn_csr(vectorizer.transform([structured(row, year_only=year_only) for row in other])),
    )


def fit_probability(x_train, y_train: np.ndarray, x_eval, *, balanced: bool = True) -> np.ndarray:
    if len(set(y_train.tolist())) != 2:
        raise RuntimeError("training_split_lacks_binary_class")
    model = LogisticRegression(C=1.0, max_iter=500, class_weight="balanced" if balanced else None, solver="liblinear", random_state=20260905)
    return model.fit(x_train, y_train).predict_proba(x_eval)[:, 1]


def top_capacity_recall(y: np.ndarray, scores: np.ndarray, ids: np.ndarray, budget: float) -> tuple[float, int, int]:
    capacity = int(np.ceil(len(y) * budget))
    order = np.lexsort((ids, -scores))
    selected = y[order[:capacity]]
    positives = int(y.sum())
    return (float(selected.sum() / positives) if positives else float("nan"), int(selected.sum()), capacity)


def ece(y: np.ndarray, scores: np.ndarray, bins: int = 10) -> float:
    edges = np.linspace(0, 1, bins + 1)
    values = []
    for lower, upper in zip(edges[:-1], edges[1:]):
        mask = (scores >= lower) & ((scores < upper) if upper < 1 else (scores <= upper))
        if mask.any():
            values.append(mask.mean() * abs(float(y[mask].mean()) - float(scores[mask].mean())))
    return float(sum(values))


def metric_set(y: np.ndarray, scores: np.ndarray, ids: np.ndarray) -> dict:
    metrics = {
        "pr_auc": float(average_precision_score(y, scores)), "brier": float(brier_score_loss(y, scores)), "ece_10": ece(y, scores),
        "positive_count": int(y.sum()), "record_count": int(len(y)),
    }
    for budget in BUDGETS:
        recall, caught, capacity = top_capacity_recall(y, scores, ids, budget)
        key = str(int(budget * 100))
        metrics[f"recall_at_{key}_pct"] = recall
        metrics[f"false_deferral_at_{key}_pct"] = int(y.sum() - caught)
        metrics[f"capacity_at_{key}_pct"] = capacity
    metrics["risk_coverage"] = [
        {"coverage": budget, "deferred_risk": float((y.sum() - top_capacity_recall(y, scores, ids, budget)[1]) / max(len(y) - top_capacity_recall(y, scores, ids, budget)[2], 1))}
        for budget in BUDGETS
    ]
    return metrics


def stratified_bootstrap(y: np.ndarray, scores: np.ndarray, ids: np.ndarray, replicates: int, seed: int) -> dict:
    rng = np.random.default_rng(seed)
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    if not len(pos) or not len(neg):
        raise RuntimeError("bootstrap_lacks_binary_class")
    keys = ("pr_auc", "brier", "ece_10", "recall_at_5_pct", "recall_at_10_pct", "recall_at_20_pct")
    values = {key: [] for key in keys}
    for _ in range(replicates):
        index = np.concatenate([rng.choice(pos, len(pos), replace=True), rng.choice(neg, len(neg), replace=True)])
        one = metric_set(y[index], scores[index], ids[index])
        for key in keys:
            values[key].append(one[key])
    return {key: {"lower_95": float(np.quantile(value, 0.025)), "upper_95": float(np.quantile(value, 0.975))} for key, value in values.items()}


def paired_recall_delta_ci(y: np.ndarray, baseline: np.ndarray, fused: np.ndarray, ids: np.ndarray, replicates: int, seed: int) -> dict:
    """Stratified paired bootstrap for the preregistered 10% capacity delta."""
    rng = np.random.default_rng(seed)
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    values = []
    for _ in range(replicates):
        index = np.concatenate([rng.choice(pos, len(pos), replace=True), rng.choice(neg, len(neg), replace=True)])
        base = top_capacity_recall(y[index], baseline[index], ids[index], 0.10)[0]
        combined = top_capacity_recall(y[index], fused[index], ids[index], 0.10)[0]
        values.append(combined - base)
    return {"lower_95": float(np.quantile(values, 0.025)), "upper_95": float(np.quantile(values, 0.975))}


def evaluate_split(train: list[dict], test: list[dict], replicates: int, seed: int) -> tuple[dict, dict[str, np.ndarray]]:
    y_train = np.array([row["label"] for row in train], dtype=int)
    y_test = np.array([row["label"] for row in test], dtype=int)
    ids = np.array([row["cve_id"] for row in test])
    y_struct_train, y_struct_test = dict_matrix(train, test, year_only=True)
    s_train, s_test = dict_matrix(train, test)
    t_train, t_test = text_matrix(train, test)
    predictions = {
        "prevalence": np.full(len(test), float(y_train.mean())),
        "year_only": fit_probability(y_struct_train, y_train, y_struct_test),
        "structured_cna": fit_probability(s_train, y_train, s_test),
        "tfidf_word_character": fit_probability(t_train, y_train, t_test),
        "fused_tfidf_structured": fit_probability(
            sklearn_csr(hstack([t_train, s_train])), y_train, sklearn_csr(hstack([t_test, s_test]))
        ),
    }
    results = {}
    for index, (name, score) in enumerate(predictions.items()):
        results[name] = {"metrics": metric_set(y_test, score, ids), "bootstrap_95": stratified_bootstrap(y_test, score, ids, replicates, seed + index)}
    return results, predictions


def write_predictions(path: Path, rows: list[dict], predictions: dict[str, np.ndarray]) -> str:
    payload = [{"cve_id": row["cve_id"], "t_obs": row["t_obs"], "label": row["label"], **{name: float(scores[index]) for name, scores in predictions.items()}} for index, row in enumerate(rows)]
    path.write_text("".join(json.dumps(row) + "\n" for row in payload), encoding="utf-8")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--v2-input-reference", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--bootstrap-replicates", type=int, default=2000)
    args = parser.parse_args()
    if args.bootstrap_replicates != 2000:
        raise RuntimeError("formal_run_requires_2000_bootstraps")
    reference = validate_reference(args.v2_input_reference, args.labels)
    model_input_manifest = require_model_manifest(args.model_rows, args.model_manifest)
    if model_input_manifest.get("input_reference_sha256") != sha256(args.v2_input_reference):
        raise RuntimeError("model_input_reference_hash_mismatch")
    out = args.output_dir.resolve()
    if out.exists() and any(out.iterdir()):
        raise RuntimeError("output_not_empty")
    rows = load_rows(args.model_rows)
    train, validation, test = select(rows, None, "2024-06-30"), select(rows, "2024-07-01", "2024-12-31"), select(rows, "2025-01-01", "2025-09-30")
    if int(sum(row["label"] for row in test)) < 100:
        raise RuntimeError("test_review_event_gate_failed")
    out.mkdir(parents=True, exist_ok=True)
    validation_results, _ = evaluate_split(train, validation, args.bootstrap_replicates, 20260905)
    fixed, predictions = evaluate_split(train, test, args.bootstrap_replicates, 20261005)
    # Rolling origins intentionally retrain representations and classifiers at
    # each boundary. They are not a random resampling of the fixed test set.
    rolling_2024_train, rolling_2024_test = select(rows, None, "2023-12-31"), select(rows, "2024-01-01", "2024-12-31")
    rolling_2025_train, rolling_2025_test = select(rows, None, "2024-12-31"), test
    rolling = {
        "train_through_2023_test_2024": evaluate_split(rolling_2024_train, rolling_2024_test, args.bootstrap_replicates, 20261205)[0],
        "train_through_2024_test_2025": evaluate_split(rolling_2025_train, rolling_2025_test, args.bootstrap_replicates, 20261305)[0],
    }
    prediction_hash = write_predictions(out / "test_predictions.jsonl", test, predictions)
    delta = fixed["fused_tfidf_structured"]["metrics"]["recall_at_10_pct"] - fixed["tfidf_word_character"]["metrics"]["recall_at_10_pct"]
    delta_ci = paired_recall_delta_ci(
        np.array([row["label"] for row in test], dtype=int), predictions["tfidf_word_character"],
        predictions["fused_tfidf_structured"], np.array([row["cve_id"] for row in test]), args.bootstrap_replicates, 20261105,
    )
    gate_passed = delta >= 0.02 and delta_ci["lower_95"] > 0
    report = {
        "run_id": args.run_id, "protocol": "fixed chronological primary evaluation; no random split", "split_counts": {"train": len(train), "validation": len(validation), "test": len(test)},
        "v2_input_reference_run_id": reference["run_id"], "v2_input_reference_sha256": sha256(args.v2_input_reference),
        "model_input_manifest_sha256": sha256(args.model_manifest), "model_rows_sha256": model_input_manifest["model_rows_sha256"],
        "validation_models": validation_results, "test_models": fixed,
        "rolling_origin_models": rolling,
        "fused_minus_text_recall_at_10_pct": delta, "fused_minus_text_recall_at_10_pct_paired_bootstrap_95": delta_ci,
        "fused_primary_delta_gate_passed": gate_passed,
        "test_predictions_sha256": prediction_hash, "bootstrap_replicates": args.bootstrap_replicates,
        "python": sys.version, "platform": platform.platform(),
    }
    (out / "chronological_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"test_rows": len(test), "test_review": int(sum(row["label"] for row in test)), "fused_delta_recall_10": delta}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
