"""Cluster-bootstrap V3 frozen predictions by observation month or CNA group.

This is a sensitivity analysis only. It imports neither the model runner nor
training data transformations, and cannot select a primary model or threshold.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from sklearn.metrics import average_precision_score, brier_score_loss


MODELS = ("prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured")
BUDGETS = (0.05, 0.10, 0.20)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def capacity(y: np.ndarray, scores: np.ndarray, ids: np.ndarray, budget: float) -> float:
    number = int(np.ceil(len(y) * budget))
    chosen = y[np.lexsort((ids, -scores))[:number]]
    return float(chosen.sum() / y.sum())


def ece(y: np.ndarray, scores: np.ndarray) -> float:
    total = 0.0
    for index in range(10):
        low, high = index / 10, (index + 1) / 10
        mask = (scores >= low) & ((scores < high) if index < 9 else (scores <= high))
        if mask.any():
            total += float(mask.mean()) * abs(float(y[mask].mean()) - float(scores[mask].mean()))
    return total


def metrics(y: np.ndarray, scores: np.ndarray, ids: np.ndarray) -> dict:
    values = {"pr_auc": float(average_precision_score(y, scores)), "brier": float(brier_score_loss(y, scores)), "ece_10": ece(y, scores)}
    for budget in BUDGETS:
        values[f"recall_at_{int(budget * 100)}_pct"] = capacity(y, scores, ids, budget)
    return values


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--grouping", choices=("month", "cna_group"), required=True)
    parser.add_argument("--replicates", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20261406)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists() or args.replicates != 2000:
        raise RuntimeError("invalid_cluster_bootstrap_request")
    predictions = [json.loads(line) for line in args.predictions.read_text(encoding="utf-8").splitlines() if line.strip()]
    source_rows = [json.loads(line) for line in args.model_rows.read_text(encoding="utf-8").splitlines() if line.strip()]
    lookup = {(row["cve_id"], row["t_obs"]): row for row in source_rows}
    groups: dict[str, list[int]] = defaultdict(list)
    unmatched = []
    for index, row in enumerate(predictions):
        source = lookup.get((row["cve_id"], row["t_obs"]))
        if source is None:
            unmatched.append(row["cve_id"])
            continue
        key = row["t_obs"][:7] if args.grouping == "month" else str(source.get("cna_group") or "__missing__")
        groups[key].append(index)
    if unmatched or len(groups) < 2:
        raise RuntimeError("prediction_to_group_mapping_invalid")
    y = np.array([row["label"] for row in predictions], dtype=int)
    ids = np.array([row["cve_id"] for row in predictions])
    group_indices = list(groups.values())
    rng = np.random.default_rng(args.seed)
    metric_names = ("pr_auc", "brier", "ece_10", "recall_at_5_pct", "recall_at_10_pct", "recall_at_20_pct")
    intervals = {}
    for model_number, model in enumerate(MODELS):
        scores = np.array([row[model] for row in predictions], dtype=float)
        samples = {name: [] for name in metric_names}
        local_rng = np.random.default_rng(args.seed + model_number)
        for _ in range(args.replicates):
            selected_groups = local_rng.integers(0, len(group_indices), size=len(group_indices))
            index = np.concatenate([group_indices[item] for item in selected_groups])
            if len(np.unique(y[index])) != 2:
                continue
            one = metrics(y[index], scores[index], ids[index])
            for name in metric_names:
                samples[name].append(one[name])
        if any(len(samples[name]) < int(args.replicates * 0.99) for name in metric_names):
            raise RuntimeError("too_many_single_class_cluster_bootstraps")
        intervals[model] = {
            "point_estimate": metrics(y, scores, ids),
            "bootstrap_95": {name: {"lower_95": float(np.quantile(values, 0.025)), "upper_95": float(np.quantile(values, 0.975)), "valid_replicates": len(values)} for name, values in samples.items()},
        }
    result = {
        "run_id": args.run_id,
        "purpose": "cluster-correlated uncertainty sensitivity from frozen V3 predictions; not primary model selection",
        "grouping": args.grouping,
        "bootstrap_replicates_requested": args.replicates,
        "prediction_sha256": sha256(args.predictions),
        "model_rows_sha256": sha256(args.model_rows),
        "record_count": len(predictions),
        "positive_count": int(y.sum()),
        "cluster_count": len(groups),
        "cluster_size_summary": {"min": min(map(len, group_indices)), "max": max(map(len, group_indices)), "missing_group_records": len(groups.get("__missing__", []))},
        "unmatched_prediction_count": len(unmatched),
        "models": intervals,
        "passed": True,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": True, "grouping": args.grouping, "clusters": len(groups)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
