"""Render audit-bound V3 manuscript figures with the Python-only backend."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams.update({
    "font.size": 7,
    "axes.linewidth": 0.8,
    "axes.spines.right": False,
    "axes.spines.top": False,
    "legend.frameon": False,
})

COLORS = {
    "structured_cna": "#0F4D92",
    "tfidf_word_character": "#42949E",
    "fused_tfidf_structured": "#9A4D8E",
    "prevalence": "#767676",
    "year_only": "#B64342",
    "neutral": "#CFCECE",
    "signal": "#3775BA",
    "risk": "#B64342",
}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def csv_rows(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def panel_label(ax, label: str) -> None:
    ax.text(-0.16, 1.04, label, transform=ax.transAxes, fontsize=9,
            fontweight="bold", ha="left", va="bottom")


def save(fig, stem: Path) -> list[Path]:
    saved = []
    for suffix, kwargs in (("svg", {}), ("pdf", {}), ("tiff", {"dpi": 600}), ("png", {"dpi": 300})):
        out = stem.with_suffix("." + suffix)
        fig.savefig(out, bbox_inches="tight", **kwargs)
        saved.append(out)
    plt.close(fig)
    return saved


def figure_1(years: list[dict], report: dict, stem: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.25), layout="constrained",
                             gridspec_kw={"width_ratios": [1.25, 1.0, 1.45]})
    year = [int(x["cohort_year"]) for x in years]
    source = [int(x["source_count"]) for x in years]
    eligible = [int(x["eligible_count"]) for x in years]
    ax = axes[0]
    x = np.arange(len(year))
    ax.bar(x - 0.18, source, width=0.36, color=COLORS["neutral"], label="Source cohort")
    ax.bar(x + 0.18, eligible, width=0.36, color=COLORS["signal"], label="Binary eligible")
    ax.set_xticks(x, year)
    ax.set_ylabel("Records")
    ax.legend(fontsize=6, loc="upper left")
    panel_label(ax, "a")

    ax = axes[1]
    rate = np.array([float(x["structural_event_rate"]) for x in years]) * 100
    bars = ax.bar(x, rate, color=COLORS["signal"], width=0.58)
    for bar, value in zip(bars, rate):
        ax.text(bar.get_x() + bar.get_width() / 2, value + 0.35, f"{value:.1f}%", ha="center", va="bottom", fontsize=6)
    ax.set_ylim(0, max(rate) + 3)
    ax.set_xticks(x, year)
    ax.set_ylabel("Structural event rate (%)")
    panel_label(ax, "b")

    ax = axes[2]
    rolling = report["rolling_origin_models"]
    origin_keys = ["train_through_2023_test_2024", "train_through_2024_test_2025"]
    origin_labels = ["Train <=2023\nTest 2024", "Train <=2024\nTest 2025"]
    for model in ("structured_cna", "tfidf_word_character", "fused_tfidf_structured"):
        values = np.array([rolling[key][model]["metrics"]["pr_auc"] for key in origin_keys])
        low = np.array([rolling[key][model]["bootstrap_95"]["pr_auc"]["lower_95"] for key in origin_keys])
        high = np.array([rolling[key][model]["bootstrap_95"]["pr_auc"]["upper_95"] for key in origin_keys])
        label = {"structured_cna": "Structured CNA", "tfidf_word_character": "TF-IDF text", "fused_tfidf_structured": "Fusion"}[model]
        ax.errorbar([0, 1], values, yerr=[values - low, high - values], marker="o", lw=1.4, ms=4,
                    capsize=2, color=COLORS[model], label=label)
    ax.set_xticks([0, 1], origin_labels)
    ax.set_ylabel("PR-AUC")
    ax.set_ylim(0, 0.85)
    ax.legend(fontsize=5.5, loc="upper left")
    panel_label(ax, "c")
    return save(fig, stem)


def figure_2(metrics: list[dict], stem: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.25), layout="constrained")
    models = [row["model"] for row in metrics]
    labels = ["Prevalence", "Year\nonly", "Structured\nCNA", "TF-IDF\ntext", "Fusion"]
    x = np.arange(len(models))
    colors = [COLORS[m] for m in models]
    ax = axes[0]
    vals = np.array([float(r["pr_auc"]) for r in metrics])
    lo = vals - np.array([float(r["pr_auc_lower_95"]) for r in metrics])
    hi = np.array([float(r["pr_auc_upper_95"]) for r in metrics]) - vals
    ax.bar(x, vals, color=colors, yerr=np.vstack([lo, hi]), capsize=2, error_kw={"elinewidth": 0.8})
    ax.set_xticks(x, labels, fontsize=5.2)
    ax.set_ylabel("PR-AUC (95% CI)")
    ax.set_ylim(0, 0.8)
    panel_label(ax, "a")

    ax = axes[1]
    vals = np.array([float(r["recall_at_10_pct"]) * 100 for r in metrics])
    ax.bar(x, vals, color=colors)
    ax.set_xticks(x, labels, fontsize=5.2)
    ax.set_ylabel("Recall at 10% review capacity (%)")
    ax.set_ylim(0, 100)
    panel_label(ax, "b")

    ax = axes[2]
    brier = np.array([float(r["brier"]) for r in metrics])
    ece = np.array([float(r["ece_10"]) for r in metrics])
    w = 0.36
    ax.bar(x - w / 2, brier, width=w, color="#767676", label="Brier")
    ax.bar(x + w / 2, ece, width=w, color="#AADCA9", label="ECE (10 bins)")
    ax.set_xticks(x, labels, fontsize=5.2)
    ax.set_ylabel("Calibration loss")
    ax.set_ylim(0, 0.46)
    ax.legend(fontsize=6)
    panel_label(ax, "c")
    return save(fig, stem)


def figure_3(primary_report: dict, delta: dict, cluster_cna: dict, cluster_month: dict,
             holdout_reports: list[dict], stem: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.25), layout="constrained",
                             gridspec_kw={"width_ratios": [1.05, 1.05, 1.2]})
    ax = axes[0]
    rows = [(name.replace("_", " "), item) for name, item in delta["models"].items()]
    y = np.arange(len(rows))[::-1]
    for yi, (_, item) in zip(y, rows):
        p = item["point_pr_auc_difference_full_minus_ablated"]
        ci = item["paired_bootstrap_95"]
        ax.plot([ci["lower_95"], ci["upper_95"]], [yi, yi], color=COLORS["risk"], lw=1.2)
        ax.plot(p, yi, "o", color=COLORS["risk"], ms=4)
    ax.axvline(0, color="#767676", ls="--", lw=0.8)
    ax.set_yticks(y, [r[0] for r in rows], fontsize=6)
    ax.set_xlabel("Full minus ablated PR-AUC")
    panel_label(ax, "a")

    ax = axes[1]
    primary = primary_report["test_models"]["structured_cna"]
    point = primary["metrics"]["pr_auc"]
    primary_ci = primary["bootstrap_95"]["pr_auc"]
    items = [("Row bootstrap", primary_ci["lower_95"], primary_ci["upper_95"]),
             ("Month clusters", cluster_month["models"]["structured_cna"]["bootstrap_95"]["pr_auc"]["lower_95"], cluster_month["models"]["structured_cna"]["bootstrap_95"]["pr_auc"]["upper_95"]),
             ("CNA clusters", cluster_cna["models"]["structured_cna"]["bootstrap_95"]["pr_auc"]["lower_95"], cluster_cna["models"]["structured_cna"]["bootstrap_95"]["pr_auc"]["upper_95"])]
    yy = np.arange(len(items))[::-1]
    for yi, (_, low, high) in zip(yy, items):
        ax.plot([low, high], [yi, yi], color=COLORS["signal"], lw=1.4)
        ax.plot(point, yi, "o", color=COLORS["signal"], ms=4)
    ax.set_yticks(yy, [r[0] for r in items], fontsize=6)
    ax.set_xlabel("Structured CNA PR-AUC (95% CI)")
    ax.set_xlim(0, 0.9)
    panel_label(ax, "b")

    ax = axes[2]
    names = ["Primary\nchronology"] + [r["group"] + "\nholdout" for r in holdout_reports]
    values = [point] + [r["test_models"]["structured_cna"]["metrics"]["pr_auc"] for r in holdout_reports]
    low = [primary_ci["lower_95"]] + [r["test_models"]["structured_cna"]["bootstrap_95"]["pr_auc"]["lower_95"] for r in holdout_reports]
    high = [primary_ci["upper_95"]] + [r["test_models"]["structured_cna"]["bootstrap_95"]["pr_auc"]["upper_95"] for r in holdout_reports]
    x = np.arange(len(names))
    ax.errorbar(x, values, yerr=[np.array(values) - np.array(low), np.array(high) - np.array(values)],
                fmt="o", color=COLORS["risk"], capsize=2, lw=1.0)
    ax.set_xticks(x, names, fontsize=6)
    ax.set_ylabel("Structured CNA PR-AUC (95% CI)")
    ax.set_ylim(0, 0.75)
    panel_label(ax, "c")
    return save(fig, stem)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--profile-delta", type=Path, required=True)
    parser.add_argument("--cluster-cna", type=Path, required=True)
    parser.add_argument("--cluster-month", type=Path, required=True)
    parser.add_argument("--dependency-lock", type=Path, required=True)
    parser.add_argument("--holdout-reports", type=Path, nargs=3, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise SystemExit(f"output_dir_exists: {args.output_dir}")
    required = [args.source_dir / "table1_yearly_cohort.csv", args.source_dir / "table2_primary_metrics.csv",
                args.report, args.profile_delta, args.cluster_cna, args.cluster_month,
                args.dependency_lock, *args.holdout_reports]
    missing = [str(p) for p in required if not p.is_file()]
    if missing:
        raise SystemExit("missing_input: " + ", ".join(missing))
    args.output_dir.mkdir(parents=True)
    years = csv_rows(args.source_dir / "table1_yearly_cohort.csv")
    metrics = csv_rows(args.source_dir / "table2_primary_metrics.csv")
    report = json.loads(args.report.read_text(encoding="utf-8"))
    delta = json.loads(args.profile_delta.read_text(encoding="utf-8"))
    cna = json.loads(args.cluster_cna.read_text(encoding="utf-8"))
    month = json.loads(args.cluster_month.read_text(encoding="utf-8"))
    holdouts = [json.loads(p.read_text(encoding="utf-8")) for p in args.holdout_reports]
    saved = []
    saved += figure_1(years, report, args.output_dir / "figure_1_cohort_drift")
    saved += figure_2(metrics, args.output_dir / "figure_2_primary_models")
    saved += figure_3(report, delta, cna, month, holdouts, args.output_dir / "figure_3_sensitivities")
    qa = {}
    for png in sorted(args.output_dir.glob("*.png")):
        from PIL import Image
        pixels = np.asarray(Image.open(png).convert("RGB"))
        nonwhite_fraction = float((pixels < 245).any(axis=2).mean())
        if nonwhite_fraction <= 0.01:
            raise RuntimeError(f"blank_png_detected: {png}")
        qa[png.name] = {"shape": list(pixels.shape), "nonwhite_fraction": nonwhite_fraction}
    for svg in sorted(args.output_dir.glob("*.svg")):
        text_nodes = len(re.findall(r"<text(?:\s|>)", svg.read_text(encoding="utf-8")))
        if text_nodes == 0:
            raise RuntimeError(f"svg_text_not_editable: {svg}")
        qa[svg.name] = {"editable_text_nodes": text_nodes}
    manifest = {
        "run_id": args.output_dir.name,
        "purpose": "Python-rendered V3 manuscript figures from audit-bound source data; not final release authorization",
        "backend": {"python": sys.version, "matplotlib": matplotlib.__version__},
        "plotting_script": {"path": str(Path(__file__).resolve()), "sha256": digest(Path(__file__))},
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "inputs": {str(p): {"bytes": p.stat().st_size, "sha256": digest(p)} for p in required},
        "outputs": {p.name: {"bytes": p.stat().st_size, "sha256": digest(p)} for p in saved},
        "qa": qa,
        "figure_contract": {
            "figure_1": "Cohort construction and annual/rolling-origin drift; no causal or deployment claim.",
            "figure_2": "Audited primary chronological model comparison; fusion is displayed without a superiority claim.",
            "figure_3": "Identity dependence and correlated/grouped sensitivity limit generalization claims.",
        },
        "final_release_authorized": False,
        "platform": platform.platform(),
    }
    (args.output_dir / "figure_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": args.output_dir.name, "figure_file_count": len(saved)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
