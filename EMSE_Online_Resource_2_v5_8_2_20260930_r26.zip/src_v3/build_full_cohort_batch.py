"""Fast complete-cohort builder using one Git cat-file batch stream per pass.

The earlier builder spawned several Git processes per CVE and was retained as
an engineering-failure run. This implementation preserves the same protocol
but batches immutable blob reads, reducing process overhead without changing
the time-lock or CNA-only boundary.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from collections import Counter
from datetime import date, datetime, timedelta
from pathlib import Path

from audit_asof import BASELINE_RE, baseline_tags, parse_utc, record_manifest, run_git


class CatFileBatch:
    def __init__(self, repo: Path):
        import subprocess

        self.proc = subprocess.Popen(
            ["git", "-C", str(repo), "cat-file", "--batch"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    def get(self, spec: str) -> bytes | None:
        assert self.proc.stdin is not None and self.proc.stdout is not None
        self.proc.stdin.write((spec + "\n").encode("utf-8"))
        self.proc.stdin.flush()
        header = self.proc.stdout.readline()
        if not header:
            raise RuntimeError("cat_file_eof")
        parts = header.rstrip(b"\n").split()
        if len(parts) >= 2 and parts[1] == b"missing":
            return None
        if len(parts) != 3:
            raise RuntimeError(f"cat_file_bad_header:{header!r}")
        size = int(parts[2])
        payload = self.proc.stdout.read(size)
        trailer = self.proc.stdout.read(1)
        if len(payload) != size or trailer != b"\n":
            raise RuntimeError("cat_file_short_blob")
        return payload

    def close(self) -> None:
        if self.proc.stdin:
            self.proc.stdin.close()
        rc = self.proc.wait(timeout=30)
        if rc:
            stderr = self.proc.stderr.read().decode("utf-8", "replace") if self.proc.stderr else ""
            raise RuntimeError(f"cat_file_failed:{rc}:{stderr.strip()}")


def paths_at_tag(repo: Path, tag: str, year: int) -> list[str]:
    proc = run_git(repo, "ls-tree", "-r", "--name-only", tag, f"cves/{year}")
    if proc.returncode:
        raise RuntimeError(f"tree_unavailable:{tag}:{proc.stderr.strip()}")
    return sorted({p for p in proc.stdout.splitlines() if p.startswith(f"cves/{year}/") and p.endswith(".json") and "/CVE-" in p})


def windows() -> tuple[tuple[int, date, date, str], ...]:
    return (
        (2023, date(2023, 3, 28), date(2023, 12, 31), "2023-12-31_baseline"),
        (2024, date(2024, 1, 1), date(2024, 12, 31), "2024-12-31_baseline"),
        (2025, date(2025, 1, 1), date(2025, 9, 30), "2025-09-30_baseline"),
    )


def load_json(payload: bytes) -> dict | None:
    try:
        value = json.loads(payload)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--max-per-year", type=int, default=0, help="smoke limit; zero means formal full scan")
    parser.add_argument("--checkpoint-every", type=int, default=1000)
    args = parser.parse_args()
    if args.max_per_year < 0 or args.checkpoint_every <= 0:
        parser.error("invalid numeric argument")

    repo = args.repo.resolve()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    rows_path = out / "asof_full_records.jsonl"
    unresolved_path = out / "asof_unresolved_candidates.jsonl"
    if rows_path.exists() or unresolved_path.exists():
        raise SystemExit(f"output_exists:{out}")

    tags = baseline_tags(repo)
    tag_times = dict(tags)
    tag_commits_proc = run_git(repo, "for-each-ref", "--format=%(refname:strip=2)\t%(objectname)", "refs/tags")
    if tag_commits_proc.returncode:
        raise RuntimeError(f"tag_commits_failed:{tag_commits_proc.stderr.strip()}")
    tag_commits = {}
    for line in tag_commits_proc.stdout.splitlines():
        name, sep, commit = line.partition("\t")
        if sep and BASELINE_RE.fullmatch(name):
            tag_commits[name] = commit
    if not all(name in tag_commits for name in tag_times):
        raise RuntimeError("baseline_commit_map_incomplete")

    counts = Counter()
    by_year = {}
    candidate_total = examined_total = selected_total = 0
    with rows_path.open("w", encoding="utf-8", newline="\n") as rows_file, unresolved_path.open("w", encoding="utf-8", newline="\n") as unresolved_file:
        for year, start, cutoff, endpoint_tag in windows():
            paths = paths_at_tag(repo, endpoint_tag, year)
            candidate_total += len(paths)
            selected = examined = 0
            year_counts = Counter()
            endpoint_reader = CatFileBatch(repo)
            try:
                endpoint_items = []
                limited_paths = paths[: args.max_per_year] if args.max_per_year else paths
                for path in limited_paths:
                    payload = endpoint_reader.get(f"{endpoint_tag}:{path}")
                    endpoint_items.append((path, payload))
            finally:
                endpoint_reader.close()

            asof_candidates = []
            for path, payload in endpoint_items:
                examined += 1
                cve_id = Path(path).stem
                if payload is None:
                    unresolved_file.write(json.dumps({"cve_id": cve_id, "path": path, "status": "excluded", "reason": "catalog_blob_missing", "catalogue_baseline_tag": endpoint_tag}, ensure_ascii=False, sort_keys=True) + "\n")
                    year_counts["unresolved_candidate"] += 1
                    continue
                record = load_json(payload)
                try:
                    published = parse_utc(record["cveMetadata"]["datePublished"]) if record else None
                except (KeyError, TypeError, ValueError):
                    published = None
                if published is None:
                    unresolved_file.write(json.dumps({"cve_id": cve_id, "path": path, "status": "excluded", "reason": "publication_unrecoverable", "catalogue_baseline_tag": endpoint_tag}, ensure_ascii=False, sort_keys=True) + "\n")
                    year_counts["unresolved_candidate"] += 1
                    continue
                publication_date = published.date()
                if not (start <= publication_date <= cutoff):
                    continue
                candidate_tags = [(tag, tm) for tag, tm in tags if published <= tm <= published + timedelta(hours=24)]
                if not candidate_tags:
                    unresolved_file.write(json.dumps({"cve_id": cve_id, "path": path, "status": "excluded", "reason": "no_baseline_in_observation_window", "t_pub": published.isoformat(), "catalogue_baseline_tag": endpoint_tag}, ensure_ascii=False, sort_keys=True) + "\n")
                    year_counts["no_baseline_in_observation_window"] += 1
                    continue
                asof_candidates.append((path, cve_id, payload, published, candidate_tags, endpoint_tag, year, start, cutoff))

            asof_reader = CatFileBatch(repo)
            try:
                for path, cve_id, endpoint_payload, published, candidate_tags, catalogue_tag, cohort_year, window_start, window_end in asof_candidates:
                    examined_row = None
                    for tag, snapshot_time in candidate_tags:
                        payload = asof_reader.get(f"{tag}:{path}")
                        if payload is None:
                            continue
                        record = load_json(payload)
                        try:
                            asof_published = parse_utc(record["cveMetadata"]["datePublished"]) if record else None
                        except (KeyError, TypeError, ValueError):
                            asof_published = None
                        if asof_published != published:
                            continue
                        examined_row = {
                            "cve_id": cve_id,
                            "path": path,
                            "status": "included",
                            "reason": None,
                            "t_pub": published.isoformat(),
                            "t_obs": snapshot_time.isoformat(),
                            "asof_baseline_tag": tag,
                            "asof_commit": tag_commits[tag],
                            "asof_commit_time": snapshot_time.isoformat(),
                            "asof_record_sha256": hashlib.sha256(payload).hexdigest(),
                            "record_bytes": len(payload),
                            "cna_manifest": record_manifest(record),
                            "cohort_year": cohort_year,
                            "cohort_window_start": window_start.isoformat(),
                            "cohort_window_end": window_end.isoformat(),
                            "catalogue_baseline_tag": catalogue_tag,
                        }
                        break
                    if examined_row is None:
                        examined_row = {"cve_id": cve_id, "path": path, "status": "excluded", "reason": "record_not_present_in_observation_window", "t_pub": published.isoformat(), "catalogue_baseline_tag": catalogue_tag}
                        unresolved_file.write(json.dumps(examined_row, ensure_ascii=False, sort_keys=True) + "\n")
                        unresolved_file.flush()
                        year_counts["record_not_present_in_observation_window"] += 1
                        continue
                    selected += 1
                    rows_file.write(json.dumps(examined_row, ensure_ascii=False, sort_keys=True) + "\n")
                    rows_file.flush()
                    counts["included"] += 1
                    year_counts["included"] += 1
                    if selected % args.checkpoint_every == 0:
                        (out / "checkpoint.json").write_text(json.dumps({"year": cohort_year, "examined": examined, "selected": selected, "counts": dict(counts), "last_cve_id": cve_id}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            finally:
                asof_reader.close()
            examined_total += examined
            selected_total += selected
            by_year[str(year)] = {"candidates": len(paths), "examined": examined, "selected": selected, **dict(year_counts)}

    head = run_git(repo, "rev-parse", "HEAD").stdout.strip()
    manifest = {
        "run_type": "full_time_locked_asof_cohort_batch_v1",
        "repo": str(repo),
        "repo_head": head,
        "repo_is_shallow": run_git(repo, "rev-parse", "--is-shallow-repository").stdout.strip(),
        "python": sys.version,
        "platform": platform.platform(),
        "formal_limit": args.max_per_year == 0,
        "candidate_count": candidate_total,
        "examined_count": examined_total,
        "selected_count": selected_total,
        "status_counts": dict(sorted(counts.items())),
        "by_publication_year": by_year,
        "records_sha256": hashlib.sha256(rows_path.read_bytes()).hexdigest(),
    }
    (out / "asof_full_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (out / "cohort_counts.json").write_text(json.dumps({"status_counts": dict(sorted(counts.items())), "by_publication_year": by_year}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (out / "checkpoint.json").unlink(missing_ok=True)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
