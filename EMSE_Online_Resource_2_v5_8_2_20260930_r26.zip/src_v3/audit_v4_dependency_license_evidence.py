"""Bind installed package licence/notice files to hashes for external review.

The output is evidence about the audited Python environment. It neither
interprets licence compatibility nor authorizes redistribution.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata as metadata
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


LICENSE_BASENAMES = {
    stem + suffix
    for stem in ("license", "licence", "copying", "notice", "copyright")
    for suffix in ("", ".txt", ".md", ".rst")
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def package_names_from_locks(locks: list[Path]) -> tuple[list[dict], set[str]]:
    records = []
    names = set()
    for lock in locks:
        records.append({"path": str(lock), "sha256": sha256(lock)})
        for raw_line in lock.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            name = line.split("==", 1)[0].split(" @ ", 1)[0].strip()
            if name:
                names.add(name)
    return records, names


def licence_files(distribution: metadata.Distribution) -> list[dict]:
    records = []
    for relative in distribution.files or []:
        if relative.name.casefold() not in LICENSE_BASENAMES:
            continue
        path = Path(distribution.locate_file(relative))
        if path.is_file():
            records.append({
                "relative_path": str(relative).replace("\\", "/"),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            })
    return sorted(records, key=lambda item: item["relative_path"].casefold())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lock", action="append", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("dependency_license_evidence_output_exists")

    locks, package_names = package_names_from_locks(args.lock)
    packages = []
    for name in sorted(package_names, key=str.casefold):
        try:
            distribution = metadata.distribution(name)
        except metadata.PackageNotFoundError:
            packages.append({"name": name, "status": "not_installed_in_audited_environment"})
            continue
        files = licence_files(distribution)
        packages.append({
            "name": name,
            "version": distribution.version,
            "installed_distribution_path": str(distribution._path),
            "licence_notice_files": files,
            "licence_notice_file_count": len(files),
            "status": "package_distributed_text_hashed_external_review_pending",
        })

    payload = {
        "run_id": args.run_id,
        "purpose": "hash-bound installed dependency licence/notice evidence; not legal clearance",
        "python": sys.version,
        "platform": platform.platform(),
        "lock_files": locks,
        "packages": packages,
        "package_count": len(packages),
        "authoritative_licence_review_complete": False,
        "public_release_authorized": False,
        "limitation": (
            "This records licence/notice files included in the audited installed distributions. "
            "It may not capture every upstream, bundled, binary, or transitive notice and does not "
            "determine compatibility, attribution obligations, or redistribution permission."
        ),
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    found = sum(item.get("licence_notice_file_count", 0) for item in packages)
    print(json.dumps({"run_id": args.run_id, "package_count": len(packages), "hashed_files": found, "authoritative_licence_review_complete": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
