"""Verify V3 model rows remain bound to a <=24-hour CNA-only source snapshot."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--asof-records", type=Path, required=True)
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--input-reference", type=Path, required=True)
    parser.add_argument("--v3-labels", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("time_lock_audit_output_exists")
    manifest = json.loads(args.model_manifest.read_text(encoding="utf-8"))
    reference = json.loads(args.input_reference.read_text(encoding="utf-8"))
    labels = json.loads(args.v3_labels.read_text(encoding="utf-8"))
    label_by_id = {row["cve_id"]: row for row in labels["records"]}
    source = {
        row["cve_id"]: row
        for row in (json.loads(line) for line in args.asof_records.read_text(encoding="utf-8").splitlines() if line.strip())
        if row.get("status") == "included"
    }
    rows = [json.loads(line) for line in args.model_rows.read_text(encoding="utf-8").splitlines() if line.strip()]
    failures, delays = [], []
    for row in rows:
        original = source.get(row["cve_id"])
        if original is None:
            failures.append({"cve_id": row["cve_id"], "failure": "missing_source_included_record"})
            continue
        if row.get("t_obs") != original.get("t_obs"):
            failures.append({"cve_id": row["cve_id"], "failure": "t_obs_mismatch"})
        if row.get("asof_record_sha256") != original.get("asof_record_sha256"):
            failures.append({"cve_id": row["cve_id"], "failure": "asof_record_hash_mismatch"})
        delay_hours = (parse(original["t_obs"]) - parse(original["t_pub"])).total_seconds() / 3600
        delays.append(delay_hours)
        if not 0 <= delay_hours <= 24:
            failures.append({"cve_id": row["cve_id"], "failure": "outside_24_hour_window", "delay_hours": delay_hours})
        if label_by_id.get(row["cve_id"], {}).get("status") not in {"review", "defer"}:
            failures.append({"cve_id": row["cve_id"], "failure": "model_row_has_nonbinary_label_disposition"})
    source_delays = [(parse(row["t_obs"]) - parse(row["t_pub"])).total_seconds() / 3600 for row in source.values()]
    source_delays.sort()
    source_ids, model_ids = set(source), {row["cve_id"] for row in rows}
    label_excluded = [label_by_id[cve_id] for cve_id in sorted(source_ids - model_ids) if cve_id in label_by_id]
    excluded_status_counts = {}
    for row in label_excluded:
        excluded_status_counts[row["status"]] = excluded_status_counts.get(row["status"], 0) + 1
    unexpected_excluded = [row["cve_id"] for row in label_excluded if row["status"] not in {"withdraw", "excluded"}]
    if unexpected_excluded:
        failures.extend({"cve_id": cve_id, "failure": "unexpected_source_to_model_exclusion"} for cve_id in unexpected_excluded)
    result = {
        "run_id": args.run_id,
        "purpose": "V3 source-to-model-row 24-hour observation-lock audit",
        "asof_records_sha256": sha256(args.asof_records),
        "model_rows_sha256": sha256(args.model_rows),
        "model_manifest_sha256": sha256(args.model_manifest),
        "input_reference_sha256": sha256(args.input_reference),
        "v3_labels_sha256": sha256(args.v3_labels),
        "source_included_count": len(source),
        "model_row_count": len(rows),
        "source_excluded_after_labeling": len(source) - len(rows),
        "source_to_model_exclusion_dispositions": excluded_status_counts,
        "source_delay_hours": {"min": min(source_delays), "p50": source_delays[(len(source_delays) - 1) // 2], "p95": source_delays[int(0.95 * (len(source_delays) - 1))], "max": max(source_delays)},
        "model_delay_hours": {"min": min(delays), "p50": sorted(delays)[(len(delays) - 1) // 2], "p95": sorted(delays)[int(0.95 * (len(delays) - 1))], "max": max(delays)},
        "binding_checks": {
            "source_hash_matches_reference": reference.get("asof_sha256") == sha256(args.asof_records),
            "source_hash_matches_manifest": manifest.get("source_asof_sha256") == sha256(args.asof_records),
            "model_hash_matches_manifest": manifest.get("model_rows_sha256") == sha256(args.model_rows),
        },
        "failures": failures[:100],
        "failure_count": len(failures),
        "passed": not failures and reference.get("asof_sha256") == sha256(args.asof_records) and manifest.get("source_asof_sha256") == sha256(args.asof_records) and manifest.get("model_rows_sha256") == sha256(args.model_rows),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "model_rows": len(rows), "source_excluded_after_labeling": result["source_excluded_after_labeling"], "failure_count": len(failures)}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
