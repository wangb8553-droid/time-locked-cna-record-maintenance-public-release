"""Point-in-time CVE audit using daily CVE List baseline tags."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


BASELINE_RE = re.compile(r"^(?P<date>\d{4}-\d{2}-\d{2})_baseline$")

# A future feature builder may consume only these CNA fields.  Recording the
# allow-list at the point of snapshotting prevents incidental CNA metadata from
# silently becoming an input feature.
ALLOWED_CNA_FEATURE_FIELDS = frozenset(
    {"affected", "descriptions", "metrics", "problemTypes", "references", "title"}
)


def parse_utc(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed.astimezone(timezone.utc)


def cve_path(cve_id: str) -> str:
    match = re.fullmatch(r"CVE-(\d{4})-(\d+)", cve_id.upper())
    if not match:
        raise ValueError(f"invalid_cve_id:{cve_id}")
    year, number = match.groups()
    digits = number.zfill(4)
    bucket = f"{digits[:-3]}xxx" if len(digits) > 4 else f"{digits[0]}xxx"
    return f"cves/{year}/{bucket}/CVE-{year}-{number}.json"


def run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", "-C", str(repo), *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="surrogateescape", check=False,
    )


def git_show(repo: Path, tag: str, path: str) -> bytes | None:
    proc = run_git(repo, "show", f"{tag}:{path}")
    return proc.stdout.encode("utf-8") if proc.returncode == 0 else None


def tag_time(repo: Path, tag: str) -> datetime:
    proc = run_git(repo, "log", "-1", "--format=%cI", tag)
    if proc.returncode:
        raise RuntimeError(f"tag_unresolvable:{tag}")
    return parse_utc(proc.stdout)


def baseline_tags(repo: Path) -> list[tuple[str, datetime]]:
    # Tag names denote a calendar run. The target commit time is the only
    # temporal authority for a snapshot.
    proc = run_git(
        repo,
        "for-each-ref",
        "--format=%(refname:strip=2)\t%(committerdate:iso-strict)",
        "refs/tags",
    )
    if proc.returncode:
        raise RuntimeError(f"git_tag_failed:{proc.stderr.strip()}")
    tags = []
    for line in proc.stdout.splitlines():
        tag, separator, timestamp = line.partition("\t")
        match = BASELINE_RE.fullmatch(tag.strip())
        if match:
            if not separator or not timestamp.strip():
                raise RuntimeError(f"baseline_timestamp_unavailable:{tag.strip()}")
            tags.append((tag.strip(), parse_utc(timestamp)))
    return sorted(tags, key=lambda item: (item[1], item[0]))


def record_manifest(record: dict[str, Any]) -> dict[str, Any]:
    containers = record.get("containers")
    if not isinstance(containers, dict):
        return {"status": "missing_containers", "feature_container": "none"}
    cna = containers.get("cna")
    adp_keys = sorted(key for key in containers if key != "cna")
    if not isinstance(cna, dict):
        return {
            "status": "missing_cna_container",
            "feature_container": "none",
            "forbidden_containers": adp_keys,
        }
    fields = sorted(cna.keys())
    allowed_fields = sorted(set(fields) & ALLOWED_CNA_FEATURE_FIELDS)
    field_hashes = {
        f"cna.{field}": hashlib.sha256(
            json.dumps(cna[field], ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()
        for field in fields
    }
    return {
        "status": "ok",
        "feature_container": "cna",
        "cna_fields_present": fields,
        "allowed_feature_fields": allowed_fields,
        "excluded_cna_fields": sorted(set(fields) - ALLOWED_CNA_FEATURE_FIELDS),
        "cna_field_sha256": field_hashes,
        "forbidden_containers": adp_keys,
        "adp_present": bool(adp_keys),
    }


def find_asof(
    repo: Path,
    cve_id: str,
    tags: list[tuple[str, datetime]],
    observation_hours: int = 24,
    locator_revision: str | None = None,
) -> dict[str, Any]:
    path = cve_path(cve_id)
    result: dict[str, Any] = {
        "cve_id": cve_id.upper(), "path": path, "status": "excluded", "reason": None,
    }
    # Locate the immutable publication timestamp from a record revision, then
    # validate it again in the selected as-of snapshot.  This is an index-only
    # lookup: no current field is emitted as a feature or label input.
    if locator_revision is None:
        locator = run_git(repo, "log", "-1", "--format=%H", "--", path)
        locator_commit = locator.stdout.strip() if locator.returncode == 0 else ""
    else:
        locator_commit = locator_revision
    seed_payload = git_show(repo, locator_commit, path) if locator_commit else None
    if seed_payload is None:
        result["reason"] = "record_not_recoverable_from_history"
        return result
    try:
        seed_record = json.loads(seed_payload)
        published_time = parse_utc(seed_record["cveMetadata"]["datePublished"])
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        result["reason"] = f"invalid_record:{type(exc).__name__}"
        return result
    result["t_pub"] = published_time.isoformat()
    deadline = published_time + timedelta(hours=observation_hours)
    candidates = [(tag, timestamp) for tag, timestamp in tags if published_time <= timestamp <= deadline]
    if not candidates:
        result["reason"] = "no_baseline_in_observation_window"
        return result
    for tag, snapshot_time in candidates:
        payload = git_show(repo, tag, path)
        if payload is None:
            continue
        try:
            record = json.loads(payload)
        except json.JSONDecodeError as exc:
            result["reason"] = f"invalid_record:{type(exc).__name__}"
            return result
        try:
            asof_published_time = parse_utc(record["cveMetadata"]["datePublished"])
        except (KeyError, TypeError, ValueError) as exc:
            result["reason"] = f"invalid_asof_record:{type(exc).__name__}"
            return result
        if asof_published_time != published_time:
            result["reason"] = "publication_timestamp_changed_after_observation"
            return result
        result.update(
            {
                "status": "included",
                "t_pub": published_time.isoformat(),
                "t_obs": snapshot_time.isoformat(),
                "asof_baseline_tag": tag,
                "asof_commit": run_git(repo, "rev-list", "-1", tag).stdout.strip(),
                "asof_commit_time": snapshot_time.isoformat(),
                "asof_record_sha256": hashlib.sha256(payload).hexdigest(),
                "record_bytes": len(payload),
                "cna_manifest": record_manifest(record),
            }
        )
        return result
    result["reason"] = "record_not_present_in_observation_window"
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--observation-hours", type=int, default=24)
    parser.add_argument("--output", type=Path)
    parser.add_argument("cve", nargs="+")
    args = parser.parse_args()
    if args.observation_hours <= 0:
        parser.error("--observation-hours must be positive")
    try:
        tags = baseline_tags(args.repo)
    except RuntimeError as exc:
        parser.error(str(exc))
    rows = []
    for cve in args.cve:
        try:
            rows.append(find_asof(args.repo, cve, tags, args.observation_hours))
        except (ValueError, RuntimeError) as exc:
            rows.append({"cve_id": cve.upper(), "status": "excluded", "reason": str(exc)})
    report = {
        "repo": str(args.repo), "observation_hours": args.observation_hours,
        "records": rows, "included": sum(row["status"] == "included" for row in rows),
        "excluded": sum(row["status"] == "excluded" for row in rows),
    }
    rendered = json.dumps(report, indent=2, ensure_ascii=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0 if report["included"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
