"""Fit V3 models under an auditable vendor/product/CNA group holdout."""

from __future__ import annotations

import argparse
import json
import platform
import sys
from pathlib import Path

from group_holdout_v3 import GROUP_FIELDS, select_groups, values
from run_v3_models import evaluate, read_rows, require_manifest, sha256
from v3_input_reference import validate_reference


OUTCOMES = ("affected_field_structural_addition", "union")
PROFILES = ("full", "identity_ablated")


def write_predictions(path: Path, rows: list[dict], predictions: dict) -> str:
    payload = [
        {
            "cve_id": row["cve_id"],
            "t_obs": row["t_obs"],
            "label": row["label"],
            **{name: float(scores[index]) for name, scores in predictions.items()},
        }
        for index, row in enumerate(rows)
    ]
    path.write_text("".join(json.dumps(row) + "\n" for row in payload), encoding="utf-8")
    return sha256(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--v3-input-reference", type=Path, required=True)
    parser.add_argument("--v3-labels", type=Path, required=True)
    parser.add_argument("--outcome", choices=OUTCOMES, required=True)
    parser.add_argument("--profile", choices=PROFILES, required=True)
    parser.add_argument("--group", choices=tuple(GROUP_FIELDS), required=True)
    parser.add_argument("--group-count", type=int, default=20)
    parser.add_argument("--bootstrap-replicates", type=int, default=2000)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output_dir.exists() or args.group_count <= 0 or args.bootstrap_replicates not in {25, 2000}:
        raise RuntimeError("invalid_group_holdout_evaluation_request")
    reference = validate_reference(args.v3_input_reference, args.v3_labels)
    manifest = require_manifest(args.model_rows, args.model_manifest, args.v3_input_reference)
    rows = read_rows(args.model_rows, args.outcome)
    train = [row for row in rows if row["t_obs"][:10] <= "2024-06-30"]
    test = [row for row in rows if "2025-01-01" <= row["t_obs"][:10] <= "2025-09-30"]
    selected_groups = select_groups(test, args.group, args.outcome, args.group_count)
    if not selected_groups:
        raise RuntimeError("no_eligible_group_holdout_tokens")
    selected = set(selected_groups)
    heldout_test = [row for row in test if values(row, args.group) & selected]
    retained_train = [row for row in train if not (values(row, args.group) & selected)]
    leaked = sorted({token for row in retained_train for token in values(row, args.group)} & selected)
    if leaked or len({row["label"] for row in retained_train}) != 2 or len({row["label"] for row in heldout_test}) != 2:
        raise RuntimeError("group_holdout_split_invalid")
    args.output_dir.mkdir(parents=True)
    models, predictions = evaluate(retained_train, heldout_test, args.profile, args.bootstrap_replicates, 20261306)
    prediction_hash = write_predictions(args.output_dir / "test_predictions.jsonl", heldout_test, predictions)
    label = "outcome_" + args.outcome
    result = {
        "run_id": args.run_id,
        "protocol": "V3 deterministic 2025 group-held-out sensitivity; not a primary model-selection result",
        "formal": args.bootstrap_replicates == 2000,
        "bootstrap_replicates": args.bootstrap_replicates,
        "outcome": args.outcome,
        "profile": args.profile,
        "group": args.group,
        "selected_groups": selected_groups,
        "split_counts": {
            "original_train": len(train),
            "purged_train": len(retained_train),
            "heldout_test": len(heldout_test),
            "heldout_test_positive": int(sum(row[label] for row in heldout_test)),
        },
        "train_test_group_overlap": leaked,
        "comparative_claim_supported": int(sum(row[label] for row in heldout_test)) >= 100,
        "v3_input_reference_sha256": sha256(args.v3_input_reference),
        "v3_input_reference_run_id": reference["run_id"],
        "model_rows_sha256": manifest["model_rows_sha256"],
        "model_manifest_sha256": sha256(args.model_manifest),
        "test_models": models,
        "test_predictions_sha256": prediction_hash,
        "python": sys.version,
        "platform": platform.platform(),
    }
    (args.output_dir / "group_holdout_report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"group": args.group, "test_positive": result["split_counts"]["heldout_test_positive"], "comparative_claim_supported": result["comparative_claim_supported"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
