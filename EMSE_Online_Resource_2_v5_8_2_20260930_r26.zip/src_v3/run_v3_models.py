"""Fixed chronological V3 evaluations for supported deterministic outcomes."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.feature_extraction import DictVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss

from v3_input_reference import validate_reference


OUTCOMES = ("affected_field_structural_addition", "union")
PROFILES = ("full", "identity_ablated")
MODELS = ("prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured")
NUMERIC = ("title_present", "description_count", "affected_count", "version_entry_count", "vendor_count", "product_count", "reference_count", "reference_host_count", "metric_count", "max_cvss_band")
CATEGORICAL = ("cohort_year", "cwe", "vendors", "products", "reference_hosts")
BUDGETS = (0.05, 0.10, 0.20)
INT32_MAX = np.iinfo(np.int32).max


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compatible_csr(matrix) -> csr_matrix:
    matrix = matrix.tocsr(copy=False)
    if matrix.shape[0] > INT32_MAX or matrix.shape[1] > INT32_MAX or matrix.nnz > INT32_MAX:
        raise RuntimeError("sparse_matrix_exceeds_int32_index_capacity")
    if matrix.indices.dtype == np.int32 and matrix.indptr.dtype == np.int32:
        return matrix
    return csr_matrix((matrix.data, matrix.indices.astype(np.int32, copy=False), matrix.indptr.astype(np.int32, copy=False)), shape=matrix.shape, copy=False)


def read_rows(path: Path, outcome: str) -> list[dict]:
    label = "outcome_" + outcome
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows or any(label not in row for row in rows):
        raise RuntimeError("invalid_v3_model_rows")
    for row in rows:
        row["label"] = int(row[label])
    return rows


def require_manifest(rows_path: Path, manifest_path: Path, reference_path: Path) -> dict:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("purpose") != "CNA-only t_obs model input; V3 structural-change outcomes and evaluation-only grouping":
        raise RuntimeError("v3_model_manifest_purpose_invalid")
    if manifest.get("model_rows_sha256") != sha256(rows_path):
        raise RuntimeError("v3_model_rows_hash_mismatch")
    if manifest.get("input_reference_sha256") != sha256(reference_path):
        raise RuntimeError("v3_model_reference_hash_mismatch")
    return manifest


def select(rows: list[dict], start: str | None, end: str | None) -> list[dict]:
    return [row for row in rows if (start is None or row["t_obs"][:10] >= start) and (end is None or row["t_obs"][:10] <= end)]


def structured(row: dict, profile: str, *, year_only: bool = False) -> dict:
    if year_only:
        return {"year=" + str(row["cohort_year"]): 1.0} if profile == "full" else {"intercept_proxy": 1.0}
    value = {"num=" + key: float(row[key]) for key in NUMERIC}
    categoricals = CATEGORICAL if profile == "full" else ("cwe",)
    if profile == "full":
        value["year=" + str(row["cohort_year"])] = 1.0
    value.update({key + "=" + str(row[key]): 1.0 for key in categoricals if key != "cohort_year"})
    return value


def text_matrix(train: list[dict], other: list[dict]):
    word = TfidfVectorizer(lowercase=True, ngram_range=(1, 2), min_df=2, max_features=150_000, sublinear_tf=True)
    char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=2, max_features=150_000, sublinear_tf=True)
    train_text, other_text = [row["text"] for row in train], [row["text"] for row in other]
    return compatible_csr(hstack([word.fit_transform(train_text), char.fit_transform(train_text)])), compatible_csr(hstack([word.transform(other_text), char.transform(other_text)]))


def dict_matrix(train: list[dict], other: list[dict], profile: str, *, year_only: bool = False):
    vectorizer = DictVectorizer(sparse=True)
    return compatible_csr(vectorizer.fit_transform([structured(row, profile, year_only=year_only) for row in train])), compatible_csr(vectorizer.transform([structured(row, profile, year_only=year_only) for row in other]))


def fit_probability(x_train, y_train: np.ndarray, x_eval) -> np.ndarray:
    if len(set(y_train.tolist())) != 2:
        raise RuntimeError("training_split_lacks_binary_class")
    model = LogisticRegression(C=1.0, max_iter=500, class_weight="balanced", solver="liblinear", random_state=20260906)
    return model.fit(x_train, y_train).predict_proba(x_eval)[:, 1]


def top_capacity(y: np.ndarray, scores: np.ndarray, ids: np.ndarray, budget: float) -> tuple[float, int, int]:
    capacity = int(np.ceil(len(y) * budget))
    selected = y[np.lexsort((ids, -scores))[:capacity]]
    caught, positives = int(selected.sum()), int(y.sum())
    return (float(caught / positives) if positives else float("nan"), caught, capacity)


def ece(y: np.ndarray, scores: np.ndarray) -> float:
    edges = np.linspace(0, 1, 11)
    return float(sum(mask.mean() * abs(float(y[mask].mean()) - float(scores[mask].mean())) for lower, upper in zip(edges[:-1], edges[1:]) if (mask := ((scores >= lower) & ((scores < upper) if upper < 1 else (scores <= upper)))).any()))


def metrics(y: np.ndarray, scores: np.ndarray, ids: np.ndarray) -> dict:
    result = {"pr_auc": float(average_precision_score(y, scores)), "brier": float(brier_score_loss(y, scores)), "ece_10": ece(y, scores), "positive_count": int(y.sum()), "record_count": int(len(y))}
    for budget in BUDGETS:
        recall, caught, capacity = top_capacity(y, scores, ids, budget)
        key = str(int(budget * 100))
        result[f"recall_at_{key}_pct"] = recall
        result[f"false_deferral_at_{key}_pct"] = int(y.sum() - caught)
        result[f"capacity_at_{key}_pct"] = capacity
    result["risk_coverage"] = [{"coverage": budget, "deferred_risk": float((y.sum() - top_capacity(y, scores, ids, budget)[1]) / max(len(y) - top_capacity(y, scores, ids, budget)[2], 1))} for budget in BUDGETS]
    return result


def bootstrap(y: np.ndarray, scores: np.ndarray, ids: np.ndarray, replicates: int, seed: int) -> dict:
    rng, positive, negative = np.random.default_rng(seed), np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    if not len(positive) or not len(negative):
        raise RuntimeError("bootstrap_lacks_binary_class")
    keys = ("pr_auc", "brier", "ece_10", "recall_at_5_pct", "recall_at_10_pct", "recall_at_20_pct")
    samples = {key: [] for key in keys}
    for _ in range(replicates):
        index = np.concatenate([rng.choice(positive, len(positive), replace=True), rng.choice(negative, len(negative), replace=True)])
        one = metrics(y[index], scores[index], ids[index])
        for key in keys:
            samples[key].append(one[key])
    return {key: {"lower_95": float(np.quantile(values, 0.025)), "upper_95": float(np.quantile(values, 0.975))} for key, values in samples.items()}


def evaluate(train: list[dict], test: list[dict], profile: str, replicates: int, seed: int) -> tuple[dict, dict[str, np.ndarray]]:
    y_train, y_test = np.array([row["label"] for row in train]), np.array([row["label"] for row in test])
    ids = np.array([row["cve_id"] for row in test])
    x_year_train, x_year_test = dict_matrix(train, test, profile, year_only=True)
    x_struct_train, x_struct_test = dict_matrix(train, test, profile)
    x_text_train, x_text_test = text_matrix(train, test)
    predictions = {
        "prevalence": np.full(len(test), float(y_train.mean())),
        "year_only": fit_probability(x_year_train, y_train, x_year_test),
        "structured_cna": fit_probability(x_struct_train, y_train, x_struct_test),
        "tfidf_word_character": fit_probability(x_text_train, y_train, x_text_test),
        "fused_tfidf_structured": fit_probability(compatible_csr(hstack([x_text_train, x_struct_train])), y_train, compatible_csr(hstack([x_text_test, x_struct_test]))),
    }
    return {name: {"metrics": metrics(y_test, score, ids), "bootstrap_95": bootstrap(y_test, score, ids, replicates, seed + i)} for i, (name, score) in enumerate(predictions.items())}, predictions


def write_predictions(path: Path, rows: list[dict], predictions: dict[str, np.ndarray]) -> str:
    payload = [{"cve_id": row["cve_id"], "t_obs": row["t_obs"], "label": row["label"], **{name: float(values[i]) for name, values in predictions.items()}} for i, row in enumerate(rows)]
    path.write_text("".join(json.dumps(row) + "\n" for row in payload), encoding="utf-8")
    return sha256(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-rows", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--v3-input-reference", type=Path, required=True)
    parser.add_argument("--v3-labels", type=Path, required=True)
    parser.add_argument("--outcome", choices=OUTCOMES, required=True)
    parser.add_argument("--profile", choices=PROFILES, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--bootstrap-replicates", type=int, default=2000)
    args = parser.parse_args()
    if args.bootstrap_replicates not in {25, 2000}:
        raise RuntimeError("replicates_must_be_25_smoke_or_2000_formal")
    if args.output_dir.exists():
        raise RuntimeError("output_dir_exists")
    reference = validate_reference(args.v3_input_reference, args.v3_labels)
    manifest = require_manifest(args.model_rows, args.model_manifest, args.v3_input_reference)
    rows = read_rows(args.model_rows, args.outcome)
    train, validation, test = select(rows, None, "2024-06-30"), select(rows, "2024-07-01", "2024-12-31"), select(rows, "2025-01-01", "2025-09-30")
    if sum(row["label"] for row in test) < 100:
        raise RuntimeError("outcome_2025_positive_gate_failed")
    out = args.output_dir
    out.mkdir(parents=True)
    validation_report, _ = evaluate(train, validation, args.profile, args.bootstrap_replicates, 20260906)
    test_report, predictions = evaluate(train, test, args.profile, args.bootstrap_replicates, 20261006)
    rolling_2024, _ = evaluate(select(rows, None, "2023-12-31"), select(rows, "2024-01-01", "2024-12-31"), args.profile, args.bootstrap_replicates, 20261106)
    rolling_2025, _ = evaluate(select(rows, None, "2024-12-31"), test, args.profile, args.bootstrap_replicates, 20261206)
    prediction_hash = write_predictions(out / "test_predictions.jsonl", test, predictions)
    result = {"run_id": args.run_id, "protocol": "fixed chronological V3 evaluation; no random split or test tuning", "outcome": args.outcome, "profile": args.profile, "formal": args.bootstrap_replicates == 2000, "bootstrap_replicates": args.bootstrap_replicates, "split_counts": {"train": len(train), "validation": len(validation), "test": len(test), "test_positive": int(sum(row["label"] for row in test))}, "v3_input_reference_sha256": sha256(args.v3_input_reference), "v3_input_reference_run_id": reference["run_id"], "model_rows_sha256": manifest["model_rows_sha256"], "model_manifest_sha256": sha256(args.model_manifest), "validation_models": validation_report, "test_models": test_report, "rolling_origin_models": {"train_through_2023_test_2024": rolling_2024, "train_through_2024_test_2025": rolling_2025}, "test_predictions_sha256": prediction_hash, "python": sys.version, "platform": platform.platform()}
    (out / "chronological_report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"outcome": args.outcome, "profile": args.profile, "test_positive": result["split_counts"]["test_positive"], "prediction_sha256": prediction_hash}))


if __name__ == "__main__":
    raise SystemExit(main())
