"""Build full-window V3 deterministic CNA record-change labels.

The affected outcome is deliberately a structural signature addition, not a
semantic claim about version interval containment or the real affected scope.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path

from audit_asof import baseline_tags, parse_utc, run_git
from build_full_cohort_batch import CatFileBatch, load_json


SEVERITY = {"NONE": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
HISTORY_END_TAG = "2025-12-31_baseline"
OUTCOMES = (
    "affected_field_structural_addition",
    "cna_cvss_escalation_to_high",
    "overlap",
    "union",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cna(record: dict | None) -> dict | None:
    containers = record.get("containers") if isinstance(record, dict) else None
    value = containers.get("cna") if isinstance(containers, dict) else None
    return value if isinstance(value, dict) else None


def state(record: dict | None) -> str:
    metadata = record.get("cveMetadata") if isinstance(record, dict) else None
    return str(metadata.get("state", "")) if isinstance(metadata, dict) else ""


def scope_signature(container: dict) -> set[str]:
    """Return canonical CNA affected signatures without semantic range parsing."""
    signatures = set()
    for affected in container.get("affected", []):
        if not isinstance(affected, dict):
            continue
        vendor = str(affected.get("vendor", "")).strip().casefold()
        product = str(affected.get("product", "")).strip().casefold()
        versions = affected.get("versions", [])
        if not versions:
            signatures.add(json.dumps([vendor, product, "all_versions"], sort_keys=True))
        for version in versions:
            if not isinstance(version, dict):
                continue
            version_range = {
                key: version[key]
                for key in ("version", "status", "lessThan", "lessThanOrEqual", "versionType", "changes")
                if key in version
            }
            signatures.add(json.dumps([vendor, product, version_range], sort_keys=True))
    return signatures


def maximum_severity(container: dict) -> int:
    best = 0
    for metric in container.get("metrics", []):
        if not isinstance(metric, dict):
            continue
        for key, payload in metric.items():
            if not key.lower().startswith("cvss") or not isinstance(payload, dict):
                continue
            declared = SEVERITY.get(str(payload.get("baseSeverity", "")).upper(), 0)
            try:
                score = float(payload.get("baseScore", 0))
            except (TypeError, ValueError):
                score = 0.0
            derived = 4 if score >= 9.0 else 3 if score >= 7.0 else 2 if score >= 4.0 else 1 if score > 0 else 0
            best = max(best, declared, derived)
    return best


def first_endpoint(tags: list[tuple[str, datetime]], timestamp: datetime) -> tuple[str, datetime] | None:
    return next(((tag, tm) for tag, tm in tags if tm >= timestamp), None)


def collect_changes(repo: Path, start_commit: str, end_commit: str, year: int) -> dict[str, list[tuple[str, datetime]]]:
    proc = run_git(repo, "log", "--format=@@%H\t%cI", "--name-only", "--reverse", f"{start_commit}..{end_commit}", "--", f"cves/{year}")
    if proc.returncode:
        raise RuntimeError(f"git_log_failed:{year}:{proc.stderr.strip()}")
    result: dict[str, list[tuple[str, datetime]]] = defaultdict(list)
    commit = None
    commit_time = None
    for line in proc.stdout.splitlines():
        if line.startswith("@@"):
            fields = line[2:].split("\t", 1)
            commit = fields[0]
            commit_time = parse_utc(fields[1]) if len(fields) == 2 else None
        elif line and commit and commit_time and line.startswith(f"cves/{year}/") and line.endswith(".json"):
            result[line].append((commit, commit_time))
    return {path: sorted(items, key=lambda item: (item[1], item[0])) for path, items in result.items()}


def event_flags(affected_added: bool, cvss_escalated: bool) -> dict[str, bool]:
    return {
        "affected_field_structural_addition": affected_added,
        "cna_cvss_escalation_to_high": cvss_escalated,
        "overlap": affected_added and cvss_escalated,
        "union": affected_added or cvss_escalated,
    }


def classify_window(initial: dict | None, changes: list[tuple[str, datetime, dict | None]], observation: datetime, boundary: datetime) -> tuple[str, dict[str, bool], list[dict], dict | None]:
    """Classify every eligible commit in a window; no event causes early return."""
    initial_cna = cna(initial)
    if initial_cna is None:
        return "excluded", event_flags(False, False), [], None
    if state(initial).upper() in {"REJECTED", "DISPUTED"}:
        return "excluded", event_flags(False, False), [], None

    previous_scope = scope_signature(initial_cna)
    previous_severity = maximum_severity(initial_cna)
    affected_added = False
    cvss_escalated = False
    evidence = []
    withdrawal = None
    for commit, commit_time, current in changes:
        if not (observation < commit_time <= boundary) or not isinstance(current, dict):
            continue
        if state(current).upper() in {"REJECTED", "DISPUTED"}:
            withdrawal = {"commit": commit, "time": commit_time.isoformat(), "event": "withdraw"}
            evidence.append(withdrawal)
            break
        current_cna = cna(current)
        if current_cna is None:
            continue
        current_scope = scope_signature(current_cna)
        current_severity = maximum_severity(current_cna)
        new_signatures = current_scope - previous_scope
        if new_signatures:
            affected_added = True
            evidence.append({
                "commit": commit,
                "time": commit_time.isoformat(),
                "event": "affected_field_structural_addition",
                "added_signature_count": len(new_signatures),
            })
        if previous_severity < SEVERITY["HIGH"] <= current_severity:
            cvss_escalated = True
            evidence.append({"commit": commit, "time": commit_time.isoformat(), "event": "cna_cvss_escalation_to_high"})
        previous_scope, previous_severity = current_scope, current_severity
    flags = event_flags(affected_added, cvss_escalated)
    if withdrawal:
        return "withdraw", flags, evidence, withdrawal
    return ("review" if flags["union"] else "defer"), flags, evidence, None


def label_row(row: dict, tags: list[tuple[str, datetime]], changes: dict[str, list[tuple[str, datetime]]], payloads: dict[str, bytes | None], freeze: datetime) -> dict:
    base = {"cve_id": row["cve_id"], "status": "excluded", "reason": None}
    if row.get("status") != "included":
        base["reason"] = "asof_excluded"
        return base
    observation = parse_utc(row["t_obs"])
    boundary = observation + timedelta(days=90)
    if boundary > freeze:
        base["reason"] = "outcome_after_dataset_freeze"
        return base
    endpoint = first_endpoint(tags, boundary)
    if endpoint is None or endpoint[1] > freeze:
        base["reason"] = "outcome_verification_after_dataset_freeze"
        return base
    initial = load_json(payloads.get(f"{row['asof_baseline_tag']}:{row['path']}") or b"")
    selected = []
    for commit, commit_time in changes.get(row["path"], []):
        if observation < commit_time <= boundary:
            selected.append((commit, commit_time, load_json(payloads.get(f"{commit}:{row['path']}") or b"")))
    status, flags, evidence, withdrawal = classify_window(initial, selected, observation, boundary)
    end_tag, verified_at = endpoint
    if status == "excluded":
        reason = "asof_missing_cna" if cna(initial) is None else "withdrawn_at_observation"
        return {**base, "reason": reason}
    return {
        "cve_id": row["cve_id"],
        "status": status,
        "reason": None,
        "t_obs": observation.isoformat(),
        "t_end": boundary.isoformat(),
        "outcome_verified_at": verified_at.isoformat(),
        "end_baseline_tag": end_tag,
        "event_flags": flags,
        "evidence": evidence,
        "withdraw_event": withdrawal,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--asof-jsonl", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--dataset-freeze-time", default="2025-12-31T23:59:59Z")
    parser.add_argument("--chunk-size", type=int, default=500)
    parser.add_argument("--max-records", type=int, default=0, help="Smoke-test limit; zero means the complete frozen cohort.")
    args = parser.parse_args()
    if args.chunk_size <= 0 or args.max_records < 0:
        parser.error("chunk-size must be positive and max-records must be non-negative")
    if args.output.exists():
        raise RuntimeError("v3_label_output_exists")

    repo = args.repo.resolve()
    freeze = parse_utc(args.dataset_freeze_time)
    rows = [json.loads(line) for line in args.asof_jsonl.read_text(encoding="utf-8").splitlines() if line.strip()]
    if args.max_records:
        rows = rows[:args.max_records]
    tags = baseline_tags(repo)
    commits = {}
    ref = run_git(repo, "for-each-ref", "--format=%(refname:strip=2)\t%(objectname)", "refs/tags")
    if ref.returncode:
        raise RuntimeError("tag_commit_lookup_failed")
    for line in ref.stdout.splitlines():
        tag, separator, commit = line.partition("\t")
        if separator:
            commits[tag] = commit
    earliest = commits.get("2023-03-28_baseline")
    history_end = commits.get(HISTORY_END_TAG)
    if not earliest or not history_end:
        raise RuntimeError("required_baseline_tag_missing")
    changes_by_year = {year: collect_changes(repo, earliest, history_end, year) for year in (2023, 2024, 2025)}

    output_rows = []
    for offset in range(0, len(rows), args.chunk_size):
        chunk = rows[offset:offset + args.chunk_size]
        specs = []
        for row in chunk:
            if row.get("status") != "included":
                continue
            observation = parse_utc(row["t_obs"])
            boundary = observation + timedelta(days=90)
            if boundary > freeze:
                continue
            endpoint = first_endpoint(tags, boundary)
            if endpoint is None or endpoint[1] > freeze:
                continue
            specs.append(f"{row['asof_baseline_tag']}:{row['path']}")
            for commit, commit_time in changes_by_year[int(row["cohort_year"])].get(row["path"], []):
                if observation < commit_time <= boundary:
                    specs.append(f"{commit}:{row['path']}")
        reader = CatFileBatch(repo)
        try:
            payloads = {spec: reader.get(spec) for spec in dict.fromkeys(specs)}
        finally:
            reader.close()
        for row in chunk:
            output_rows.append(label_row(row, tags, changes_by_year[int(row["cohort_year"])], payloads, freeze))

    status_counts = Counter(row["status"] for row in output_rows)
    eligible = [row for row in output_rows if row["status"] in {"review", "defer"}]
    outcome_counts = {name: sum(bool(row["event_flags"][name]) for row in eligible) for name in OUTCOMES}
    year_by_id = {row["cve_id"]: int(row["cohort_year"]) for row in rows}
    year_counts = {
        str(year): {
            "eligible": sum(row["status"] in {"review", "defer"} and year_by_id.get(row["cve_id"]) == year for row in output_rows),
            **{
                name: sum(
                    row["status"] in {"review", "defer"}
                    and year_by_id.get(row["cve_id"]) == year
                    and row["event_flags"][name]
                    for row in output_rows
                )
                for name in OUTCOMES
            },
        }
        for year in (2023, 2024, 2025)
    }
    report = {
        "run_type": "time_locked_cna_structural_addition_and_cvss_labels_v3",
        "definition": {
            "affected_field_structural_addition": "A new canonical CNA affected signature; no semantic version interval containment is inferred.",
            "cna_cvss_escalation_to_high": "Maximum CNA CVSS severity transitions from below High to High or Critical.",
            "withdraw_disposition": "Any REJECTED or DISPUTED state within the outcome window excludes the record from binary model fitting.",
        },
        "source_asof_jsonl_sha256": sha256(args.asof_jsonl),
        "max_records": args.max_records,
        "horizon_days": 90,
        "dataset_freeze_time": freeze.isoformat(),
        "status_counts": dict(sorted(status_counts.items())),
        "outcome_counts_eligible": outcome_counts,
        "outcome_counts_by_cohort_year": year_counts,
        "records": output_rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status_counts": report["status_counts"], "outcome_counts_eligible": outcome_counts}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
