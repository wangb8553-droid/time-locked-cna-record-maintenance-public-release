"""Audit reuse of immutable upstream Git objects without changing source worktrees."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo), *args],
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return result.stdout.strip()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def status_count(repo: Path) -> int:
    return len(git(repo, "status", "--porcelain=v1").splitlines())


def audit_repo(repo: Path, role: str, required_tags: tuple[str, ...]) -> dict:
    if not (repo / ".git").exists():
        raise RuntimeError(f"not_a_git_repository:{repo}")
    head = git(repo, "rev-parse", "HEAD")
    tags = {}
    missing = []
    for tag in required_tags:
        try:
            commit = git(repo, "rev-parse", f"{tag}^{{commit}}")
            when = git(repo, "show", "-s", "--format=%cI", commit)
            tags[tag] = {"commit": commit, "commit_time": when}
        except subprocess.CalledProcessError:
            missing.append(tag)
    fsck = subprocess.run(
        ["git", "-C", str(repo), "fsck", "--connectivity-only", "--no-progress"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if fsck.returncode != 0:
        raise RuntimeError(f"git_fsck_failed:{role}:{fsck.returncode}:{fsck.stderr.strip()}")
    remote = git(repo, "remote", "get-url", "origin")
    return {
        "role": role,
        "path": str(repo.resolve()),
        "head": head,
        "head_time": git(repo, "show", "-s", "--format=%cI", head),
        "remote_origin": remote,
        "is_shallow": (git(repo, "rev-parse", "--is-shallow-repository") == "true"),
        "is_bare": (git(repo, "rev-parse", "--is-bare-repository") == "true"),
        "required_tags": tags,
        "missing_required_tags": missing,
        "ref_snapshot_sha256": hashlib.sha256(git(repo, "show-ref").encode("utf-8")).hexdigest(),
        "ref_count": len(git(repo, "show-ref").splitlines()),
        "worktree_porcelain_count": status_count(repo),
        "worktree_policy": "read_git_objects_only; source was intentionally no-checkout and is not modified",
        "fsck_connectivity_exit": fsck.returncode,
        "fsck_connectivity_stderr": fsck.stderr.strip(),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cve-repo", type=Path, required=True)
    parser.add_argument("--kev-repo", type=Path, required=True)
    parser.add_argument("--prior-cve-manifest", type=Path, required=True)
    parser.add_argument("--prior-kev-manifest", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("v4_source_reuse_output_exists")
    cve_tags = (
        "2023-03-28_baseline",
        "2025-09-30_baseline",
        "2025-12-31_baseline",
    )
    kev_tags: tuple[str, ...] = ()
    cve = audit_repo(args.cve_repo.resolve(), "cve_list_v5", cve_tags)
    kev = audit_repo(args.kev_repo.resolve(), "cisa_kev_history", kev_tags)
    prior = [{"path": str(args.prior_cve_manifest.resolve()), "sha256": sha256(args.prior_cve_manifest)}]
    if args.prior_kev_manifest:
        prior.append({"path": str(args.prior_kev_manifest.resolve()), "sha256": sha256(args.prior_kev_manifest)})
    result = {
        "run_id": args.run_id,
        "purpose": "V4 read-only reuse audit; no upstream download or worktree mutation",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "sources": [cve, kev],
        "prior_audit_manifests": prior,
        "download_action": "not_needed_existing_complete_object_databases_reused",
        "source_hashes_bind_integrity_and_provenance_only": True,
        "no_semantic_correctness_or_human_independence_claim": True,
        "python": sys.version,
        "platform": platform.platform(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": args.run_id, "sources": len(result["sources"]), "download_action": result["download_action"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
