"""Fail-closed terminal audit for one V3 formal chronological model run."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


SUPPORTED_OUTCOMES = {"affected_field_structural_addition", "union"}
PROFILES = {"full", "identity_ablated"}
REQUIRED_MODELS = {"prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--metric-audit", type=Path, required=True)
    parser.add_argument("--model-manifest", type=Path, required=True)
    parser.add_argument("--input-reference", type=Path, required=True)
    parser.add_argument("--time-lock-audit", type=Path, required=True)
    parser.add_argument("--runner", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("formal_audit_output_exists")
    report, metrics, manifest, reference, time_lock = (load(path) for path in (args.report, args.metric_audit, args.model_manifest, args.input_reference, args.time_lock_audit))
    prediction_hash, report_hash, runner_hash = sha256(args.predictions), sha256(args.report), sha256(args.runner)
    failures: list[str] = []
    def require(condition: bool, name: str) -> None:
        if not condition:
            failures.append(name)
    require(report.get("formal") is True, "report_not_formal")
    require(report.get("bootstrap_replicates") == 2000, "report_bootstrap_not_2000")
    require(metrics.get("bootstrap_replicates") == 2000, "metric_audit_bootstrap_not_2000")
    require(report.get("outcome") in SUPPORTED_OUTCOMES, "unsupported_or_sparse_outcome")
    require(report.get("profile") in PROFILES, "invalid_profile")
    require(report.get("split_counts", {}).get("test_positive", 0) >= 100, "test_positive_gate_failed")
    require(report.get("test_predictions_sha256") == prediction_hash, "report_prediction_hash_mismatch")
    require(metrics.get("prediction_sha256") == prediction_hash, "metric_audit_prediction_hash_mismatch")
    require(metrics.get("report_sha256") == report_hash, "metric_audit_report_hash_mismatch")
    require(metrics.get("passed") is True, "independent_metric_audit_failed")
    require(report.get("model_rows_sha256") == manifest.get("model_rows_sha256"), "model_rows_hash_mismatch")
    require(report.get("model_manifest_sha256") == sha256(args.model_manifest), "model_manifest_hash_mismatch")
    require(report.get("v3_input_reference_sha256") == sha256(args.input_reference), "input_reference_hash_mismatch")
    require(manifest.get("input_reference_sha256") == sha256(args.input_reference), "manifest_input_reference_hash_mismatch")
    require(reference.get("passed") is True, "input_reference_not_passed")
    require(time_lock.get("passed") is True, "time_lock_audit_failed")
    require(time_lock.get("model_rows_sha256") == manifest.get("model_rows_sha256"), "time_lock_model_rows_hash_mismatch")
    require(time_lock.get("asof_records_sha256") == reference.get("asof_sha256"), "time_lock_asof_hash_mismatch")
    require(time_lock.get("model_delay_hours", {}).get("max", float("inf")) <= 24, "time_lock_window_exceeded")
    require(set(report.get("test_models", {})) == REQUIRED_MODELS, "required_model_set_mismatch")
    require(set(metrics.get("recomputed", {})) == REQUIRED_MODELS, "audited_model_set_mismatch")
    runner_source = args.runner.read_text(encoding="utf-8")
    require("cna_group" not in runner_source, "runner_mentions_evaluation_only_cna_group")
    require("providerMetadata" not in runner_source, "runner_mentions_prohibited_provider_metadata")
    result = {
        "run_id": args.run_id,
        "purpose": "terminal, fail-closed audit for one formal V3 chronological evaluation",
        "model_run_id": report.get("run_id"),
        "report_sha256": report_hash,
        "prediction_sha256": prediction_hash,
        "metric_audit_sha256": sha256(args.metric_audit),
        "model_manifest_sha256": sha256(args.model_manifest),
        "input_reference_sha256": sha256(args.input_reference),
        "time_lock_audit_sha256": sha256(args.time_lock_audit),
        "runner_sha256_at_audit": runner_hash,
        "outcome": report.get("outcome"),
        "profile": report.get("profile"),
        "test_positive": report.get("split_counts", {}).get("test_positive"),
        "bootstrap_replicates": report.get("bootstrap_replicates"),
        "failures": failures,
        "passed": not failures,
        "limitations": [
            "This audit binds artifacts available at audit time; it is not an independent historical source snapshot.",
            "Passing this audit does not establish clinical, exploitability, deployment, or analyst-replacement claims.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "failures": failures}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
