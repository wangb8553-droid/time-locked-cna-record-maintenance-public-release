"""Run a bounded KEV snapshot overlap analysis from frozen V4 predictions.

This tool deliberately has no training, fitting, calibration, or threshold
selection path. A KEV membership in the fixed snapshot is not interpreted as
an exploitation time or as validation of operational triage benefit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True, text=True)
    return result.stdout.strip()


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> dict[str, float | None]:
    if total == 0:
        return {"lower_95": None, "upper_95": None}
    fraction = successes / total
    denom = 1 + (z * z / total)
    center = (fraction + z * z / (2 * total)) / denom
    radius = z * math.sqrt((fraction * (1 - fraction) / total) + (z * z / (4 * total * total))) / denom
    return {"lower_95": max(0.0, center - radius), "upper_95": min(1.0, center + radius)}


def load_predictions(path: Path, score_column: str) -> list[dict]:
    rows = []
    seen = set()
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        row = json.loads(line)
        cve_id, score = row.get("cve_id"), row.get(score_column)
        if not isinstance(cve_id, str) or not cve_id.startswith("CVE-"):
            raise RuntimeError(f"invalid_prediction_cve_id_line_{line_number}")
        if cve_id in seen:
            raise RuntimeError(f"duplicate_prediction_cve_id:{cve_id}")
        if not isinstance(score, (float, int)) or not math.isfinite(float(score)):
            raise RuntimeError(f"invalid_prediction_score_line_{line_number}")
        seen.add(cve_id)
        rows.append({"cve_id": cve_id, "score": float(score), "t_obs": row.get("t_obs")})
    if not rows:
        raise RuntimeError("empty_prediction_file")
    return rows


def load_kev_ids(repo: Path, commit: str) -> tuple[set[str], dict, str]:
    payload_bytes = subprocess.run(
        ["git", "-C", str(repo), "show", f"{commit}:known_exploited_vulnerabilities.json"],
        check=True, capture_output=True,
    ).stdout
    payload = json.loads(payload_bytes.decode("utf-8"))
    vulnerabilities = payload.get("vulnerabilities")
    if not isinstance(vulnerabilities, list):
        raise RuntimeError("kev_vulnerabilities_array_required")
    ids = {row.get("cveID") for row in vulnerabilities if isinstance(row, dict) and isinstance(row.get("cveID"), str)}
    if len(ids) != len(vulnerabilities):
        raise RuntimeError("kev_duplicate_or_invalid_cve_ids")
    return ids, payload, hashlib.sha256(payload_bytes).hexdigest()


def summarise(rows: list[dict], kev_ids: set[str], capacity: float) -> dict:
    if not 0 < capacity <= 1:
        raise RuntimeError("capacity_must_be_in_0_1")
    ranked = sorted(rows, key=lambda row: (-row["score"], row["cve_id"]))
    k = math.ceil(len(ranked) * capacity)
    selected = ranked[:k]
    selected_ids = {row["cve_id"] for row in selected}
    cohort_ids = {row["cve_id"] for row in rows}
    cohort_kev = cohort_ids & kev_ids
    selected_kev = selected_ids & kev_ids
    unselected_kev = cohort_kev - selected_ids
    return {
        "capacity_fraction": capacity,
        "selected_record_count": k,
        "cohort_kev_count": len(cohort_kev),
        "selected_kev_count": len(selected_kev),
        "unselected_kev_count": len(unselected_kev),
        "selected_kev_proportion": len(selected_kev) / k,
        "selected_kev_proportion_wilson_95": wilson_interval(len(selected_kev), k),
        "kev_capture_fraction": (len(selected_kev) / len(cohort_kev)) if cohort_kev else None,
        "unselected_kev_proportion": len(unselected_kev) / (len(rows) - k),
        "unselected_kev_proportion_wilson_95": wilson_interval(len(unselected_kev), len(rows) - k),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--kev-repo", type=Path, required=True)
    parser.add_argument("--snapshot-commit", required=True)
    parser.add_argument("--snapshot-not-after", default="2025-12-31T23:59:59Z")
    parser.add_argument("--score-column", default="structured_cna")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("kev_output_exists")
    commit = git(args.kev_repo, "rev-parse", args.snapshot_commit)
    commit_time = git(args.kev_repo, "show", "-s", "--format=%cI", commit)
    deadline = datetime.fromisoformat(args.snapshot_not_after.replace("Z", "+00:00"))
    observed = datetime.fromisoformat(commit_time)
    if observed > deadline:
        raise RuntimeError("kev_snapshot_after_declared_deadline")
    rows = load_predictions(args.predictions, args.score_column)
    kev_ids, kev_payload, blob_sha = load_kev_ids(args.kev_repo, commit)
    result = {
        "run_id": args.run_id,
        "purpose": "post-freeze KEV snapshot-backed descriptive overlap; not training, calibration, or exploitation prediction",
        "prediction_provenance": {
            "path": str(args.predictions), "sha256": sha256(args.predictions),
            "score_column": args.score_column, "record_count": len(rows),
        },
        "kev_snapshot": {
            "repo": str(args.kev_repo), "commit": commit, "commit_time": commit_time,
            "not_after": args.snapshot_not_after, "json_blob_sha256": blob_sha,
            "catalog_version": kev_payload.get("catalogVersion"), "catalog_date_released": kev_payload.get("dateReleased"),
            "catalog_record_count": len(kev_ids),
        },
        "capacities": [summarise(rows, kev_ids, capacity) for capacity in (0.05, 0.10, 0.20)],
        "boundaries": [
            "KEV data were not used as a model input, label, calibration source, or threshold-selection source.",
            "Snapshot membership is not first exploitation time and is not a causal validation of model utility.",
            "Wilson intervals quantify finite-sample proportions only; correlated records and catalog selection remain limitations.",
        ],
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"run_id": args.run_id, "kev_catalog_count": len(kev_ids), "cohort_kev_count": result["capacities"][0]["cohort_kev_count"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
