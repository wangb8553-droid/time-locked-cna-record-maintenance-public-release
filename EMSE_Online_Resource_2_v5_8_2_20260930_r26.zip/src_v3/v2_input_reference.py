"""Create and validate V2's hash-bound, model-only input reference."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


SCOPE = "time_locked_cna_record_stability_v2_model_only"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_value(repo: Path, *args: str) -> str:
    result = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, encoding="utf-8", check=False)
    if result.returncode:
        raise RuntimeError(f"git_command_failed:{' '.join(args)}")
    return result.stdout.strip()


def validate_reference(reference_path: Path, labels_path: Path, asof_path: Path | None = None, cve_repo: Path | None = None) -> dict:
    if not reference_path.is_file():
        raise RuntimeError("v2_input_reference_missing")
    reference = json.loads(reference_path.read_text(encoding="utf-8"))
    if reference.get("scope") != SCOPE or not reference.get("passed"):
        raise RuntimeError("v2_input_reference_not_passed")
    if reference.get("labels_sha256") != sha256(labels_path):
        raise RuntimeError("v2_labels_hash_mismatch")
    if asof_path is not None and reference.get("asof_sha256") != sha256(asof_path):
        raise RuntimeError("v2_asof_hash_mismatch")
    if cve_repo is not None:
        if Path(reference.get("cve_repo", "")).resolve() != cve_repo.resolve():
            raise RuntimeError("v2_cve_repo_path_mismatch")
        if reference.get("cve_repo_head") != git_value(cve_repo, "rev-parse", "HEAD"):
            raise RuntimeError("v2_cve_repo_head_mismatch")
    return reference


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze-manifest", type=Path, required=True)
    parser.add_argument("--source-manifest", type=Path, required=True)
    parser.add_argument("--cohort-audit", type=Path, required=True)
    parser.add_argument("--label-audit", type=Path, required=True)
    parser.add_argument("--replay-audit", type=Path, required=True)
    parser.add_argument("--statistics", type=Path, required=True)
    parser.add_argument("--asof-jsonl", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--cve-repo", type=Path, required=True)
    parser.add_argument("--kev-source-manifest", type=Path, required=True)
    parser.add_argument("--kev-repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError("v2_reference_output_exists")
    freeze = json.loads(args.freeze_manifest.read_text(encoding="utf-8"))
    source = json.loads(args.source_manifest.read_text(encoding="utf-8"))
    cohort = json.loads(args.cohort_audit.read_text(encoding="utf-8"))
    label = json.loads(args.label_audit.read_text(encoding="utf-8"))
    replay = json.loads(args.replay_audit.read_text(encoding="utf-8"))
    statistics = json.loads(args.statistics.read_text(encoding="utf-8"))
    kev = json.loads(args.kev_source_manifest.read_text(encoding="utf-8"))
    artifacts = (args.freeze_manifest, args.source_manifest, args.cohort_audit, args.label_audit, args.replay_audit, args.statistics, args.asof_jsonl, args.labels, args.kev_source_manifest)
    passed = (
        freeze.get("passed") and source.get("repo_is_shallow") == "false" and source.get("fsck_connectivity_exit") == 0
        and cohort.get("passed") and label.get("passed") and replay.get("passed")
        and replay.get("asof", {}).get("exact_match") and replay.get("labels", {}).get("exact_match")
        and statistics.get("model_branch_gate", {}).get("passed") and kev.get("passed")
        and freeze.get("asof_records_sha256") == sha256(args.asof_jsonl)
        and freeze.get("labels_sha256") == sha256(args.labels)
        and source.get("repo_head") == git_value(args.cve_repo, "rev-parse", "HEAD")
        and kev.get("repo_head") == git_value(args.kev_repo, "rev-parse", "HEAD")
    )
    reference = {
        "run_id": args.run_id, "scope": SCOPE, "created_at": datetime.now(timezone.utc).isoformat(), "passed": bool(passed),
        "v1_disposition": "Read-only upstream deterministic data-route evidence. V2 does not claim human annotation reliability or analyst-process validation.",
        "asof_sha256": sha256(args.asof_jsonl), "labels_sha256": sha256(args.labels),
        "cve_repo": str(args.cve_repo.resolve()), "cve_repo_head": git_value(args.cve_repo, "rev-parse", "HEAD"),
        "kev_repo": str(args.kev_repo.resolve()), "kev_repo_head": git_value(args.kev_repo, "rev-parse", "HEAD"),
        "artifact_sha256": {str(path.resolve()): sha256(path) for path in artifacts},
        "constraints": [
            "No human-label reliability, Cohen kappa, analyst replacement, exploitability, patch-priority, attack-behavior, or CVSS-prediction claim.",
            "V2 predicts only the deterministic, time-locked CNA record-stability outcome.",
            "KEV is post-model-freeze descriptive stress evidence only, never training/calibration/threshold input.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(reference, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": reference["passed"], "asof_sha256": reference["asof_sha256"], "labels_sha256": reference["labels_sha256"]}))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
