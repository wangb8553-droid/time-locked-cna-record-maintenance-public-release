"""Regenerate the primary-model figure using the manuscript's tie-aware baseline."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


COLORS = {
    "prevalence": "#767676",
    "year_only": "#B64342",
    "structured_cna": "#0F4D92",
    "tfidf_word_character": "#42949E",
    "fused_tfidf_structured": "#9A4D8E",
}
LABELS = {
    "prevalence": "Prevalence",
    "year_only": "Year\nonly",
    "structured_cna": "Structured\nCNA",
    "tfidf_word_character": "TF-IDF\ntext",
    "fused_tfidf_structured": "Fusion",
}
EXPECTED_MODELS = tuple(LABELS)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if tuple(row["model"] for row in rows) != EXPECTED_MODELS:
        raise ValueError("model_order_or_set_does_not_match_frozen_contract")
    for row in rows:
        for field in (
            "pr_auc", "pr_auc_lower_95", "pr_auc_upper_95", "brier", "ece_10",
            "recall_at_5_pct", "recall_at_10_pct", "recall_at_20_pct",
        ):
            value = float(row[field])
            if not np.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"invalid_metric:{row['model']}:{field}")
    for model in ("prevalence", "year_only"):
        row = next(item for item in rows if item["model"] == model)
        expected = (0.05, 0.10, 0.20)
        observed = tuple(float(row[f"recall_at_{p}_pct"]) for p in (5, 10, 20))
        if not np.allclose(observed, expected, atol=1e-12, rtol=0):
            raise ValueError(f"constant_baseline_must_use_tie_aware_expectation:{model}")
    return rows


def panel_label(ax, label: str) -> None:
    ax.text(-0.13, 1.03, label, transform=ax.transAxes, fontsize=8,
            fontweight="bold", ha="left", va="bottom")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-data", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise SystemExit("output_dir_must_be_new")
    rows = read_rows(args.source_data)
    args.output_dir.mkdir(parents=True)

    matplotlib.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 7,
        "axes.linewidth": 0.8,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
    })

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.35), layout="constrained")
    x = np.arange(len(rows))
    colors = [COLORS[row["model"]] for row in rows]
    labels = [LABELS[row["model"]] for row in rows]

    # a — primary ranking metric; intervals are row-bootstrap intervals for this fixed cohort.
    values = np.array([float(row["pr_auc"]) for row in rows])
    lower = values - np.array([float(row["pr_auc_lower_95"]) for row in rows])
    upper = np.array([float(row["pr_auc_upper_95"]) for row in rows]) - values
    ax = axes[0]
    ax.bar(x, values, color=colors, yerr=np.vstack([lower, upper]), capsize=2,
           error_kw={"elinewidth": 0.8})
    ax.set_xticks(x, labels, fontsize=5.2)
    ax.set_ylabel("PR-AUC (row-bootstrap 95% CI)")
    ax.set_ylim(0, 0.8)
    panel_label(ax, "a")

    # b — primary operational metric. Constant-score ties use analytic random-selection expectation.
    recall = np.array([float(row["recall_at_10_pct"]) * 100 for row in rows])
    ax = axes[1]
    ax.bar(x, recall, color=colors)
    ax.axhline(10, color="#303030", linewidth=0.8, linestyle=(0, (3, 2)), zorder=0)
    # Keep the annotation in the empty top margin so it cannot obscure a bar.
    ax.text(0.02, 0.97, "Random baseline = 10%", transform=ax.transAxes,
            ha="left", va="top", fontsize=5.2)
    ax.set_xticks(x, labels, fontsize=5.2)
    ax.set_ylabel("Recall at 10% review capacity (%)")
    ax.set_ylim(0, 100)
    panel_label(ax, "b")

    # c — calibration metrics, retained as secondary descriptive evidence.
    brier = np.array([float(row["brier"]) for row in rows])
    ece = np.array([float(row["ece_10"]) for row in rows])
    width = 0.36
    ax = axes[2]
    ax.bar(x - width / 2, brier, width=width, color="#767676", label="Brier")
    ax.bar(x + width / 2, ece, width=width, color="#AADCA9", label="ECE (10 bins)")
    ax.set_xticks(x, labels, fontsize=5.2)
    ax.set_ylabel("Calibration loss")
    ax.set_ylim(0, 0.46)
    ax.legend(fontsize=6)
    panel_label(ax, "c")

    stem = args.output_dir / "figure_2_primary_models"
    outputs = {}
    for suffix, kwargs in (("svg", {}), ("pdf", {}), ("tiff", {"dpi": 600}), ("png", {"dpi": 300})):
        path = stem.with_suffix(f".{suffix}")
        fig.savefig(path, bbox_inches="tight", **kwargs)
        outputs[path.name] = {"sha256": sha256(path), "bytes": path.stat().st_size}
    plt.close(fig)

    from PIL import Image
    png = stem.with_suffix(".png")
    with Image.open(png) as rendered:
        pixels = np.asarray(rendered.convert("RGB"))
        nonwhite_fraction = float((pixels < 245).any(axis=2).mean())
        if nonwhite_fraction <= 0.01:
            raise RuntimeError("blank_figure_detected")
        pixel_size = list(rendered.size)
    svg_text = stem.with_suffix(".svg").read_text(encoding="utf-8")
    if "<text" not in svg_text:
        raise RuntimeError("svg_text_not_editable")
    manifest = {
        "run_id": args.output_dir.name,
        "purpose": "tie-aware update to the fixed-test primary-model figure; no model refitting",
        "backend": "Python/matplotlib",
        "source_data_sha256": sha256(args.source_data),
        "source_row_count": len(rows),
        "constant_score_baseline": "analytic expected recall under random tie-breaking at each fixed capacity",
        "primary_metric": "R@10%",
        "pr_auc_role": "frozen fusion-hypothesis metric; row-bootstrap intervals describe the fixed cohort only",
        "png_pixel_size": pixel_size,
        "png_nonwhite_fraction": nonwhite_fraction,
        "svg_has_editable_text": True,
        "outputs": outputs,
    }
    (args.output_dir / "figure_2_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"run_id": args.output_dir.name, "outputs": list(outputs), "png_pixel_size": pixel_size}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
