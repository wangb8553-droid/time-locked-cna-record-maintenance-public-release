# Rights and attribution

## Project-authored code and documentation

Files under `src_v3/`, `src_v5/`, `src_v5_8/`, `src_public/`, `tests/`, `docs/`, and project-authored metadata are licensed under the MIT License in `LICENSE`.

## Aggregate study outputs

The aggregate result tables, figure source data and rendered figures are made publicly accessible for inspection. They are **not** licensed under MIT, and this release grants no additional reuse licence for those outputs. Do not infer a blanket permission to repackage or create derivative datasets from public download access. Contact the authors if a reuse permission is needed.

## Third-party sources

The study was built from the official CVE List V5 history and, for a secondary descriptive analysis, the CISA Known Exploited Vulnerabilities catalog. Those upstream datasets are not included. Their terms remain independent of the project MIT license. See `source_provenance.json` for the frozen revisions and official links.

The authors state that the project-authored contents in this release are under their control and that no project-specific funding, company contract, confidentiality agreement, or additional institutional approval requirement was identified by the authors for this release. This statement is limited to the authors' supplied authorization and is not a legal opinion about upstream data.
