# Research Protocol V5.8.1: evidence expansion

## Revision status

V5.8 is a post-results revision dated 2026-09-18. It was not retrospectively
preregistered. It does not change V5 labels, source cohort, chronology, model
fits, predictions, capacities or thresholds. V5.7 and all earlier results are
preserved read-only. The revision adds an auditable CPU evidence layer and
clarifies the human-review boundary; it is not evidence that the original
analysis was preregistered.

## Fixed scientific protocol

The cohort spans publication dates 2023-03-28 through 2025-09-30 and uses a
2025-12-31T23:59:59Z source freeze. A record is eligible when
`0 <= t_obs - t_pub <= 24 h`; the outcome window ends at `t_end = t_obs + 90
days`. The model sees only CNA fields available at `t_obs`: `affected`,
`descriptions`, `metrics`, `problemTypes`, `references` and `title`.
ADP/NVD/KEV/EPSS/current-web/provider metadata and future fields are excluded
from model inputs. Provider metadata is evaluation-only grouping information.

The primary event is a new normalized affected signature. The implementation
does not perform version-interval containment and therefore cannot support a
semantic range-expansion claim. No secondary CVSS or union endpoint is used in V5.8.1. Withdrawals and disputes are reported only as trajectory and disposition evidence.

## Scope correction

V5.8.1 is an editorial scope correction after results were visible. It removes the legacy CVSS secondary/union analysis from the active manuscript without changing labels, predictions, splits or thresholds. CVSS artifacts remain historical and are not used to support the single-event claim. KEV remains descriptive only.

## Independent replay and calculation

The V5 raw-Git replayers use different traversal strategies and do not import
the V3 label generator. They scan every qualifying revision through `t_end`,
including changes after withdrawal or dispute, and preserve commit, timestamp,
event type, before/after summaries and source hashes. The frozen replay audit
reports 77,218 records, zero replay mismatches, 390 withdrawals and 24 with
post-withdrawal changes. The seven V3/V5 differences are terminal withdrawals;
the predeclared decision therefore retained the V3 model rows and predictions
with V5 full-window sensitivity.

Independent metric computation uses the saved predictions and the project
definition of average precision (`sklearn.metrics.average_precision_score`),
which groups tied scores at a common threshold. Fixed top-k recall uses the
frozen deterministic score/identifier ordering. Constant-score baselines use
analytic random-selection expectations; exact hypergeometric intervals describe
one random selection and are not bootstrap intervals.

## V5.8 evidence expansion runs

| Run | Purpose | Status | Allowed interpretation |
| --- | --- | --- | --- |
| `v5_8_evidence_expansion_20260918_r01` | Initial gate | failed engineering gate | Preserved failure scene; test IDs were incorrectly required to equal all model rows |
| `v5_8_evidence_expansion_20260918_r02` | Corrected input gate and CPU smoke | passed | Frozen prediction alignment and finite CPU metrics; not retraining or external validation |
| `v5_8_evidence_expansion_20260918_r03` | First stratified smoke | superseded | Preserved because its hand-ranked AP implementation was not tie-consistent |
| `v5_8_evidence_expansion_20260918_r04` | Corrected gate metrics | passed | Authoritative V5.8 gate and tie-consistent CPU point estimates |
| `v5_8_evidence_expansion_20260918_r05` | Corrected five-fold/group smoke | passed | Descriptive stratified stress evidence only |

The r04 inputs are hash-bound to 76,790 model rows and 26,103 saved test
predictions. The gate checks duplicate IDs, test-prediction subset alignment,
label/time equality, finite bounded scores, five-fold assignment, V5 replay
status and the predeclared V5 decision. The r05 five-fold assignment is
`sha256(cve_id)[:8] mod 5`; it is independent of numeric CVE order and is not a
replacement for chronological evaluation.

## Models and reporting

The fixed models are prevalence, year-only, structured CNA, word/character
TF-IDF class-weighted logistic regression and linear fusion. Training ends
2024-06-30; 2024-H2 is descriptive validation and 2025 is the fixed test
period. R@10% is the primary study metric. R@5/20%, PR-AUC, Brier, ECE,
risk-coverage, explicit fixed-budget denominators, 2,000 row bootstrap
replicates, month-block and CNA-group sensitivities, rolling-origin retraining,
identity ablation and vendor/product/CNA holdouts remain frozen analyses.

## Optional and external gates

QLoRA is optional and was not executed. KEV is a post-freeze snapshot-backed
descriptive overlap analysis and is not a training/calibration/threshold source
or a first-exploitation-time measure. No formal GPU task is authorized.

Public release requires author and institutional/IP confirmation, upstream CVE
and KEV redistribution review, a license compatible with the included
project-authored material, a stable repository record, a persistent identifier
and a final manifest. Local hashes and tests do not create those rights or
authorize publication.
