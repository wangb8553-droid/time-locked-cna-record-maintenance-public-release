# Claim and interpretation boundaries

- The label denotes a new normalized CNA affected-field signature, not semantic affected-version expansion.
- The primary metric is R@10%; PR-AUC is retained for the preregistered/frozen fusion comparison. The fusion gain did not meet its fixed threshold.
- The fixed 2025 test cohort has 26,103 records and 2,428 primary events. Grouped uncertainty is materially wider than row-level uncertainty.
- The fixed product holdout is negative: its structured-model PR-AUC is below that set's prevalence baseline and its R@10% is below the random expectation. This is evidence for this stress test only, not every future product.
- KEV overlap is descriptive and post-freeze; it is not a label, calibration source, threshold source, or exploitability outcome.
- No claim is made about deployment, analyst replacement, patch priority, semantic scope growth, QLoRA advantage, or operational savings.
