# V5.8 Data and Model Card

## Intended use

This artifact is a frozen-cohort benchmark for ranking deterministic CNA
record-maintenance events. It is intended for reproducibility studies of
evolving vulnerability metadata. It is not a deployed security decision
system, exploitability predictor, remediation-priority tool or analyst
replacement.

## Data and outcomes

The cohort spans CVE publication dates 2023-03-28 through 2025-09-30. Each
eligible record has an observation recovered within 24 hours of publication and
is followed for 90 days. The primary outcome is the addition of a normalized
`(vendor, product, version/range JSON)` signature. This is a syntactic record
event; it does not establish semantic affected-version or population growth.
The secondary outcome is a CNA CVSS transition from below High to High/Critical.
Withdrawals, disputes, overlaps and unions are reported separately under the
frozen disposition rule.

## Inputs

Allowed model inputs are CNA `affected`, `descriptions`, `metrics`,
`problemTypes`, `references` and `title` available at observation time.
ADP/NVD/KEV/EPSS, current web data, provider metadata and post-observation
fields are excluded from model inputs. Provider metadata is evaluation-only.

## Fixed evaluation

Training ends 2024-06-30, 2024-H2 is descriptive validation and 2025 is the
fixed test period. R@10% is the primary metric. R@5/20%, PR-AUC, Brier, ECE,
fixed-budget denominators, row/month/CNA-group intervals, rolling-origin
analysis, identity ablation and vendor/product/CNA holdouts are retained.
The frozen fusion hypothesis required at least a 0.02 PR-AUC gain over the
TF-IDF comparator with an interval excluding zero; it was not supported.

## Known limitations

The strongest structured signal is identity-dependent, temporal performance
varies, and a fixed product holdout falls below its within-set baseline. Group
and fold smoke results are descriptive and do not establish future-entity or
external-source generalization. No expert annotation, human agreement,
workflow-efficiency measurement, QLoRA result or GPU formal run exists.

## Reuse and access

Project-authored code, tests, protocols, aggregate reports and figure source
data are preserved in a private V5.8 package. Raw upstream CVE/KEV trees,
upstream text, row-level derived payloads, prediction files, case keys, model
weights and dependency binaries are excluded pending authorization and terms
review. The planned MIT licence applies only to authorized project-authored
material.
