# Figure 2 contract

Core conclusion: On the fixed 2025 test cohort, the structured CNA model has the highest PR-AUC and R@10%, while the frozen fusion hypothesis does not meet its predeclared gain threshold; all interpretation is limited by entity dependence and transfer failures.

Archetype: quantitative grid. Target: Empirical Software Engineering article, double-column-width landscape figure. Backend: Python/Matplotlib. Panels: (a) PR-AUC with row-bootstrap 95% intervals for the fixed cohort; (b) primary R@10% at the fixed 10% review capacity, with constant-score baselines shown as analytic random-tie expectations; (c) secondary Brier and 10-bin ECE calibration losses. The fixed-cohort row intervals are not future-entity uncertainty. Aggregate source values are in `source_data/figure_2_primary_models_source_data.csv`.

Reviewer risk addressed: the former graphic displayed CVE-ID-order tie-breaking for constant scores (about 4.5% R@10) while the manuscript table used the predeclared tie-aware expected value (10%). This release regenerates the graphic from the latter rule and states that baseline explicitly. No model was refit.
