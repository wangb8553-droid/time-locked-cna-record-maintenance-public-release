# Public release addendum (2026-09-26)

This addendum records a later access/distribution decision. It does not retroactively preregister the post-results V5.8.1 protocol or change any labels, source cohort, chronology, model fits, predictions, capacities, thresholds, or manuscript claims.

The public package contains project-authored code, tests, protocols, aggregate outputs, and figure files. It excludes upstream raw histories and record text, row-level labels/predictions/trajectories, case keys, private review material, model weights and credentials. The archive manifest binds every distributed file by SHA-256. The aggregate outputs are not assigned the MIT license; the MIT license covers only software, tests and documentation.

The V5 full-window replay summary remains 77,218 records, zero replay mismatches, 390 withdrawals, and 24 records with post-withdrawal changes. The model table is a deterministic reproducibility rerun of the frozen analysis, not an independent implementation validation or external-source replication.
