# Public source-data map

| Manuscript evidence | Public file(s) | Unit and limitation |
| --- | --- | --- |
| Annual cohort and event prevalence | `source_data/figure_1_cohort_drift_source_data.csv`, `source_data/manuscript_tables/table_1.csv` | One row per cohort year; aggregate counts only. |
| Fixed-cohort model metrics | `source_data/figure_2_primary_models_source_data.csv`, `source_data/manuscript_tables/table_2.csv` | One row per model; intervals are fixed-cohort row-bootstrap intervals. Constant-score recall is an analytic random-tie expectation. |
| Identity ablation, grouped uncertainty and entity holdouts | `source_data/figure_3_sensitivities_source_data.csv`, `source_data/figure_5_transfer_and_drift_source_data.csv`, `source_data/figure_6_construct_and_identity_source_data.csv`, `source_data/manuscript_tables/table_4.csv` | Aggregated model/group summaries; do not interpret as universal performance for unseen entities. |
| Fixed-budget coverage and deferral | `source_data/figure_4_fixed_budget_capture_source_data.csv`, `source_data/manuscript_tables/table_3.csv` | Explicit denominators: 2,428 total events and 26,103 test records. Deferred event rate is not a security-risk rate. |
| Frozen-prediction stratified stability check | `source_data/stratified_prediction_fold_summary.csv` | Five anonymous hash-assigned folds; aggregate test only, not cross-validation or external validation. |
| Descriptive group-prevalence heterogeneity | `source_data/group_prevalence_range_summary.csv` | Only counts and prevalence ranges for groups with at least 50 records; entity names and row-level data are excluded. |
| V5 replay and disposition audit | `source_data/figure_s1_v5_full_window_replay_source_data.csv` | Aggregate replay counts only; full per-record trajectories are excluded. |
| KEV descriptive overlap | `source_data/figure_s3_kev_descriptive_overlap_source_data.csv` | Snapshot-backed aggregate counts only; not exploitability prediction or first-exploitation timing. |

Full upstream histories and row-level intermediate artifacts are not redistributed. Readers must retrieve the upstream sources from their official repositories, verify the frozen commit IDs in `source_provenance.json`, and rebuild the analysis inputs with the included scripts before independently rerunning the full model pipeline.
