# Online Resource 2 metadata

Article title: A Time-Locked Benchmark for CNA Record Maintenance: Predictability, Identity Dependence, and Temporal Drift

Journal: Empirical Software Engineering

Authors:
- Bo Wang, School of Computer Science & Artificial Intelligence, Lanzhou Institute of Technology, Lanzhou, Gansu 730300, China
- Jiapeng Wei, Department of Physical Education, Lanzhou Institute of Technology, Lanzhou, Gansu 730300, China

Corresponding author: Jiapeng Wei, weijp@lzit.edu.cn

Zenodo archive version: 5.8.2-r14. Concept DOI: https://doi.org/10.5281/zenodo.23032471. Check the Zenodo record for deposit status and the version-specific DOI assigned to this archive.

Contents: project-authored code, tests, protocols, aggregate cohort/model/replay summaries, manuscript table source data, and figure source data. This archive does not contain raw CVE or KEV repositories, original record text, record-level labels or predictions, full per-record trajectories, case keys, model weights, dependency binaries, or private review material.

Rights: The MIT License applies only to project-authored code, tests and documentation. Aggregate outputs are provided for access and inspection, without a separate reuse licence. Third-party source data remain subject to their own terms.
