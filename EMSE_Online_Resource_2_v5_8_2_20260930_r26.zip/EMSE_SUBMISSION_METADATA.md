# EMSE submission metadata — Online Resource 2

**Article title:** A Time-Locked Benchmark for CNA Record Maintenance: Identity Dependence and Transfer Limits  
**Journal:** Empirical Software Engineering  
**Authors:** Bo Wang; Jiapeng Wei  
**Affiliation 1:** School of Computer Science & Artificial Intelligence, Lanzhou Institute of Technology, Lanzhou, Gansu 730300, China  
**Affiliation 2:** Department of Physical Education, Lanzhou Institute of Technology, Lanzhou, Gansu 730300, China  
**Corresponding author:** Jiapeng Wei, weijp@lzit.edu.cn

This resource contains the files from the public 5.8.2-r14 reproducibility archive unchanged, plus this submission metadata note. The original public GitHub release and Zenodo record have not been modified. The r14 artifact supports the original fixed chronological analyses and predates the revision-specific post hoc group-holdout sensitivity analyses supplied in Online Resource 3.

**Original public archive SHA-256:** `14908a7ba9f36a071b8b21f9356a9c82e5bb428666eeea2610fec5e0cde7846d`
