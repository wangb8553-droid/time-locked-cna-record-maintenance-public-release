"""Stratified, frozen-prediction sensitivity tables for V5.8."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
from sklearn.metrics import average_precision_score


FIELDS = ["prevalence", "structured_cna", "tfidf_word_character", "fused_tfidf_structured"]


def fold(cid: str) -> int:
    return int(hashlib.sha256(cid.encode()).hexdigest()[:8], 16) % 5


def ap_score(y, s):
    if not sum(y):
        return None
    return float(average_precision_score(y, s))


def r10(y, s):
    k = max(1, math.ceil(len(y) * 0.10))
    order = sorted(range(len(y)), key=lambda i: (-s[i], i))[:k]
    return sum(y[i] for i in order) / max(1, sum(y))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=Path, required=True)
    ap.add_argument("--predictions", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rows = {}
    with args.rows.open(encoding="utf-8") as f:
        for line in f:
            r = json.loads(line)
            rows[r["cve_id"]] = r
    preds = []
    with args.predictions.open(encoding="utf-8") as f:
        for line in f:
            p = json.loads(line)
            if p["cve_id"] in rows:
                preds.append(p)
    def label(cid):
        return int(rows[cid].get("outcome_affected_field_structural_addition", 0))

    folds = {}
    for fidx in range(5):
        subset = [p for p in preds if fold(p["cve_id"]) == fidx]
        y = [label(p["cve_id"]) for p in subset]
        models = {}
        for name in FIELDS:
            s = [float(p[name]) for p in subset]
            models[name] = {"pr_auc": ap_score(y, s), "r_at_10_pct": r10(y, s)}
        folds[str(fidx)] = {"record_count": len(subset), "positive_count": sum(y), "prevalence": sum(y) / len(y), "models": models}

    groups = {}
    for key in ("cna_group", "vendors", "products"):
        buckets = defaultdict(list)
        for p in preds:
            value = rows[p["cve_id"]].get(key) or "__missing__"
            buckets[str(value)].append(p)
        ranked = sorted(buckets.items(), key=lambda kv: (-len(kv[1]), kv[0]))
        records = []
        for value, subset in ranked:
            if len(subset) < 50:
                continue
            y = [label(p["cve_id"]) for p in subset]
            s = [float(p["structured_cna"]) for p in subset]
            records.append({"group": value, "record_count": len(subset), "positive_count": sum(y), "prevalence": sum(y) / len(y), "structured_pr_auc": ap_score(y, s), "structured_r_at_10_pct": r10(y, s)})
            if len(records) >= 25:
                break
        groups[key] = records
    result = {"run_id": "v5_8_evidence_expansion_20260918_r05", "scope": "frozen 2025 predictions; stratified smoke only", "records": len(preds), "fold_metrics": folds, "top_groups_n_ge_50": groups, "limitations": ["No retraining or external source was used.", "Group tables are descriptive stress tests; they do not establish future-entity generalization.", "AP uses sklearn average_precision_score so tied scores are threshold-grouped consistently with the primary reports."]}
    (args.out / "v5_8_stratified_smoke.json").write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with (args.out / "v5_8_group_metrics.csv").open("w", encoding="utf-8") as f:
        f.write("group_type,group,record_count,positive_count,prevalence,structured_pr_auc,structured_r_at_10_pct\n")
        for key, records in groups.items():
            for r in records:
                group = r["group"].replace('"', '""')
                f.write(f'{key},"{group}",{r["record_count"]},{r["positive_count"]},{r["prevalence"]},{r["structured_pr_auc"]},{r["structured_r_at_10_pct"]}\n')
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
