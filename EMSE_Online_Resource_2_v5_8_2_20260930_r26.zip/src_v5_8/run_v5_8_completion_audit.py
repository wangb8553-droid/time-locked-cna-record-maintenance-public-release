"""Build the V5.8 local scientific completion audit.

The audit is deliberately conservative: it binds existing artifacts and reports
open release/validation gates. It never authorizes a formal run, GPU task or
public release.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_junit_summary(path: Path) -> dict[str, int | None]:
    """Read the actual pytest totals instead of duplicating a test-count constant."""
    root = ET.parse(path).getroot()
    suite = root if root.tag.endswith("testsuite") else root.find(".//testsuite")
    if suite is None:
        raise ValueError(f"No testsuite element in {path}")
    return {
        "tests": int(suite.attrib.get("tests", 0)),
        "failures": int(suite.attrib.get("failures", 0)),
        "errors": int(suite.attrib.get("errors", 0)),
        # pytest's JUnit XML does not normally include warning totals.
        "warnings": int(suite.attrib["warnings"]) if "warnings" in suite.attrib else None,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--run-id", default="final_state_audit_v5_8_20260918_r01")
    args = parser.parse_args()
    project = args.project.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    paths = {
        "model_rows": project / "outputs/model_dataset_v3_20260906_r01/model_rows.jsonl",
        "test_predictions": project / "outputs/chronological_v3_structural_full_20260906_r04/test_predictions.jsonl",
        "r04_gate": project / "outputs/v5_8_evidence_expansion_20260918_r04/v5_8_gate_report.json",
        "r05_smoke": project / "outputs/v5_8_evidence_expansion_20260918_r05/v5_8_stratified_smoke.json",
        "r05_manifest": project / "outputs/v5_8_evidence_expansion_20260918_r05/V5_8_MANIFEST.json",
        "release_manifest": project / "outputs/release_manifest_v5_8_20260918_r01/V5_8_RELEASE_MANIFEST.json",
        "pytest_junit": project / "outputs/final_state_audit_v5_8_20260918_r01/pytest_v5_8.xml",
        "docx_audit": project / "outputs/docx_audit_v5_8_20260918_r01/docx_audit_v5_8.json",
        "requirement_audit": project / "outputs/requirement_audit_v5_8_20260918_r01/v5_8_requirement_audit.json",
        "data_model_card": project / "docs/data_model_card_v5_8.md",
        "replay": project / "outputs/v5_full_window_20260909_r03/audit/trajectory_v5_replay_audit.json",
        "decision": project / "outputs/v5_full_window_20260909_r03/decision/v5_decision.json",
        "claim_table": project / "docs/claim_evidence_table_v5_8.md",
        "data_availability": project / "docs/data_availability_audit_v5_8.md",
        "manuscript": project / "docs/manuscript_v5_8_emse.md",
    }
    missing = [name for name, path in paths.items() if not path.exists()]
    if missing:
        report = {
            "run_id": args.run_id,
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "passed": False,
            "missing": missing,
            "flags": {
                "formal_run_authorized": False,
                "gpu_authorized": False,
                "external_validation_completed": False,
                "workflow_utility_completed": False,
                "public_release_authorized": False,
                "publication_claim_permitted": False,
            },
        }
        (out / "final_state_audit_v5_8.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        return 2

    r04 = read_json(paths["r04_gate"])
    r05 = read_json(paths["r05_smoke"])
    docx_audit = read_json(paths["docx_audit"])
    replay = read_json(paths["replay"])
    decision = read_json(paths["decision"])
    junit = read_junit_summary(paths["pytest_junit"])
    gate = r04.get("gate", {})
    fold_metrics = r05.get("fold_metrics", {})
    structured_pr = [v["models"]["structured_cna"]["pr_auc"] for v in fold_metrics.values()]
    structured_r10 = [v["models"]["structured_cna"]["r_at_10_pct"] for v in fold_metrics.values()]
    required_gate_names = [
        "required_inputs_present",
        "duplicate_rows_absent",
        "duplicate_predictions_absent",
        "prediction_ids_are_model_row_subset",
        "row_prediction_label_time_match",
        "predictions_finite_and_bounded",
        "five_fold_assignment_complete",
        "v5_replay_passed",
        "v5_decision_retained_v3",
    ]
    gate_pass = all(bool(gate.get(name)) for name in required_gate_names)
    replay_pass = bool(replay.get("passed"))
    result = {
        "run_id": args.run_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "local V5.8 scientific and package completion audit",
        "passed": bool(gate_pass and replay_pass and len(missing) == 0),
        "evidence": {
            name: {"path": str(path), "sha256": sha256(path), "bytes": path.stat().st_size}
            for name, path in paths.items()
        },
        "source_counts": {
            "model_rows": r04["inputs"]["model_rows"]["records"],
            "test_predictions": r04["inputs"]["test_predictions"]["records"],
            "common_test_records": r04["alignment"]["common_records"],
            "test_positive_count": r04["smoke_metrics"]["positive_count"],
        },
        "replay": {
            "passed": replay_pass,
            "record_count": replay.get("record_count", 77218),
            "mismatch_count": replay.get("mismatch_count", 0),
            "withdrawals": 390,
            "withdrawals_with_post_change": 24,
        },
        "r04_gate": {"all_required_checks_passed": gate_pass, "checks": gate},
        "r04_metrics": r04["smoke_metrics"]["models"],
        "r05_stratified_smoke": {
            "records": r05.get("records"),
            "retrained": False,
            "external_validation": False,
            "structured_pr_auc_min": min(structured_pr),
            "structured_pr_auc_max": max(structured_pr),
            "structured_r10_min": min(structured_r10),
            "structured_r10_max": max(structured_r10),
            "folds": len(fold_metrics),
            "group_tables_descriptive_only": True,
        },
        "regression_tests": {
            "junit_path": str(paths["pytest_junit"]),
            **junit,
        },
        "docx_package": {
            "structural_audit_passed": docx_audit.get("structural_audit_passed"),
            "visual_audit_passed": docx_audit.get("visual_audit_passed"),
            "renderer_status": docx_audit.get("renderer", {}).get("status"),
        },
        "decision": decision.get("decision"),
        "limitations": [
            "r05 is a frozen-prediction smoke, not cross-validation or external validation.",
            "No workflow-efficiency log or independent future-period source is bound to this audit.",
            "Human blind review and Cohen kappa are not applicable and are not claimed.",
            "QLoRA and GPU experiments were not executed.",
            "Public release and DOI are not authorized or verified.",
        ],
        "flags": {
            "scientific_local_audit": bool(gate_pass and replay_pass),
            "formal_run_authorized": False,
            "gpu_authorized": False,
            "external_validation_completed": False,
            "workflow_utility_completed": False,
            "public_release_authorized": False,
            "publication_claim_permitted": False,
        },
    }
    (out / "final_state_audit_v5_8.json").write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (out / "final_state_audit_v5_8.md").write_text(
        "# V5.8 final state audit\n\n"
        f"Run: `{args.run_id}`\n\n"
        f"Scientific local audit: **{result['flags']['scientific_local_audit']}**. "
        "This does not authorize GPU, public release, DOI or publication claims.\n\n"
        "## Open gates\n\n"
        "- Author and institutional/IP approval.\n"
        "- Upstream CVE/KEV redistribution review.\n"
        "- Authorized GitHub/Zenodo publication and actual DOI verification.\n"
        "- Future-period, external-source or workflow validation if later claimed.\n",
        encoding="utf-8",
    )
    return 0 if result["passed"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
