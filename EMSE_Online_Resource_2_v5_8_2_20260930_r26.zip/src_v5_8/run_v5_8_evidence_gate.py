"""Hash-bound V5.8 evidence expansion gate.

This run consumes only frozen V5.7 artifacts. It does not retrain a model or
change labels. The purpose is to make the reproducibility, duplicate/leakage,
and finite CPU smoke checks explicit before any later extension is authorized.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from sklearn.metrics import average_precision_score


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n"


def read_jsonl(path: Path):
    with path.open(encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid JSONL at {path}:{line_no}: {exc}") from exc


def average_precision(y, score):
    if sum(y) == 0:
        return None
    # Use the project/scikit-learn definition, which groups tied scores at a
    # common threshold. A hand-ranked implementation can silently change AP
    # for prevalence/year-only scores with many ties.
    return float(average_precision_score(y, score))


def recall_at(y, score, fraction):
    k = max(1, math.ceil(len(y) * fraction))
    order = sorted(range(len(y)), key=lambda i: (-score[i], i))
    return sum(y[i] for i in order[:k]) / max(1, sum(y)), k


def brier(y, score):
    return sum((a - b) ** 2 for a, b in zip(y, score)) / len(y)


def ece(y, score, bins=10):
    total = len(y)
    value = 0.0
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        idx = [i for i, p in enumerate(score) if lo <= p < hi or (b == bins - 1 and p == hi)]
        if idx:
            value += len(idx) / total * abs(sum(y[i] for i in idx) / len(idx) - sum(score[i] for i in idx) / len(idx))
    return value


def fold_for(cve_id: str) -> int:
    # Stable, order-independent assignment; no CVE numeric ordering is used.
    return int(hashlib.sha256(cve_id.encode("utf-8")).hexdigest()[:8], 16) % 5


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--run-id", default="v5_8_evidence_expansion_20260918_r01")
    args = ap.parse_args()
    project = args.project.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)

    rows_path = project / "outputs/model_dataset_v3_20260906_r01/model_rows.jsonl"
    pred_path = project / "outputs/chronological_v3_structural_full_20260906_r04/test_predictions.jsonl"
    replay_path = project / "outputs/v5_full_window_20260909_r03/audit/trajectory_v5_replay_audit.json"
    decision_path = project / "outputs/v5_full_window_20260909_r03/decision/v5_decision.json"
    release_path = project / "release_staging_v5_6_20260917_r04/RELEASE_MANIFEST.json"
    required = [rows_path, pred_path, replay_path, decision_path, release_path]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        report = {"run_id": args.run_id, "passed": False, "failure": "missing_inputs", "missing": missing}
        (out / "input_failure.json").write_text(dumps(report), encoding="utf-8")
        return 2

    rows = list(read_jsonl(rows_path))
    preds = list(read_jsonl(pred_path))
    row_by_id = {r.get("cve_id"): r for r in rows}
    pred_by_id = {r.get("cve_id"): r for r in preds}
    row_ids = [r.get("cve_id") for r in rows]
    pred_ids = [r.get("cve_id") for r in preds]
    duplicate_rows = [k for k, v in Counter(row_ids).items() if not k or v > 1]
    duplicate_preds = [k for k, v in Counter(pred_ids).items() if not k or v > 1]
    common = sorted(set(row_by_id) & set(pred_by_id))
    missing_in_rows = sorted(set(pred_by_id) - set(row_by_id))
    missing_in_preds = sorted(set(row_by_id) - set(pred_by_id))

    mismatches = []
    for cid in common:
        a, b = row_by_id[cid], pred_by_id[cid]
        label = int(a.get("outcome_affected_field_structural_addition", 0))
        if int(b.get("label")) != label:
            mismatches.append({"cve_id": cid, "kind": "label", "rows": label, "predictions": b.get("label")})
        if str(a.get("t_obs")) != str(b.get("t_obs")):
            mismatches.append({"cve_id": cid, "kind": "t_obs", "rows": a.get("t_obs"), "predictions": b.get("t_obs")})

    score_fields = ["prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured"]
    nonfinite = []
    for cid in common:
        for field in score_fields:
            value = pred_by_id[cid].get(field)
            if not isinstance(value, (int, float)) or not math.isfinite(float(value)) or not 0 <= float(value) <= 1:
                nonfinite.append({"cve_id": cid, "field": field, "value": value})

    test = [pred_by_id[cid] for cid in common]
    y = [int(row_by_id[cid].get("outcome_affected_field_structural_addition", 0)) for cid in common]
    fold_ids = {cid: fold_for(cid) for cid in common}
    fold_counts = {}
    for fold in range(5):
        ids = [cid for cid in common if fold_ids[cid] == fold]
        yy = [int(row_by_id[cid].get("outcome_affected_field_structural_addition", 0)) for cid in ids]
        fold_counts[str(fold)] = {"record_count": len(ids), "positive_count": sum(yy), "prevalence": sum(yy) / len(ids) if ids else None, "unique_ids": len(ids) == len(set(ids))}

    metrics = {}
    for field in score_fields:
        score = [float(pred_by_id[cid][field]) for cid in common]
        values = {}
        for pct in (0.05, 0.10, 0.20):
            rec, k = recall_at(y, score, pct)
            values[f"recall_at_{int(pct * 100)}pct"] = rec
            values[f"capacity_at_{int(pct * 100)}pct"] = k
            values[f"captured_at_{int(pct * 100)}pct"] = round(rec * sum(y))
            values[f"omitted_at_{int(pct * 100)}pct"] = sum(y) - round(rec * sum(y))
        values.update({"pr_auc": average_precision(y, score), "brier": brier(y, score), "ece_10": ece(y, score)})
        metrics[field] = values

    replay = json.loads(replay_path.read_text(encoding="utf-8"))
    decision = json.loads(decision_path.read_text(encoding="utf-8"))
    gate = {
        "required_inputs_present": not missing,
        "duplicate_rows_absent": not duplicate_rows,
        "duplicate_predictions_absent": not duplicate_preds,
        "prediction_ids_are_model_row_subset": not missing_in_rows,
        "row_prediction_label_time_match": not mismatches,
        "predictions_finite_and_bounded": not nonfinite,
        "five_fold_assignment_complete": len(fold_ids) == len(common) and all(v["unique_ids"] for v in fold_counts.values()),
        "v5_replay_passed": bool(replay.get("passed")),
        "v5_decision_retained_v3": decision.get("decision") == "retain_v3_model_results_with_v5_full_window_sensitivity",
    }
    # A/B smoke is authorized only when the frozen inputs are internally consistent.
    gate["ab_smoke_authorized"] = all(gate.values())
    result = {
        "run_id": args.run_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "frozen V5.7 evidence expansion gate and finite CPU smoke",
        "scope": "no label rebuild, no model retraining, no GPU, no external validation",
        "inputs": {
            "model_rows": {"path": str(rows_path), "sha256": sha256(rows_path), "records": len(rows)},
            "test_predictions": {"path": str(pred_path), "sha256": sha256(pred_path), "records": len(preds)},
            "v5_replay_audit": {"path": str(replay_path), "sha256": sha256(replay_path)},
            "v5_decision": {"path": str(decision_path), "sha256": sha256(decision_path)},
            "release_manifest": {"path": str(release_path), "sha256": sha256(release_path)},
        },
        "alignment": {"common_records": len(common), "missing_in_rows": missing_in_rows[:20], "missing_in_predictions": missing_in_preds[:20], "mismatch_count": len(mismatches), "nonfinite_count": len(nonfinite)},
        "five_fold_freeze": {"hash": "sha256(cve_id)[:8] mod 5", "folds": fold_counts},
        "smoke_metrics": {"record_count": len(y), "positive_count": sum(y), "prevalence": sum(y) / len(y) if y else None, "models": metrics},
        "gate": gate,
        "limitations": ["This is a frozen-prediction smoke and audit, not an independent external validation.", "No real workflow-efficiency log or independent source was available in the bound inputs.", "Group/bootstrap uncertainty remains a manuscript-level limitation and is not replaced by the five-fold partition."],
        "python": sys.version,
        "platform": platform.platform(),
    }
    (out / "v5_8_gate_report.json").write_text(dumps(result), encoding="utf-8")
    (out / "v5_8_metrics.csv").write_text("model,pr_auc,brier,ece_10,recall_at_5pct,recall_at_10pct,recall_at_20pct,captured_at_10pct,omitted_at_10pct\n" + "\n".join(
        f"{name},{vals['pr_auc']},{vals['brier']},{vals['ece_10']},{vals['recall_at_5pct']},{vals['recall_at_10pct']},{vals['recall_at_20pct']},{vals['captured_at_10pct']},{vals['omitted_at_10pct']}" for name, vals in metrics.items()
    ) + "\n", encoding="utf-8")
    return 0 if gate["ab_smoke_authorized"] else 3


if __name__ == "__main__":
    raise SystemExit(main())
