# Source data index

All files here contain aggregate counts or model/group-level statistics. No CVE identifier, original CVE/KEV record text, row-level label, full trajectory, per-record prediction, or case key is included.

- `figure_1*` through `figure_6*`: source data for the six main-text figures.
- `figure_s1*` through `figure_s3*`: source data for supplementary figures.
- `manuscript_tables/table_1.csv` through `table_4.csv`: the manuscript's four aggregate tables in machine-readable form.
- `stratified_prediction_fold_summary.csv`: five anonymous fold-level summaries of frozen predictions; this is not cross-validation.
- `group_prevalence_range_summary.csv`: counts and prevalence ranges for group categories with at least 50 records; group names are omitted.
- Figure 2 baseline R@5/10/20 values are the analytic expected recall for random tie-breaking at the fixed selection capacities, matching the manuscript table and baseline definition.

Numeric definitions and limitations are in `docs/source_data_mapping.md`.
