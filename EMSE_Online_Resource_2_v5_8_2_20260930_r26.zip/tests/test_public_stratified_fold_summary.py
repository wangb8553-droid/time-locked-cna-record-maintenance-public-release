from __future__ import annotations

import csv
from pathlib import Path


def test_public_fold_summary_is_aggregate_and_complete() -> None:
    path = Path(__file__).resolve().parents[1] / "source_data" / "stratified_prediction_fold_summary.csv"
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
        assert reader.fieldnames == [
            "fold", "record_count", "positive_count", "prevalence",
            "structured_pr_auc", "structured_r_at_10_pct",
        ]

    assert [int(row["fold"]) for row in rows] == [0, 1, 2, 3, 4]
    assert sum(int(row["record_count"]) for row in rows) == 26_103
    assert sum(int(row["positive_count"]) for row in rows) == 2_428
    assert all(0 <= float(row["prevalence"]) <= 1 for row in rows)
    assert all(0 <= float(row["structured_pr_auc"]) <= 1 for row in rows)
    assert all(0 <= float(row["structured_r_at_10_pct"]) <= 1 for row in rows)
