from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src_public"))
from plot_public_fig2_r01 import read_rows  # noqa: E402


class PublicFigureBaselineTests(unittest.TestCase):
    def test_constant_score_recall_uses_random_tie_expectation(self) -> None:
        source = ROOT / "source_data" / "figure_2_primary_models_source_data.csv"
        rows = {row["model"]: row for row in read_rows(source)}
        for name in ("prevalence", "year_only"):
            self.assertAlmostEqual(float(rows[name]["recall_at_5_pct"]), 0.05)
            self.assertAlmostEqual(float(rows[name]["recall_at_10_pct"]), 0.10)
            self.assertAlmostEqual(float(rows[name]["recall_at_20_pct"]), 0.20)


if __name__ == "__main__":
    unittest.main()
