from __future__ import annotations

import sys
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src_v3"))
from audit_v3_prediction_metrics import bootstrap, main, metric_set, numeric_differences, sha256  # noqa: E402


class MetricAuditTest(unittest.TestCase):
    def test_nested_metrics_and_risk_coverage_are_compared(self) -> None:
        expected = {
            "metrics": {"pr_auc": 0.5, "risk_coverage": [{"coverage": 0.1, "deferred_risk": 0.2}]},
            "bootstrap_95": {"pr_auc": {"lower_95": 0.4, "upper_95": 0.6}},
        }
        actual = {
            "metrics": {"pr_auc": 0.5, "risk_coverage": [{"coverage": 0.1, "deferred_risk": 0.25}]},
            "bootstrap_95": {"pr_auc": {"lower_95": 0.4, "upper_95": 0.6}},
        }
        differences = numeric_differences(expected, actual)
        self.assertEqual(differences["metrics.pr_auc"], 0.0)
        self.assertAlmostEqual(differences["metrics.risk_coverage[0].deferred_risk"], 0.05)

    def test_metric_key_mismatch_fails_closed(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "metric_key_mismatch"):
            numeric_differences({"pr_auc": 0.5}, {"pr_auc": 0.5, "brier": 0.1})

    def test_cli_bootstrap_seed_reproduces_nondefault_runner_seed(self) -> None:
        rows = [
            {"cve_id": "CVE-1", "label": 0},
            {"cve_id": "CVE-2", "label": 1},
            {"cve_id": "CVE-3", "label": 0},
        ]
        for row, score in zip(rows, (0.1, 0.9, 0.2)):
            for model in ("prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured"):
                row[model] = score
        y = np.array([row["label"] for row in rows], dtype=int)
        ids = np.array([row["cve_id"] for row in rows])
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            predictions = root / "predictions.jsonl"
            predictions.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
            report = root / "report.json"
            report.write_text(json.dumps({
                "test_predictions_sha256": sha256(predictions),
                "bootstrap_replicates": 1,
                "outcome": "affected_field_structural_addition",
                "profile": "full",
                "test_models": {
                    model: {"metrics": metric_set(y, np.array([row[model] for row in rows]), ids), "bootstrap_95": bootstrap(y, np.array([row[model] for row in rows]), ids, 1, 77 + index)}
                    for index, model in enumerate(("prevalence", "year_only", "structured_cna", "tfidf_word_character", "fused_tfidf_structured"))
                },
            }), encoding="utf-8")
            output = root / "audit.json"
            with patch.object(sys, "argv", ["audit", "--predictions", str(predictions), "--report", str(report), "--output", str(output), "--run-id", "test", "--bootstrap-seed", "77"]):
                self.assertEqual(main(), 0)
            result = json.loads(output.read_text(encoding="utf-8"))
            self.assertTrue(result["passed"])
            self.assertEqual(result["bootstrap_seed"], 77)


if __name__ == "__main__":
    unittest.main()
