import importlib.util
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).parents[1] / "src_v3" / "audit_v3_model_field_sources.py"
SPEC = importlib.util.spec_from_file_location("audit_v3_model_field_sources", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


class ModelFieldSourceTests(unittest.TestCase):
    def test_feature_extraction_uses_only_cna_for_model_features(self):
        record = {
            "containers": {
                "cna": {
                    "title": "CNA title",
                    "descriptions": [{"lang": "en", "value": "CNA description"}],
                    "problemTypes": [{"descriptions": [{"cweId": "CWE-79"}]}],
                    "affected": [{"vendor": "Acme", "product": "Widget", "versions": [{"version": "1"}]}],
                    "references": [{"url": "https://cna.example/x"}],
                    "metrics": [{"cvssV3_1": {"baseScore": 7.5}}],
                    "providerMetadata": {"shortName": "CNA-Group"},
                },
                "adp": {"title": "must never enter text"},
            }
        }
        values = MODULE.extract(record)
        self.assertEqual(values["text"], "CNA title CNA description CWE-79")
        self.assertNotIn("must never enter", values["text"])
        self.assertEqual(values["reference_hosts"], "cna.example")
        self.assertEqual(values["cna_group"], "cna-group")

    def test_expected_schema_keeps_group_outside_model_feature_columns(self):
        self.assertNotIn("cna_group", MODULE.EXPECTED_COLUMNS - MODULE.EVALUATION_ONLY_COLUMNS)
        self.assertTrue(MODULE.ALLOWED_CNA.issuperset({"affected", "descriptions", "metrics", "problemTypes", "references", "title"}))


if __name__ == "__main__":
    unittest.main()
