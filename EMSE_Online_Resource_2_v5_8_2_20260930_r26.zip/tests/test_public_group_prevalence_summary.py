from __future__ import annotations

import csv
from pathlib import Path


def test_public_group_summary_contains_only_aggregate_ranges() -> None:
    path = Path(__file__).resolve().parents[1] / "source_data" / "group_prevalence_range_summary.csv"
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
        assert reader.fieldnames == [
            "group_dimension", "group_count_min_50_records",
            "minimum_event_prevalence", "maximum_event_prevalence",
        ]

    assert {row["group_dimension"] for row in rows} == {"cna_group", "products", "vendors"}
    counts = {row["group_dimension"]: int(row["group_count_min_50_records"]) for row in rows}
    assert counts == {"cna_group": 25, "products": 24, "vendors": 25}
    for row in rows:
        low = float(row["minimum_event_prevalence"])
        high = float(row["maximum_event_prevalence"])
        assert 0 <= low <= high <= 1
