from __future__ import annotations

import sys
import unittest
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src_v3"))
from group_holdout_v3 import select_groups, values  # noqa: E402


class GroupHoldoutTest(unittest.TestCase):
    def test_missing_values_are_never_group_tokens(self) -> None:
        self.assertEqual(values({"vendors": "__missing__"}, "vendor"), set())

    def test_selection_is_positive_support_then_total_support_then_name(self) -> None:
        rows = [
            {"vendors": "a", "outcome_union": 1}, {"vendors": "a", "outcome_union": 0},
            {"vendors": "b", "outcome_union": 1}, {"vendors": "b", "outcome_union": 1},
            {"vendors": "c", "outcome_union": 1},
        ]
        self.assertEqual(select_groups(rows, "vendor", "union", 2), [])
        rows.extend({"vendors": "a", "outcome_union": 0} for _ in range(8))
        rows.extend({"vendors": "b", "outcome_union": 0} for _ in range(8))
        self.assertEqual(select_groups(rows, "vendor", "union", 2), ["b", "a"])


if __name__ == "__main__":
    unittest.main()
