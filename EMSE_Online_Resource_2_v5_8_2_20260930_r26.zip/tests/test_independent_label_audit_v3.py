import importlib.util
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path


MODULE_PATH = Path(__file__).parents[1] / "src_v3" / "audit_v3_independent_labels.py"
SPEC = importlib.util.spec_from_file_location("audit_v3_independent_labels", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def record(version: str, severity: str = "MEDIUM", state: str = "PUBLISHED") -> dict:
    return {
        "cveMetadata": {"state": state},
        "containers": {"cna": {"affected": [{"vendor": "Acme", "product": "Widget", "versions": [{"version": version, "status": "affected"}]}], "metrics": [{"cvssV3_1": {"baseSeverity": severity}}]}},
    }


class IndependentLabelAuditTests(unittest.TestCase):
    def test_module_does_not_import_label_builder(self):
        self.assertNotIn("build_v3_labels", MODULE_PATH.read_text(encoding="utf-8"))

    def test_blob_hash_uses_raw_bytes_not_text_normalization(self):
        blob = bytes.fromhex("7b226465736372697074696f6e223a22636166c3a9227d0a")
        self.assertEqual(len(blob), 24)
        self.assertEqual(MODULE.hashlib.sha256(blob).hexdigest(), "02a32783963ccb8b66a82069ec67e43700a89cc18ca3cfd1f3b11bbd9ca6b49c")

    def test_structural_signature_flags_version_json_change_without_scope_claim(self):
        self.assertNotEqual(MODULE.structural_signatures(record("1.0")["containers"]["cna"]), MODULE.structural_signatures(record("1.0.1")["containers"]["cna"]))

    def test_recompute_scans_events_before_withdrawal(self):
        start = datetime(2025, 1, 1, tzinfo=timezone.utc)
        status, reason, flags, evidence, withdrawal = MODULE.recompute_window(
            record("1.0"),
            [("a" * 40, start + timedelta(days=1), record("2.0")), ("b" * 40, start + timedelta(days=2), record("2.0", "HIGH")), ("c" * 40, start + timedelta(days=3), record("2.0", "HIGH", "REJECTED"))],
            start,
            start + timedelta(days=90),
        )
        self.assertEqual((status, reason), ("withdraw", None))
        self.assertTrue(flags["overlap"])
        self.assertEqual([event["event"] for event in evidence], ["affected_field_structural_addition", "cna_cvss_escalation_to_high", "withdraw"])
        self.assertEqual(withdrawal, evidence[-1])

    def test_observation_time_exclusion_uses_the_frozen_minimal_schema(self):
        start = datetime(2025, 1, 1, tzinfo=timezone.utc)
        self.assertEqual(
            MODULE.comparable_label("excluded", "withdrawn_at_observation", start, start + timedelta(days=90), {"union": False}, [{"event": "ignored"}], None),
            {"status": "excluded", "reason": "withdrawn_at_observation", "t_obs": None, "t_end": None, "event_flags": None, "evidence": [], "withdraw_event": None},
        )


if __name__ == "__main__":
    unittest.main()
