from __future__ import annotations

import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src_v3"))
from build_v3_labels import classify_window  # noqa: E402


def record(version: str, severity: str = "MEDIUM", state: str = "PUBLISHED") -> dict:
    return {
        "cveMetadata": {"state": state},
        "containers": {
            "cna": {
                "affected": [{"vendor": "Acme", "product": "Widget", "versions": [{"version": version, "status": "affected"}]}],
                "metrics": [{"cvssV3_1": {"baseSeverity": severity}}],
            }
        },
    }


class V3LabelSemanticsTest(unittest.TestCase):
    def test_scans_beyond_first_event_and_records_overlap(self) -> None:
        start = datetime(2025, 1, 1, tzinfo=timezone.utc)
        status, flags, evidence, withdrawal = classify_window(
            record("1.0"),
            [
                ("a" * 40, start + timedelta(days=1), record("2.0")),
                ("b" * 40, start + timedelta(days=2), record("2.0", "HIGH")),
            ],
            start,
            start + timedelta(days=90),
        )
        self.assertEqual(status, "review")
        self.assertTrue(flags["affected_field_structural_addition"])
        self.assertTrue(flags["cna_cvss_escalation_to_high"])
        self.assertTrue(flags["overlap"])
        self.assertEqual([event["event"] for event in evidence], ["affected_field_structural_addition", "cna_cvss_escalation_to_high"])
        self.assertIsNone(withdrawal)

    def test_same_product_version_edit_is_structural_not_semantic_scope_claim(self) -> None:
        start = datetime(2025, 1, 1, tzinfo=timezone.utc)
        status, flags, evidence, _ = classify_window(
            record("1.0"),
            [("c" * 40, start + timedelta(days=1), record("1.0.1", "MEDIUM"))],
            start,
            start + timedelta(days=90),
        )
        self.assertEqual(status, "review")
        self.assertTrue(flags["affected_field_structural_addition"])
        self.assertEqual(evidence[0]["event"], "affected_field_structural_addition")

    def test_withdrawal_dominates_binary_disposition_but_retains_prior_events(self) -> None:
        start = datetime(2025, 1, 1, tzinfo=timezone.utc)
        status, flags, evidence, withdrawal = classify_window(
            record("1.0"),
            [
                ("d" * 40, start + timedelta(days=1), record("2.0")),
                ("e" * 40, start + timedelta(days=2), record("2.0", state="REJECTED")),
            ],
            start,
            start + timedelta(days=90),
        )
        self.assertEqual(status, "withdraw")
        self.assertTrue(flags["affected_field_structural_addition"])
        self.assertEqual(evidence[-1]["event"], "withdraw")
        self.assertEqual(withdrawal, evidence[-1])


if __name__ == "__main__":
    unittest.main()
